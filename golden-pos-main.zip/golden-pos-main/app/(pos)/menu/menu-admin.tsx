"use client";

import { useActionState, useState, useTransition } from "react";
import { toast } from "sonner";
import { BookOpenText, FolderPlus, Loader2, Pencil, Plus, Save, Search, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { rsExact } from "@/lib/money";
import { CATEGORY_COLORS, CATEGORY_ICONS, STATION_LABEL, type Category, type MenuItem } from "@/lib/types/menu";
import { Modal } from "@/components/ui/sheet-dialog";
import { Btn } from "@/components/pos/button";
import { Field, inputClass } from "@/components/pos/field";
import { ImageField } from "@/components/pos/image-field";
import { MenuIcon } from "@/components/pos/menu-icon";
import { DishImage } from "@/components/pos/menu-card";
import { EmptyState } from "@/components/pos/empty-state";
import { keepFormOnSubmit } from "@/lib/use-keep-form";
import { deleteCategory, deleteItem, saveCategory, saveItem, setSoldOut, type MenuFormState } from "./actions";

type Editing<T> = { mode: "new" } | { mode: "edit"; value: T } | null;

export function MenuAdmin({ categories, items }: { categories: Category[]; items: MenuItem[] }) {
  const [catId, setCatId] = useState<string>("all");
  const [q, setQ] = useState("");
  const [itemForm, setItemForm] = useState<Editing<MenuItem>>(null);
  const [catForm, setCatForm] = useState<Editing<Category>>(null);
  const [formKey, setFormKey] = useState(0);
  const [, start] = useTransition();

  const catById = Object.fromEntries(categories.map((c) => [c.id, c]));
  const rows = items
    .filter((i) => (catId === "all" || i.categoryId === catId) && (!q || i.name.toLowerCase().includes(q.toLowerCase()) || String(i.code).startsWith(q)))
    .sort((a, b) => a.code - b.code);

  const openItem = (e: Editing<MenuItem>) => { setFormKey((k) => k + 1); setItemForm(e); };
  const openCat = (e: Editing<Category>) => { setFormKey((k) => k + 1); setCatForm(e); };

  return (
    <div className="flex min-h-0 flex-1">
      {/* Categories */}
      <aside className="scroll-thin flex w-60 shrink-0 flex-col overflow-y-auto border-r border-line p-3">
        <div className="mb-2 flex items-center justify-between px-1">
          <span className="text-[12px] font-semibold text-muted-foreground">Categories</span>
          <Btn tone="soft" size="xs" onClick={() => openCat({ mode: "new" })}>
            <FolderPlus /> New
          </Btn>
        </div>
        <CatRow active={catId === "all"} onClick={() => setCatId("all")} label="All items" count={items.length} />
        {categories.map((c) => (
          <CatRow
            key={c.id}
            active={catId === c.id}
            onClick={() => setCatId(c.id)}
            label={c.name}
            count={items.filter((i) => i.categoryId === c.id).length}
            category={c}
            onEdit={() => openCat({ mode: "edit", value: c })}
          />
        ))}
      </aside>

      {/* Items */}
      <section className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-center gap-2 border-b border-line px-4 py-2.5">
          <label className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Find by name or code"
              className="h-9 w-64 rounded-full bg-muted pl-9 pr-3 text-[13px] outline-none placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-pay/40"
            />
          </label>
          <Btn tone="pay" className="ml-auto" onClick={() => openItem({ mode: "new" })} disabled={!categories.length}>
            <Plus /> Add item
          </Btn>
        </div>

        <div className="scroll-thin min-h-0 flex-1 overflow-y-auto">
          {rows.length === 0 ? (
            <EmptyState icon={BookOpenText} message={categories.length ? "No items here yet" : "Add a category first"} hint={categories.length ? "Use Add item to put a dish on the menu." : "Every item belongs to a category, like Starters or Beverages."} />
          ) : (
            <table className="w-full min-w-[760px] text-[13px]">
              <thead className="sticky top-0 z-10 bg-muted text-left text-[12px] text-muted-foreground">
                <tr>
                  <th className="py-2 pl-4 pr-2 font-medium">Item</th>
                  <th className="px-2 py-2 font-medium">Code</th>
                  <th className="px-2 py-2 font-medium">Category</th>
                  <th className="px-2 py-2 font-medium">Station</th>
                  <th className="px-2 py-2 text-right font-medium">Price (Rs)</th>
                  <th className="px-2 py-2 font-medium">Available</th>
                  <th className="py-2 pl-2 pr-4"><span className="sr-only">Edit</span></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((i) => {
                  const c = catById[i.categoryId];
                  return (
                    <tr key={i.id} className="border-b border-line hover:bg-muted/50">
                      <td className="py-2 pl-4 pr-2">
                        <span className="flex items-center gap-3">
                          <DishImage src={i.image} alt="" color={c?.color ?? "#808080"} icon={c?.icon ?? "starters"} className="size-12 shrink-0 rounded-lg" iconClassName="size-5" />
                          <span className="min-w-0">
                            <span className="block font-medium">{i.name}</span>
                            <span className="block max-w-80 truncate text-[12px] text-muted-foreground">{i.desc || "No description"}</span>
                          </span>
                        </span>
                      </td>
                      <td className="px-2 py-2 font-mono text-[12px]">{i.code}</td>
                      <td className="px-2 py-2">{c?.name}</td>
                      <td className="px-2 py-2 text-muted-foreground">{STATION_LABEL[i.station]}</td>
                      <td className="num px-2 py-2 text-right font-medium">{rsExact(i.price)}</td>
                      <td className="px-2 py-2">
                        <Switch
                          on={!i.soldOut}
                          label={i.soldOut ? `${i.name} is sold out` : `${i.name} is available`}
                          onChange={(on) => start(async () => { await setSoldOut(i.id, !on); toast.success(on ? `${i.name} is back on` : `${i.name} marked sold out`); })}
                        />
                      </td>
                      <td className="py-2 pl-2 pr-4 text-right">
                        <Btn size="sm" onClick={() => openItem({ mode: "edit", value: i })}><Pencil /> Edit</Btn>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </section>

      <Modal open={!!itemForm} onOpenChange={(o) => !o && setItemForm(null)} title={itemForm?.mode === "edit" ? "Edit item" : "Add item"} className="max-w-2xl">
        {itemForm && (
          <ItemForm
            key={formKey}
            item={itemForm.mode === "edit" ? itemForm.value : undefined}
            categories={categories}
            defaultCategory={catId !== "all" ? catId : categories[0]?.id}
            nextCode={Math.max(100, ...items.map((i) => i.code)) + 1}
            onDone={() => setItemForm(null)}
          />
        )}
      </Modal>

      <Modal open={!!catForm} onOpenChange={(o) => !o && setCatForm(null)} title={catForm?.mode === "edit" ? "Edit category" : "New category"} className="max-w-md">
        {catForm && <CategoryForm key={formKey} category={catForm.mode === "edit" ? catForm.value : undefined} onDone={() => setCatForm(null)} />}
      </Modal>
    </div>
  );
}

function CatRow({ active, onClick, label, count, category, onEdit }: { active: boolean; onClick: () => void; label: string; count: number; category?: Category; onEdit?: () => void }) {
  return (
    <div className={cn("group flex items-center rounded-lg", active ? "bg-brand-soft" : "hover:bg-muted")}>
      <button onClick={onClick} className="flex h-10 min-w-0 flex-1 items-center gap-2.5 px-2 text-left text-[13px]">
        <span className="flex size-7 shrink-0 items-center justify-center rounded-md" style={{ background: `${category?.color ?? "#808080"}1f`, color: category?.color ?? "#808080" }}>
          {category ? <MenuIcon name={category.icon} className="size-4" strokeWidth={2} /> : <span className="text-[11px] font-semibold">All</span>}
        </span>
        <span className={cn("flex-1 truncate", active && "font-medium")}>{label}</span>
        <span className="num text-[11px] text-muted-foreground">{count}</span>
      </button>
      {onEdit && (
        <button onClick={onEdit} aria-label={`Edit ${label}`} className="mr-1 rounded-md p-1.5 text-muted-foreground opacity-0 hover:bg-panel hover:text-foreground focus-visible:opacity-100 group-hover:opacity-100">
          <Pencil className="size-3.5" />
        </button>
      )}
    </div>
  );
}

function Switch({ on, onChange, label }: { on: boolean; onChange: (on: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={cn("relative inline-flex h-6 w-11 items-center rounded-full transition-colors", on ? "bg-success" : "bg-input")}
    >
      <span className={cn("inline-block size-5 rounded-full bg-white shadow transition-transform", on ? "translate-x-[22px]" : "translate-x-0.5")} />
    </button>
  );
}

function ItemForm({
  item,
  categories,
  defaultCategory,
  nextCode,
  onDone,
}: {
  item?: MenuItem;
  categories: Category[];
  defaultCategory?: string;
  nextCode: number;
  onDone: () => void;
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, startDelete] = useTransition();
  const [state, action, pending] = useActionState(async (prev: MenuFormState, fd: FormData) => {
    const r = await saveItem(prev, fd);
    if (r?.ok) { toast.success(r.ok); onDone(); }
    return r;
  }, undefined);
  const f = state?.fields ?? {};

  function remove() {
    if (!item) return;
    if (!confirmDelete) return setConfirmDelete(true);
    startDelete(async () => {
      const r = await deleteItem(item.id);
      if ("error" in r) toast.error(r.error);
      else { toast.success(r.ok); onDone(); }
    });
  }

  return (
    <form onSubmit={keepFormOnSubmit(action)} className="grid gap-4 sm:grid-cols-[220px_1fr]">
      {item && <input type="hidden" name="id" value={item.id} />}
      <ImageField name="photo" label="Photo" current={item?.image} error={f.photo} aspect="aspect-square" />

      <div className="grid grid-cols-2 gap-3">
        <Field label="Name" htmlFor="name" error={f.name} className="col-span-2">
          <input id="name" name="name" defaultValue={item?.name} required autoFocus className={inputClass} aria-invalid={!!f.name} />
        </Field>
        <Field label="Item code" htmlFor="code" error={f.code} hint="Typed at the till to add it fast">
          <input id="code" name="code" inputMode="numeric" defaultValue={item?.code ?? nextCode} required className={inputClass} aria-invalid={!!f.code} />
        </Field>
        <Field label="Price (Rs)" htmlFor="price" error={f.price}>
          <input id="price" name="price" inputMode="decimal" defaultValue={item ? (item.price / 100).toFixed(2) : ""} placeholder="1650.00" required className={inputClass} aria-invalid={!!f.price} />
        </Field>
        <Field label="Category" htmlFor="categoryId" error={f.categoryId}>
          <select id="categoryId" name="categoryId" defaultValue={item?.categoryId ?? defaultCategory} className={inputClass}>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </Field>
        <Field label="Kitchen station" htmlFor="station">
          <select id="station" name="station" defaultValue={item?.station ?? "HOT_KITCHEN"} className={inputClass}>
            {Object.entries(STATION_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </Field>
        <Field label="Short description" htmlFor="desc" error={f.desc} hint="Shown under the name on the menu card" className="col-span-2">
          <input id="desc" name="desc" defaultValue={item?.desc} maxLength={80} className={inputClass} aria-invalid={!!f.desc} />
        </Field>
        <label className="col-span-2 flex items-center gap-2 text-[13px]">
          <input type="checkbox" name="soldOut" defaultChecked={item?.soldOut} className="size-4 accent-[var(--brand-base)]" />
          Sold out today
        </label>
      </div>

      {state?.error && <p className="col-span-full text-[13px] font-medium text-void-ink">{state.error}</p>}
      <div className="col-span-full flex items-center gap-2 border-t border-line pt-3">
        {item && (
          <Btn type="button" tone={confirmDelete ? "void" : "void-outline"} onClick={remove} disabled={deleting}>
            {deleting ? <Loader2 className="animate-spin" /> : <Trash2 />} {confirmDelete ? "Click again to delete" : "Delete"}
          </Btn>
        )}
        <Btn type="button" className="ml-auto" onClick={onDone}>Cancel</Btn>
        <Btn type="submit" tone="pay" className="px-5" disabled={pending}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />} {item ? "Save changes" : "Add to menu"}
        </Btn>
      </div>
    </form>
  );
}

function CategoryForm({ category, onDone }: { category?: Category; onDone: () => void }) {
  const [icon, setIcon] = useState(category?.icon ?? "starters");
  const [color, setColor] = useState(category?.color ?? CATEGORY_COLORS[0]);
  const [deleting, startDelete] = useTransition();
  const [state, action, pending] = useActionState(async (prev: MenuFormState, fd: FormData) => {
    const r = await saveCategory(prev, fd);
    if (r?.ok) { toast.success(r.ok); onDone(); }
    return r;
  }, undefined);
  const f = state?.fields ?? {};

  return (
    <form onSubmit={keepFormOnSubmit(action)} className="space-y-4">
      {category && <input type="hidden" name="id" value={category.id} />}
      <input type="hidden" name="icon" value={icon} />
      <input type="hidden" name="color" value={color} />
      <Field label="Name" htmlFor="catName" error={f.name}>
        <input id="catName" name="name" defaultValue={category?.name} required autoFocus className={inputClass} aria-invalid={!!f.name} />
      </Field>
      <div>
        <span className="mb-1.5 block text-[12px] font-medium text-muted-foreground">Icon</span>
        <div className="grid grid-cols-8 gap-1.5">
          {CATEGORY_ICONS.map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setIcon(n)}
              aria-label={n}
              aria-pressed={icon === n}
              className={cn("flex size-9 items-center justify-center rounded-md border", icon === n ? "border-pay bg-brand-soft" : "border-input hover:bg-muted")}
              style={{ color }}
            >
              <MenuIcon name={n} className="size-[18px]" strokeWidth={1.8} />
            </button>
          ))}
        </div>
      </div>
      <div>
        <span className="mb-1.5 block text-[12px] font-medium text-muted-foreground">Colour</span>
        <div className="flex flex-wrap gap-2">
          {CATEGORY_COLORS.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setColor(c)}
              aria-label={`Colour ${c}`}
              aria-pressed={color === c}
              className={cn("size-8 rounded-full ring-offset-2 ring-offset-panel", color === c && "ring-2 ring-foreground")}
              style={{ background: c }}
            />
          ))}
        </div>
      </div>
      <div className="flex items-center gap-2 border-t border-line pt-3">
        {category && (
          <Btn
            type="button"
            tone="void-outline"
            disabled={deleting}
            onClick={() => startDelete(async () => {
              const r = await deleteCategory(category.id);
              if ("error" in r) toast.error(r.error);
              else { toast.success(r.ok); onDone(); }
            })}
          >
            <Trash2 /> Delete
          </Btn>
        )}
        <Btn type="button" className="ml-auto" onClick={onDone}>Cancel</Btn>
        <Btn type="submit" tone="pay" className="px-5" disabled={pending}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />} Save
        </Btn>
      </div>
    </form>
  );
}
