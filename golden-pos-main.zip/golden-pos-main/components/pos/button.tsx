import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

// Tones map to meaning, not decoration:
// pay = money in, kot = kitchen, info = hold/selection, void = remove, primary = neutral main action.
export const btn = cva(
  "inline-flex shrink-0 items-center justify-center gap-1.5 rounded-md font-medium whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-1 disabled:pointer-events-none disabled:opacity-45 [&_svg]:shrink-0",
  {
    variants: {
      tone: {
        outline: "border border-input bg-panel text-foreground hover:bg-muted",
        ghost: "text-foreground hover:bg-muted",
        primary: "bg-selected text-selected-foreground hover:opacity-90",
        dark: "bg-selected text-selected-foreground hover:opacity-90", // old name for primary
        pay: "bg-pay text-on-tone hover:bg-pay-hover",
        kot: "bg-kot text-on-tone hover:bg-kot-hover",
        info: "bg-info text-on-tone hover:bg-info-hover",
        void: "bg-void text-on-tone hover:bg-void-hover",
        "void-outline": "border border-input bg-panel text-void-ink hover:bg-void/10",
        "brand-outline": "border border-pay bg-panel text-pay-ink hover:bg-brand-soft",
        soft: "bg-brand-soft text-pay-ink hover:bg-pay/20",
      },
      size: {
        xs: "h-7 rounded-full px-3 text-[12px] [&_svg]:size-3.5",
        sm: "h-8 px-2.5 text-[13px] [&_svg]:size-4",
        md: "h-9 px-3 text-[13px] [&_svg]:size-4",
        lg: "h-11 px-4 text-[14px] [&_svg]:size-[18px]",
        xl: "h-14 rounded-lg px-5 text-[16px] [&_svg]:size-5",
        icon: "size-9 [&_svg]:size-4",
      },
    },
    defaultVariants: { tone: "outline", size: "md" },
  },
);

export function Btn({ tone, size, className, ...props }: React.ComponentProps<"button"> & VariantProps<typeof btn>) {
  return <button {...props} className={cn(btn({ tone, size }), className)} />;
}

/** Shortcut hint shown on buttons, e.g. <Key>F8</Key>. */
export function Key({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <kbd className={cn("rounded-[3px] border border-current/25 px-1 py-px font-sans text-[10px] font-semibold leading-none opacity-80", className)}>
      {children}
    </kbd>
  );
}
