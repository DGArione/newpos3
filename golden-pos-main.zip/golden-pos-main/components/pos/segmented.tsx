"use client";

import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export type SegmentOption<T extends string> = { value: T; label: string; icon?: LucideIcon; count?: number };

/** Pill switch for a view or filter. Active pill is filled orange. */
export function Segmented<T extends string>({
  options,
  value,
  onChange,
  label,
  size = "sm",
}: {
  options: SegmentOption<T>[];
  value: T;
  onChange: (v: T) => void;
  label: string;
  size?: "sm" | "md";
}) {
  return (
    <div role="radiogroup" aria-label={label} className="flex flex-wrap gap-1.5">
      {options.map((o) => {
        const on = o.value === value;
        const Icon = o.icon;
        return (
          <button
            key={o.value}
            role="radio"
            aria-checked={on}
            onClick={() => onChange(o.value)}
            className={cn(
              "flex items-center gap-1.5 rounded-full border px-3.5 text-[12px] transition-colors",
              size === "md" ? "h-9" : "h-8",
              on ? "border-pay bg-pay font-medium text-white" : "border-input text-foreground hover:border-pay hover:text-pay-ink",
            )}
          >
            {Icon && <Icon className="size-3.5" strokeWidth={2} />}
            {o.label}
            {o.count !== undefined && <span className={cn("num text-[11px]", on ? "text-white/80" : "text-muted-foreground")}>{o.count}</span>}
          </button>
        );
      })}
    </div>
  );
}
