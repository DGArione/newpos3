"use client";

import { useRouter } from "next/navigation";
import { THEME_COOKIE, type Theme } from "@/lib/theme";

/** Switches the terminal theme and remembers it for a year. */
export function useToggleTheme() {
  const router = useRouter();
  return () => {
    const next: Theme = document.documentElement.classList.contains("dark") ? "light" : "dark";
    document.documentElement.classList.toggle("dark", next === "dark");
    document.cookie = `${THEME_COOKIE}=${next}; path=/; max-age=31536000; samesite=lax`;
    router.refresh();
  };
}
