import type { Metadata } from "next";
import { LayoutGrid } from "lucide-react";
import { requireArea } from "@/lib/auth/session";
import { areas } from "@/lib/mock/floor";
import { PageHeader } from "@/components/pos/page-header";
import { Screen } from "@/components/pos/screen";
import { FloorView } from "./floor-view";

export const metadata: Metadata = { title: "Tables" };

export default async function TablesPage() {
  await requireArea("tables");
  const all = areas.flatMap((a) => a.tables);
  const busy = all.filter((t) => t.status === "seated" || t.status === "bill").length;

  return (
    <Screen>
      <PageHeader title="Tables" icon={LayoutGrid} meta={`${busy} of ${all.length} occupied`} />
      <FloorView areas={areas} />
    </Screen>
  );
}
