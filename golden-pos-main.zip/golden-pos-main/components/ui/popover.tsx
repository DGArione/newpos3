"use client";

import { Popover as P } from "@base-ui/react/popover";
import { cn } from "@/lib/utils";

/** Small anchored panel for quick edits (table, discount) instead of a full dialog. */
export function Popover({
  open,
  onOpenChange,
  trigger,
  children,
  side = "bottom",
  align = "start",
  className,
  triggerClassName,
  triggerLabel,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  trigger: React.ReactNode;
  children: React.ReactNode;
  side?: "top" | "bottom" | "left" | "right";
  align?: "start" | "center" | "end";
  className?: string;
  triggerClassName?: string;
  triggerLabel?: string;
}) {
  return (
    <P.Root open={open} onOpenChange={onOpenChange}>
      <P.Trigger className={triggerClassName} aria-label={triggerLabel}>{trigger}</P.Trigger>
      <P.Portal>
        <P.Positioner side={side} align={align} sideOffset={6} className="z-50">
          <P.Popup
            className={cn(
              "rounded-lg border border-border bg-panel p-3 text-foreground shadow-lg outline-none transition-[opacity,transform] duration-100 data-[ending-style]:scale-[0.98] data-[ending-style]:opacity-0 data-[starting-style]:scale-[0.98] data-[starting-style]:opacity-0",
              className,
            )}
          >
            {children}
          </P.Popup>
        </P.Positioner>
      </P.Portal>
    </P.Root>
  );
}
