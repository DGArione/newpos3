"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Dialog } from "@base-ui/react/dialog";
import {
  Armchair,
  CornerDownLeft,
  Lock,
  Search,
  SunMoon,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Area } from "@/lib/auth/roles";
import { useToggleTheme } from "./use-theme";
import { MODULES } from "./nav";

type Cmd = { id: string; group: string; label: string; hint?: string; icon: LucideIcon; run: () => void };

/** Ctrl+K: jump to a module, open a table, or run a terminal action. */
export function CommandPalette({
  open,
  onOpenChange,
  areas,
  tables,
  onLock,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  areas: Area[];
  tables: { id: string; area: string }[];
  onLock: () => void;
}) {
  const router = useRouter();
  const toggleTheme = useToggleTheme();
  const [q, setQ] = useState("");
  const [active, setActive] = useState(0);
  const listRef = useRef<HTMLUListElement>(null);

  const commands = useMemo<Cmd[]>(() => {
    const go = (href: string) => () => router.push(href);
    return [
      ...MODULES.filter((m) => areas.includes(m.area)).map((m) => ({
        id: `m-${m.href}`, group: "Go to", label: m.label, icon: m.icon, run: go(m.href),
      })),
      ...(areas.includes("pos")
        ? tables.map((t) => ({ id: `t-${t.id}`, group: "Open table", label: `Table ${t.id}`, hint: t.area, icon: Armchair, run: go(`/pos?table=${t.id}`) }))
        : []),
      { id: "a-theme", group: "Terminal", label: "Switch light / dark", icon: SunMoon, run: toggleTheme },
      { id: "a-lock", group: "Terminal", label: "Lock terminal", hint: "F10", icon: Lock, run: onLock },
    ];
  }, [areas, tables, router, toggleTheme, onLock]);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return commands.filter((c) => c.group !== "Open table").concat(commands.filter((c) => c.group === "Open table").slice(0, 6));
    return commands.filter((c) => `${c.label} ${c.hint ?? ""} ${c.group}`.toLowerCase().includes(s));
  }, [q, commands]);

  useEffect(() => {
    listRef.current?.querySelector(`[data-idx="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active]);

  function run(c: Cmd | undefined) {
    if (!c) return;
    onOpenChange(false);
    c.run();
  }

  let lastGroup = "";

  return (
    <Dialog.Root
      open={open}
      onOpenChange={(o) => {
        onOpenChange(o);
        if (!o) { setQ(""); setActive(0); }
      }}
    >
      <Dialog.Portal>
        <Dialog.Backdrop className="fixed inset-0 z-50 bg-black/50" />
        <Dialog.Popup className="fixed left-1/2 top-[12vh] z-50 w-[calc(100%-2rem)] max-w-xl -translate-x-1/2 overflow-hidden rounded-xl border border-border bg-panel shadow-2xl outline-none">
          <Dialog.Title className="sr-only">Command palette</Dialog.Title>
          <div className="flex items-center gap-2 border-b border-border px-3">
            <Search className="size-4 text-muted-foreground" />
            <input
              autoFocus
              value={q}
              onChange={(e) => { setQ(e.target.value); setActive(0); }}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => Math.min(results.length - 1, a + 1)); }
                if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(0, a - 1)); }
                if (e.key === "Enter") { e.preventDefault(); run(results[active]); }
              }}
              placeholder="Type a module, table or action"
              aria-label="Search commands"
              className="h-12 flex-1 bg-transparent text-[15px] outline-none placeholder:text-muted-foreground"
            />
            <kbd className="rounded border border-border px-1.5 text-[11px] text-muted-foreground">Esc</kbd>
          </div>
          <ul ref={listRef} className="scroll-thin max-h-[50vh] overflow-y-auto py-1" role="listbox" aria-label="Commands">
            {results.length === 0 && <li className="px-4 py-6 text-center text-[13px] text-muted-foreground">No match for &quot;{q}&quot;</li>}
            {results.map((c, i) => {
              const header = c.group !== lastGroup ? c.group : null;
              lastGroup = c.group;
              const Icon = c.icon;
              return (
                <li key={c.id}>
                  {header && <p className="px-3 pb-1 pt-2 text-[11px] font-semibold text-muted-foreground">{header}</p>}
                  <button
                    data-idx={i}
                    role="option"
                    aria-selected={i === active}
                    onMouseMove={() => setActive(i)}
                    onClick={() => run(c)}
                    className={cn("flex h-9 w-full items-center gap-2.5 px-3 text-left text-[14px]", i === active && "bg-accent text-accent-foreground")}
                  >
                    <Icon className="size-4 text-muted-foreground" strokeWidth={1.75} />
                    <span className="flex-1">{c.label}</span>
                    {c.hint && <span className="text-[12px] text-muted-foreground">{c.hint}</span>}
                    {i === active && <CornerDownLeft className="size-3.5 text-muted-foreground" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </Dialog.Popup>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
