import { cn } from "@/lib/utils";

// Sun over the sea. Kept as SVG so it prints and scales cleanly.
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" aria-hidden="true" className={cn("size-8", className)}>
      <rect width="32" height="32" rx="4" fill="#f0ad1c" />
      <circle cx="16" cy="15" r="7" fill="#fff6dc" />
      <rect x="0" y="17" width="32" height="15" fill="#f0ad1c" />
      <path d="M3 20.5c2.2 0 2.2-1.6 4.4-1.6s2.2 1.6 4.4 1.6 2.2-1.6 4.4-1.6 2.2 1.6 4.4 1.6 2.2-1.6 4.4-1.6 2.2 1.6 4.4 1.6" fill="none" stroke="#17323c" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M6 25c1.8 0 1.8-1.3 3.6-1.3s1.8 1.3 3.6 1.3 1.8-1.3 3.6-1.3 1.8 1.3 3.6 1.3 1.8-1.3 3.6-1.3 1.8 1.3 3.6 1.3" fill="none" stroke="#17323c" strokeOpacity=".55" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return <span className={cn("font-semibold tracking-tight", className)}>Golden Beach POS</span>;
}
