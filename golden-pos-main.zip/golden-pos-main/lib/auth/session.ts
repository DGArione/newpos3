import "server-only";
import { cache } from "react";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { sessionStore, staffStore } from "@/lib/store";
import { hashToken, newSessionToken } from "./hash";
import { SESSION_COOKIE } from "./constants";
import { canAccess, homeFor, type Area, type AuthMethod, type Role } from "./roles";

const sessionHours = () => Number(process.env.SESSION_HOURS ?? 12);
export const terminalName = () => process.env.TERMINAL_NAME ?? "Counter 1";

export type CurrentUser = {
  id: string;
  name: string;
  role: Role;
  staffCode: string;
  sessionId: string;
  method: AuthMethod;
  signedInAt: Date;
};

export async function requestIp() {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;
}

export async function createSession(userId: string, method: AuthMethod) {
  const token = newSessionToken();
  const expiresAt = new Date(Date.now() + sessionHours() * 3600_000);

  await sessionStore.create({
    tokenHash: hashToken(token),
    userId,
    method,
    terminal: terminalName(),
    expiresAt,
  });

  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.SECURE_COOKIES === "true",
    path: "/",
    expires: expiresAt,
  });
}

// Validates the session once per request.
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const session = await sessionStore.byTokenHash(hashToken(token));
  if (!session || session.revokedAt || session.expiresAt < new Date()) return null;

  const user = await staffStore.byId(session.userId);
  if (!user || !user.active) return null;

  await sessionStore.touch(session.id);

  return {
    id: user.id,
    name: user.name,
    role: user.role,
    staffCode: user.staffCode,
    sessionId: session.id,
    method: session.method,
    signedInAt: session.createdAt,
  };
});

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

// First line of every protected page.
export async function requireArea(area: Area) {
  const user = await requireUser();
  if (!canAccess(user.role, area)) redirect(homeFor(user.role));
  return user;
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await sessionStore.revoke(hashToken(token));
  jar.delete(SESSION_COOKIE);
}
