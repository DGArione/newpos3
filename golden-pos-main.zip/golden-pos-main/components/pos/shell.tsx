"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { Area } from "@/lib/auth/roles";
import type { SidebarMode } from "@/lib/sidebar";
import { Sidebar } from "./sidebar";
import { AppHeader } from "./app-header";
import { CommandPalette } from "./command-palette";

/** App frame: sidebar, greeting header, Ctrl+K palette and F10 lock. */
export function Shell({
  areas,
  name,
  roleLabel,
  terminal,
  since,
  tables,
  readyTickets,
  brand,
  heldCount,
  sidebarMode,
  signOut,
  children,
}: {
  areas: Area[];
  name: string;
  roleLabel: string;
  terminal: string;
  since: string;
  tables: { id: string; area: string }[];
  readyTickets: number;
  brand: { name: string; logo?: string };
  heldCount: number;
  sidebarMode: SidebarMode;
  signOut: () => Promise<void>;
  children: React.ReactNode;
}) {
  const lockForm = useRef<HTMLFormElement>(null);
  const [palette, setPalette] = useState(false);
  const lock = useCallback(() => lockForm.current?.requestSubmit(), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "F10") { e.preventDefault(); lock(); }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPalette((p) => !p); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lock]);

  return (
    <div className="flex h-dvh gap-3 overflow-hidden bg-background p-3">
      <form ref={lockForm} action={signOut} hidden />
      <Sidebar areas={areas} terminal={terminal} since={since} brand={brand} heldCount={heldCount} initialMode={sidebarMode} onLock={lock} />
      <div className="flex min-w-0 flex-1 flex-col gap-3">
        <AppHeader
          firstName={name.split(" ")[0]}
          name={name}
          roleLabel={roleLabel}
          terminal={terminal}
          areas={areas}
          readyTickets={readyTickets}
          onSearch={() => setPalette(true)}
        />
        <main className="flex min-h-0 flex-1 flex-col">{children}</main>
      </div>
      <CommandPalette open={palette} onOpenChange={setPalette} areas={areas} tables={tables} onLock={lock} />
    </div>
  );
}
