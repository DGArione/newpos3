"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { pct, rsExact } from "@/lib/money";
import { Btn } from "@/components/pos/button";

const PRESETS = [5, 10, 15, 20];

export function DiscountPicker({ current, subtotal, onApply }: { current: number; subtotal: number; onApply: (rate: number) => void }) {
  const [percent, setPercent] = useState(current ? String(Math.round(current * 100)) : "");
  const value = Math.min(100, Number(percent || 0));

  return (
    <div className="space-y-2.5">
      <p className="text-[13px] font-semibold">Bill discount</p>
      <div className="grid grid-cols-4 gap-1">
        {PRESETS.map((p) => (
          <button
            key={p}
            onClick={() => setPercent(String(p))}
            className={cn("h-9 rounded border text-[13px] font-semibold", value === p ? "border-ring bg-accent" : "border-input hover:bg-muted")}
          >
            {p}%
          </button>
        ))}
      </div>
      <label className="flex items-center gap-2 text-[12px] text-muted-foreground">
        Other
        <input
          inputMode="numeric"
          value={percent}
          onChange={(e) => setPercent(e.target.value.replace(/\D/g, "").slice(0, 3))}
          onKeyDown={(e) => e.key === "Enter" && onApply(value / 100)}
          className="h-8 w-16 rounded border border-input bg-background px-2 text-[13px] text-foreground outline-none focus-visible:border-ring"
        />
        %
        <span className="num ml-auto text-foreground">- {rsExact(pct(subtotal, value / 100))}</span>
      </label>
      <div className="flex gap-1.5 border-t border-line pt-2.5">
        {current > 0 && <Btn tone="void-outline" size="sm" onClick={() => onApply(0)}>Remove</Btn>}
        <Btn tone="primary" size="sm" className="ml-auto" onClick={() => onApply(value / 100)}>Apply</Btn>
      </div>
    </div>
  );
}
