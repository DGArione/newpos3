// Shapes shared by server and client. Money is integer cents.

export type Station = "HOT_KITCHEN" | "BAR" | "PASTRY";

/** Icon names map to Lucide icons in components/pos/menu-icon.tsx */
export type IconName =
  | "starters" | "seafood" | "kottu" | "curries" | "drinks" | "desserts"
  | "drumstick" | "shrimp" | "fish" | "flame" | "soup" | "egg" | "pot" | "wheat"
  | "coconut" | "citrus" | "coffee" | "beer" | "cocktail" | "icecream" | "cake" | "salad" | "shell";

export type Category = { id: string; name: string; icon: IconName; color: string };

export type MenuItem = {
  id: string;
  code: number;
  categoryId: string;
  name: string;
  price: number;
  station: Station;
  icon: IconName;
  desc: string;
  /** URL of the photo, e.g. "/media/abc.jpg" or "/menu/301.jpg". */
  image?: string;
  soldOut?: boolean;
};

export type Banner = {
  id: string;
  title: string;
  text: string;
  image?: string;
  /** Menu item the "Add to order" button adds. */
  itemId?: string;
  active: boolean;
};

export type Branding = {
  restaurantName: string;
  tagline: string;
  logo?: string;
  /** Picture in the coloured panel of the login card. */
  loginImage?: string;
  /** Picture behind the whole login page. */
  loginBackground?: string;
  /** Main colour of the whole system (hex). Defaults to golden orange. */
  brandColor?: string;
};

export type OrderType = "dine-in" | "takeaway" | "delivery";

export type HeldLine = { itemId: string; qty: number; note: string; sent: boolean };

export type HeldOrder = {
  id: string;
  orderNo: number;
  type: OrderType;
  table: string | null;
  guests: number;
  customer: string;
  discountRate: number;
  lines: HeldLine[];
  total: number;
  heldBy: string;
  heldAt: Date;
};

export const STATION_LABEL: Record<Station, string> = { HOT_KITCHEN: "Hot kitchen", BAR: "Bar", PASTRY: "Pastry" };

export const CATEGORY_ICONS: IconName[] = ["starters", "seafood", "kottu", "curries", "drinks", "desserts", "drumstick", "shrimp", "fish", "flame", "soup", "egg", "pot", "wheat", "coconut", "citrus", "coffee", "beer", "cocktail", "icecream", "cake", "salad", "shell"];

export const CATEGORY_COLORS = ["#d9772b", "#2a7d8f", "#b3442a", "#6f8a1f", "#3a68ad", "#a74e83", "#f6990d", "#7471f6", "#35c344", "#f52121"];
