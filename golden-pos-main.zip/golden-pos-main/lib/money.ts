// All money is integer cents (LKR × 100). Format only at the edge.

const whole = new Intl.NumberFormat("en-LK", { maximumFractionDigits: 0 });
const exact = new Intl.NumberFormat("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** "1,250" — for menu tiles, where cents are always zero. */
export const rs = (cents: number) => whole.format(Math.round(cents / 100));

/** "1,250.00" — for the ticket and payments. */
export const rsExact = (cents: number) => exact.format(cents / 100);

/** Percentage of an amount, rounded to the nearest cent. */
export const pct = (cents: number, rate: number) => Math.round(cents * rate);

export const SERVICE_CHARGE_RATE = 0.1;
