import type { Metadata } from "next";
import { ReceiptText } from "lucide-react";
import { requireArea } from "@/lib/auth/session";
import { orders } from "@/lib/mock/orders";
import { PageHeader } from "@/components/pos/page-header";
import { Screen } from "@/components/pos/screen";
import { OrdersTable } from "./orders-table";

export const metadata: Metadata = { title: "Orders" };

export default async function OrdersPage() {
  await requireArea("orders");
  return (
    <Screen>
      <PageHeader title="Orders" icon={ReceiptText} meta="Today" />
      <OrdersTable orders={orders} />
    </Screen>
  );
}
