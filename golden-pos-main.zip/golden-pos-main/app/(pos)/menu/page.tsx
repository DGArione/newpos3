import type { Metadata } from "next";
import { BookOpenText } from "lucide-react";
import { requireArea } from "@/lib/auth/session";
import { menuStore } from "@/lib/store";
import { PageHeader } from "@/components/pos/page-header";
import { Screen } from "@/components/pos/screen";
import { MenuAdmin } from "./menu-admin";

export const metadata: Metadata = { title: "Menu" };

export default async function MenuPage() {
  await requireArea("menu");
  const [categories, items] = await Promise.all([menuStore.categories(), menuStore.items()]);

  return (
    <Screen>
      <PageHeader title="Menu" icon={BookOpenText} meta={`${items.length} items in ${categories.length} categories`} />
      <MenuAdmin categories={categories} items={items} />
    </Screen>
  );
}
