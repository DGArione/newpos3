"use client";

import Link from "next/link";
import { Bell, Moon, Search, Sun } from "lucide-react";
import type { Area } from "@/lib/auth/roles";
import { Clock } from "./clock";
import { Identity } from "./identity";
import { useToggleTheme } from "./use-theme";

export function AppHeader({
  firstName,
  name,
  roleLabel,
  terminal,
  areas,
  readyTickets,
  onSearch,
}: {
  firstName: string;
  name: string;
  roleLabel: string;
  terminal: string;
  areas: Area[];
  readyTickets: number;
  onSearch: () => void;
}) {
  const toggleTheme = useToggleTheme();

  return (
    <header className="flex shrink-0 items-center gap-4">
      <div className="min-w-0">
        <h1 className="truncate text-[20px] font-semibold leading-tight">Hello, {firstName}!</h1>
        <p className="truncate text-[12px] text-muted-foreground">
          <Clock pattern="EEEE d MMMM, h:mm a" /> <span className="mx-1 text-input">|</span> {terminal}
        </p>
      </div>

      <button
        onClick={onSearch}
        className="ml-auto flex h-11 w-full max-w-md items-center gap-2.5 rounded-xl bg-panel px-4 text-[13px] text-muted-foreground hover:ring-1 hover:ring-border"
      >
        <Search className="size-[18px] text-pay" />
        <span className="flex-1 text-left">Search menu, tables, screens</span>
        <kbd className="rounded-md bg-muted px-1.5 py-0.5 text-[11px]">Ctrl K</kbd>
      </button>

      <div className="flex h-14 shrink-0 items-center gap-2 rounded-2xl bg-panel px-3">
        <button
          onClick={toggleTheme}
          aria-label="Switch light or dark theme"
          title="Switch light / dark"
          className="flex size-9 items-center justify-center rounded-lg text-bar-foreground hover:bg-muted"
        >
          <Moon className="size-[18px] dark:hidden" />
          <Sun className="hidden size-[18px] dark:block" />
        </button>
        {areas.includes("kitchen") || areas.includes("pos") ? (
          <Link
            href={areas.includes("kitchen") ? "/kitchen" : "/orders"}
            aria-label={`${readyTickets} orders ready`}
            title={`${readyTickets} orders ready to serve`}
            className="relative flex size-9 items-center justify-center rounded-lg bg-pay text-white hover:bg-pay-hover"
          >
            <Bell className="size-[18px]" />
            {readyTickets > 0 && (
              <span className="absolute -right-1 -top-1 flex size-4 items-center justify-center rounded-full bg-void text-[10px] font-semibold ring-2 ring-panel">
                {readyTickets}
              </span>
            )}
          </Link>
        ) : null}
        <span className="ml-1 hidden lg:block">
          <Identity name={name} sub={roleLabel} />
        </span>
      </div>
    </header>
  );
}
