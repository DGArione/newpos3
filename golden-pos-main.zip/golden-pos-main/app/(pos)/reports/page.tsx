import type { Metadata } from "next";
import { BarChart3, FileSpreadsheet, PieChart, Receipt, TrendingUp, Wallet } from "lucide-react";
import { requireArea } from "@/lib/auth/session";
import { PageHeader } from "@/components/pos/page-header";
import { Screen } from "@/components/pos/screen";

export const metadata: Metadata = { title: "Reports" };

const REPORTS = [
  { icon: Receipt, name: "Daily Sales Summary", desc: "Totals by payment type, discounts, service charge" },
  { icon: Wallet, name: "Cash Up / Shift Close", desc: "Expected vs counted cash per cashier" },
  { icon: PieChart, name: "Item Sales", desc: "Quantity and value sold per item and category" },
  { icon: BarChart3, name: "Hourly Sales", desc: "Busy hours across the day" },
  { icon: FileSpreadsheet, name: "Void & Discount Log", desc: "Who voided or discounted what, and when" },
];

export default async function ReportsPage() {
  await requireArea("reports");
  return (
    <Screen>
      <PageHeader title="Reports" icon={TrendingUp} />
      <div className="scroll-thin flex-1 overflow-y-auto p-4">
        <div className="max-w-3xl overflow-hidden rounded-md border border-border bg-panel">
          {REPORTS.map(({ icon: Icon, name, desc }) => (
            <div key={name} className="flex items-center gap-3 border-b border-line px-4 py-3 last:border-0">
              <Icon className="size-5 text-muted-foreground" strokeWidth={1.6} />
              <div className="flex-1">
                <p className="text-[14px] font-semibold">{name}</p>
                <p className="text-[12px] text-muted-foreground">{desc}</p>
              </div>
              <span className="rounded bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">Needs database</span>
            </div>
          ))}
        </div>
      </div>
    </Screen>
  );
}
