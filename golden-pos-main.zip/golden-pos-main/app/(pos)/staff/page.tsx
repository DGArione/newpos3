import type { Metadata } from "next";
import { format, formatDistanceToNow } from "date-fns";
import {
  KeyRound,
  LockKeyhole,
  LogIn,
  LogOut,
  ShieldAlert,
  Unlock,
  UserCheck,
  UserPlus,
  Users,
  UserX,
  type LucideIcon,
} from "lucide-react";
import { eventStore, staffStore, type AuthEventType } from "@/lib/store";
import { requireArea } from "@/lib/auth/session";
import { assignableRoles } from "@/lib/auth/roles";
import { PageHeader } from "@/components/pos/page-header";
import { Screen } from "@/components/pos/screen";
import { RoleBadge } from "@/components/pos/role-badge";
import { Identity } from "@/components/pos/identity";
import { StatusBadge } from "@/components/pos/status-badge";
import { cn } from "@/lib/utils";
import { AddStaff } from "./add-staff";
import { StaffRowActions } from "./staff-row-actions";

export const metadata: Metadata = { title: "Users" };

const EVENT: Record<AuthEventType, { label: string; icon: LucideIcon; bad?: boolean }> = {
  LOGIN_SUCCESS: { label: "logged in", icon: LogIn },
  LOGIN_FAILED: { label: "failed login", icon: ShieldAlert, bad: true },
  ACCOUNT_LOCKED: { label: "account locked", icon: LockKeyhole, bad: true },
  LOGOUT: { label: "locked terminal", icon: LogOut },
  PIN_RESET: { label: "PIN changed", icon: KeyRound },
  USER_CREATED: { label: "user created", icon: UserPlus },
  USER_DEACTIVATED: { label: "deactivated", icon: UserX, bad: true },
  USER_REACTIVATED: { label: "reactivated", icon: UserCheck },
  USER_UNLOCKED: { label: "unlocked", icon: Unlock },
};

const ROLE_ORDER = ["OWNER", "MANAGER", "CASHIER", "WAITER", "KITCHEN"];

export default async function StaffPage() {
  const me = await requireArea("staff");
  const canManage = assignableRoles(me.role);
  const [staff, events] = await Promise.all([staffStore.list(), eventStore.recent(25)]);
  const byId = Object.fromEntries(staff.map((s) => [s.id, s]));
  const sorted = [...staff].sort(
    (a, b) => Number(b.active) - Number(a.active) || ROLE_ORDER.indexOf(a.role) - ROLE_ORDER.indexOf(b.role) || a.name.localeCompare(b.name),
  );
  const now = new Date();

  return (
    <Screen>
      <PageHeader title="Users" icon={Users} meta={`${staff.filter((s) => s.active).length} active users`}>
        <AddStaff roles={canManage} />
      </PageHeader>

      <div className="grid min-h-0 flex-1 xl:grid-cols-[1fr_340px]">
        <div className="scroll-thin min-h-0 overflow-auto bg-panel">
          <table className="w-full min-w-[760px] text-[13px]">
            <thead className="sticky top-0 bg-muted text-left text-[12px] text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-4 py-2 font-semibold">User ID</th>
                <th className="px-3 py-2 font-semibold">Name</th>
                <th className="px-3 py-2 font-semibold">Role</th>
                <th className="px-3 py-2 font-semibold">Status</th>
                <th className="px-3 py-2 font-semibold">Last Login</th>
                <th className="px-4 py-2 text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((s) => {
                const locked = !!s.lockedUntil && s.lockedUntil > now;
                return (
                  <tr key={s.id} className={cn("border-b border-line hover:bg-muted/60", !s.active && "text-muted-foreground")}>
                    <td className="px-4 py-2 font-mono text-[12px] font-semibold">{s.staffCode}</td>
                    <td className="px-3 py-2">
                      <Identity name={s.id === me.id ? `${s.name} (you)` : s.name} sub={s.email ?? undefined} />
                    </td>
                    <td className="px-3 py-2"><RoleBadge role={s.role} /></td>
                    <td className="px-3 py-2">
                      <StatusBadge status={!s.active ? "inactive" : locked ? "locked" : "active"} />
                    </td>
                    <td className="num px-3 py-2 text-muted-foreground">
                      {s.lastLoginAt ? format(s.lastLoginAt, "d MMM, h:mm a") : "Never"}
                    </td>
                    <td className="px-4 py-1.5">
                      {canManage.includes(s.role) && s.id !== me.id && (
                        <StaffRowActions userId={s.id} name={s.name} active={s.active} locked={locked} />
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <section aria-labelledby="activity" className="flex min-h-0 flex-col border-l border-border bg-panel">
          <h2 id="activity" className="flex h-9 items-center border-b border-border bg-muted px-3 text-[13px] font-semibold">
            Login Activity
          </h2>
          <ol className="scroll-thin min-h-0 flex-1 overflow-y-auto">
            {events.length === 0 && <li className="p-4 text-[13px] text-muted-foreground">No activity yet.</li>}
            {events.map((e) => {
              const ev = EVENT[e.type];
              const who = (e.userId && byId[e.userId]?.name) ?? `User ID ${e.staffCode ?? "unknown"}`;
              const actor = e.actorId ? byId[e.actorId]?.name : null;
              return (
                <li key={e.id} className="flex gap-2.5 border-b border-line px-3 py-2 text-[13px]">
                  <ev.icon className={cn("mt-0.5 size-4 shrink-0", ev.bad ? "text-void" : "text-muted-foreground")} strokeWidth={1.75} />
                  <span className="min-w-0">
                    <b className="font-semibold">{who}</b> {ev.label}
                    {actor && actor !== who && <> by {actor}</>}
                    <span className="block text-[11px] text-muted-foreground">
                      {formatDistanceToNow(e.createdAt, { addSuffix: true })} on {e.terminal}
                    </span>
                  </span>
                </li>
              );
            })}
          </ol>
        </section>
      </div>
    </Screen>
  );
}
