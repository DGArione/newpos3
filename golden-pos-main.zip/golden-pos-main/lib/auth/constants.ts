export const SESSION_COOKIE = "gp_session";
export const MAX_FAILED_ATTEMPTS = 5;
export const LOCK_MINUTES = 15;
