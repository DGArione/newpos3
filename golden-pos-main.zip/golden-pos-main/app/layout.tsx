import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { cookies } from "next/headers";
import { Toaster } from "sonner";
import { THEME_COOKIE, parseTheme } from "@/lib/theme";
import { settingsStore } from "@/lib/store";
import { DEFAULT_BRAND_COLOR, isHex } from "@/lib/brand-color";
import "./globals.css";

// Bundled in app/fonts so the till works with no internet.
const poppins = localFont({
  src: [
    { path: "./fonts/poppins-400.woff2", weight: "400" },
    { path: "./fonts/poppins-500.woff2", weight: "500" },
    { path: "./fonts/poppins-600.woff2", weight: "600" },
    { path: "./fonts/poppins-700.woff2", weight: "700" },
  ],
  variable: "--font-poppins",
});

export const metadata: Metadata = {
  title: { default: "Golden Beach POS", template: "%s - Golden Beach POS" },
  description: "Point of sale for Golden Beach restaurant.",
};

export const viewport: Viewport = {
  themeColor: "#f6990d",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const theme = parseTheme((await cookies()).get(THEME_COOKIE)?.value);
  const { brandColor } = await settingsStore.branding();
  // Only a validated hex reaches the page, so this style tag can't inject anything else.
  const brand = brandColor && isHex(brandColor) ? brandColor : DEFAULT_BRAND_COLOR;

  return (
    <html lang="en" className={`${poppins.variable} ${theme === "dark" ? "dark" : ""} h-full antialiased`}>
      <body className="h-full">
        <style>{`:root{--brand-base:${brand}}`}</style>
        {children}
        <Toaster
          theme={theme}
          position="bottom-center"
          offset={20}
          richColors
          toastOptions={{ style: { borderRadius: 12, fontFamily: "inherit" } }}
        />
      </body>
    </html>
  );
}
