import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { homeFor } from "@/lib/auth/roles";
import { PasswordLogin } from "./password-login";

export const metadata: Metadata = { title: "Back office login" };

export default async function PasswordLoginPage() {
  const user = await getCurrentUser();
  if (user) redirect(homeFor(user.role));

  return (
    <div>
      <h1 className="text-[20px] font-semibold">Back Office Login</h1>
      <p className="text-[13px] text-muted-foreground">Owners and managers only.</p>
      <PasswordLogin />
      <Link href="/login" className="mt-4 flex items-center justify-center gap-1.5 text-[13px] font-semibold text-pay-ink hover:underline">
        <ArrowLeft className="size-4" /> Back to staff PIN login
      </Link>
    </div>
  );
}
