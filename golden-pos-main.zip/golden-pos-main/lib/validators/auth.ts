import { z } from "zod";

export const staffCodeSchema = z
  .string()
  .trim()
  .regex(/^\d{3,6}$/, { error: "User ID must be 3 to 6 digits." });

export const pinSchema = z
  .string()
  .regex(/^\d{4,6}$/, { error: "PIN is 4 to 6 digits." });

export const pinLoginSchema = z.object({
  staffCode: staffCodeSchema,
  pin: pinSchema,
});
export type PinLoginInput = z.infer<typeof pinLoginSchema>;

export const passwordLoginSchema = z.object({
  email: z.email({ error: "Enter a valid email." }).trim().toLowerCase(),
  password: z.string().min(1, { error: "Enter your password." }),
});
export type PasswordLoginInput = z.infer<typeof passwordLoginSchema>;
