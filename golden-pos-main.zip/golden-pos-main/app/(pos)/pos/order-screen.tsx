"use client";

import { useEffect, useEffectEvent, useMemo, useRef, useState, useTransition } from "react";
import { toast } from "sonner";
import {
  Armchair,
  BadgePercent,
  Bike,
  ChefHat,
  CirclePause,
  Minus,
  NotebookPen,
  PanelRightClose,
  PanelRightOpen,
  Phone,
  Play,
  Plus,
  Printer,
  Search,
  ShoppingBag,
  ShoppingCart,
  Trash2,
  UtensilsCrossed,
  Wallet,
  X,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { pct, rsExact, SERVICE_CHARGE_RATE } from "@/lib/money";
import type { Banner, Category, HeldOrder, MenuItem, OrderType, Station } from "@/lib/types/menu";
import type { OrderSnapshot } from "@/lib/validators/order";
import type { Area as FloorArea } from "@/lib/mock/floor";
import { Btn, Key } from "@/components/pos/button";
import { DishImage, MenuCard } from "@/components/pos/menu-card";
import { MenuIcon } from "@/components/pos/menu-icon";
import { EmptyState } from "@/components/pos/empty-state";
import { TimeAgo } from "@/components/pos/time-ago";
import { Popover } from "@/components/ui/popover";
import { PaymentDialog } from "./payment-dialog";
import { TablePicker } from "./table-picker";
import { DiscountPicker } from "./discount-picker";
import { HomeBanners } from "./home-banners";
import { holdOrder, newOrderNumber, resumeOrder } from "./actions";
import { ORDER_PANEL_COOKIE } from "@/lib/sidebar";

type Line = { key: string; itemId: string; qty: number; note: string; sent: boolean };

const ORDER_TYPES: { value: OrderType; label: string; icon: LucideIcon }[] = [
  { value: "dine-in", label: "Dine In", icon: UtensilsCrossed },
  { value: "takeaway", label: "Take Away", icon: ShoppingBag },
  { value: "delivery", label: "Delivery", icon: Bike },
];

const STATION_NAME: Record<Station, string> = { HOT_KITCHEN: "Kitchen", BAR: "Bar", PASTRY: "Pastry" };
const QUICK_NOTES = ["Less spicy", "No onion", "Allergy - ask steward", "Parcel"];

let lineSeq = 0;
const newKey = () => `l${++lineSeq}`;

export function OrderScreen({
  server,
  categories,
  menu,
  floor,
  banners,
  initialHeld,
  initialTable,
  initialPanelCollapsed,
}: {
  server: string;
  categories: Category[];
  menu: MenuItem[];
  floor: FloorArea[];
  banners: Banner[];
  initialHeld: HeldOrder[];
  initialTable: string | null;
  initialPanelCollapsed: boolean;
}) {
  // Number is reserved on the server when the first item is added; null = new, nothing added yet.
  const [orderNo, setOrderNo] = useState<number | null>(null);
  const [orderType, setOrderType] = useState<OrderType>("dine-in");
  const [table, setTable] = useState<string | null>(initialTable);
  const [guests, setGuests] = useState(2);
  const [customer, setCustomer] = useState("");
  const [category, setCategory] = useState("all");
  const [query, setQuery] = useState("");
  const [lines, setLines] = useState<Line[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [discountRate, setDiscountRate] = useState(0);
  const [pop, setPop] = useState<null | "table" | "discount">(null);
  const [payOpen, setPayOpen] = useState(false);
  const [held, setHeld] = useState<HeldOrder[]>(initialHeld);
  const [resumed, setResumed] = useState(false);
  const [collapsed, setCollapsed] = useState(initialPanelCollapsed);
  const [busy, startBusy] = useTransition();
  const searchRef = useRef<HTMLInputElement>(null);

  const items = useMemo(() => Object.fromEntries(menu.map((m) => [m.id, m])), [menu]);
  const catById = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c])), [categories]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q) return menu.filter((m) => m.name.toLowerCase().includes(q) || String(m.code).startsWith(q));
    return category === "all" ? menu : menu.filter((m) => m.categoryId === category);
  }, [menu, category, query]);

  const qtyByItem = useMemo(() => {
    const map: Record<string, number> = {};
    for (const l of lines) map[l.itemId] = (map[l.itemId] ?? 0) + l.qty;
    return map;
  }, [lines]);

  const subtotal = lines.reduce((s, l) => s + items[l.itemId].price * l.qty, 0);
  const discount = pct(subtotal, discountRate);
  const service = orderType === "dine-in" ? pct(subtotal - discount, SERVICE_CHARGE_RATE) : 0;
  const total = subtotal - discount + service;
  const unsent = lines.filter((l) => !l.sent);
  const unsentQty = unsent.reduce((s, l) => s + l.qty, 0);

  const patch = (key: string, p: Partial<Line>) => setLines((prev) => prev.map((l) => (l.key === key ? { ...l, ...p } : l)));

  function add(item: MenuItem) {
    if (item.soldOut) return toast.warning(`${item.name} is sold out.`);
    if (orderNo === null && !busy) startBusy(async () => setOrderNo(await newOrderNumber()));
    const match = lines.find((l) => l.itemId === item.id && !l.sent && !l.note);
    if (match) {
      patch(match.key, { qty: match.qty + 1 });
      setSelected(match.key);
      return;
    }
    const line: Line = { key: newKey(), itemId: item.id, qty: 1, note: "", sent: false };
    setLines((prev) => [...prev, line]);
    setSelected(line.key);
  }

  function changeQty(key: string, delta: number) {
    setLines((prev) => prev.flatMap((l) => (l.key !== key ? [l] : l.qty + delta <= 0 ? [] : [{ ...l, qty: l.qty + delta }])));
  }

  function snapshot(): OrderSnapshot | null {
    if (orderNo === null) return null;
    return {
      orderNo,
      type: orderType,
      table,
      guests,
      customer,
      discountRate,
      lines: lines.map(({ itemId, qty, note, sent }) => ({ itemId, qty, note, sent })),
      total,
    };
  }

  function clearScreen() {
    setLines([]);
    setSelected(null);
    setCustomer("");
    setDiscountRate(0);
    setPayOpen(false);
    setResumed(false);
    setOrderNo(null);
    if (orderType === "dine-in") setTable(null);
  }

  // After a sale. The next order gets its number when its first item is added.
  function resetOrder() {
    clearScreen();
  }

  // TODO(db phase): save the order and print one KOT per station.
  function sendKot() {
    if (orderType === "dine-in" && !table) {
      setPop("table");
      return toast.info("Choose a table before sending the KOT.");
    }
    if (!unsent.length) return toast.info("No new items to send.");
    const byStation: Partial<Record<Station, number>> = {};
    for (const l of unsent) byStation[items[l.itemId].station] = (byStation[items[l.itemId].station] ?? 0) + l.qty;
    setLines((prev) => prev.map((l) => ({ ...l, sent: true })));
    setSelected(null);
    toast.success(`KOT sent for order ${orderNo}`, {
      description: Object.entries(byStation).map(([st, n]) => `${STATION_NAME[st as Station]}: ${n}`).join("   "),
    });
  }

  function hold() {
    if (!lines.length || busy) return;
    const snap = snapshot();
    if (!snap) return toast.info("One moment, the order number is still being assigned.");
    startBusy(async () => {
      const r = await holdOrder(snap);
      if ("error" in r) return void toast.error(r.error);
      setHeld(r.held);
      clearScreen();
      toast.success(`Order ${snap.orderNo} is on hold`, { description: "Tap it in the On hold bar to continue." });
    });
  }

  function resume(h: HeldOrder) {
    if (busy) return;
    const current = lines.length ? snapshot() : null;
    if (lines.length && !current) return toast.info("One moment, the order number is still being assigned.");
    startBusy(async () => {
      const r = await resumeOrder(h.id, current);
      setHeld(r.held);
      if ("error" in r) return void toast.error(r.error);
      const o = r.order;
      setOrderNo(o.orderNo);
      setOrderType(o.type);
      setTable(o.table);
      setGuests(o.guests);
      setCustomer(o.customer);
      setDiscountRate(o.discountRate);
      // Skip lines whose item was removed from the menu while the order was parked.
      setLines(o.lines.filter((l) => items[l.itemId]).map((l) => ({ ...l, key: newKey() })));
      setSelected(null);
      setResumed(true);
      toast.success(`Order ${o.orderNo} is back`, current ? { description: `Order ${current.orderNo} was put on hold.` } : undefined);
    });
  }

  function pay() {
    if (!lines.length) return toast.info("Add items before taking payment.");
    setPayOpen(true);
  }

  function searchEnter() {
    const code = Number(query.trim());
    const hit = Number.isInteger(code) ? menu.find((m) => m.code === code) : undefined;
    const target = hit ?? (visible.length === 1 ? visible[0] : undefined);
    if (target) {
      add(target);
      setQuery("");
    }
  }

  // Fold the order panel into a thin bar for more menu space; remembered per till.
  function togglePanel() {
    const next = !collapsed;
    setCollapsed(next);
    document.cookie = `${ORDER_PANEL_COOKIE}=${next ? "collapsed" : "expanded"}; path=/; max-age=31536000; samesite=lax`;
  }

  // F2 search, F4 KOT, F8 pay, F9 hold.
  const onFnKey = useEffectEvent((e: KeyboardEvent) => {
    if (payOpen) return;
    const fn = ({ F2: () => searchRef.current?.focus(), F4: sendKot, F8: pay, F9: hold } as Record<string, () => void>)[e.key];
    if (fn) {
      e.preventDefault();
      fn();
    }
  });
  useEffect(() => {
    window.addEventListener("keydown", onFnKey);
    return () => window.removeEventListener("keydown", onFnKey);
  }, []);

  return (
    <div className="flex min-h-0 flex-1 gap-3">
      {/* Left: banners, held orders, menu */}
      <div className="flex min-w-0 flex-1 flex-col gap-3">
        <HomeBanners banners={banners} items={items} onAdd={add} />

        {held.length > 0 && <HeldStrip held={held} busy={busy} onResume={resume} />}

        <section className="flex min-h-0 flex-1 flex-col rounded-2xl bg-panel" aria-label="Menu">
          <div className="flex items-center gap-3 px-5 pb-3 pt-4">
            <h2 className="text-[15px] font-semibold">Golden Beach Menu</h2>
            <span className="text-[12px] text-muted-foreground">{visible.length} items</span>
            <label className="relative ml-auto flex w-60 items-center">
              <Search className="pointer-events-none absolute left-3 size-4 text-muted-foreground" />
              <input
                ref={searchRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") searchEnter();
                  if (e.key === "Escape") setQuery("");
                }}
                placeholder="Name or item code"
                aria-label="Search item name or code"
                className="h-9 w-full rounded-full bg-muted pl-9 pr-10 text-[13px] outline-none placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-pay/40"
              />
              {query ? (
                <button onClick={() => setQuery("")} aria-label="Clear search" className="absolute right-2.5 rounded-full p-0.5 text-muted-foreground hover:bg-line">
                  <X className="size-4" />
                </button>
              ) : (
                <Key className="pointer-events-none absolute right-3 text-muted-foreground">F2</Key>
              )}
            </label>
          </div>

          <div className="scroll-thin flex shrink-0 gap-2 overflow-x-auto px-5 pb-3" role="tablist" aria-label="Categories">
            <Chip active={category === "all" && !query} onClick={() => { setCategory("all"); setQuery(""); }}>All items</Chip>
            {categories.map((c) => (
              <Chip key={c.id} active={category === c.id && !query} onClick={() => { setCategory(c.id); setQuery(""); }}>
                <MenuIcon name={c.icon} className="size-3.5" strokeWidth={2} />
                {c.name}
              </Chip>
            ))}
          </div>

          <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-5 pb-5">
            {visible.length === 0 ? (
              <EmptyState icon={Search} message={`Nothing matches "${query}"`} hint="Try part of the name, or the item code printed on the menu card." />
            ) : (
              <div className="grid grid-cols-[repeat(auto-fill,minmax(158px,1fr))] gap-3">
                {visible.map((item) => (
                  <MenuCard
                    key={item.id}
                    name={item.name}
                    desc={item.desc}
                    code={item.code}
                    price={item.price}
                    color={catById[item.categoryId].color}
                    icon={catById[item.categoryId].icon}
                    image={item.image}
                    count={qtyByItem[item.id]}
                    soldOut={item.soldOut}
                    onAdd={() => add(item)}
                  />
                ))}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Right: order */}
      {collapsed ? (
        <OrderRail
          orderNo={orderNo}
          where={orderType === "dine-in" ? table ?? "No table" : ORDER_TYPES.find((t) => t.value === orderType)!.label}
          count={lines.reduce((n, l) => n + l.qty, 0)}
          unsentQty={unsentQty}
          total={total}
          busy={busy}
          onExpand={togglePanel}
          onHold={hold}
          onKot={sendKot}
          onPay={pay}
        />
      ) : (
      <aside className="flex w-[340px] shrink-0 flex-col gap-3 xl:w-[360px]" aria-label="Current order">
        {/* Order card, orange like the reference balance card */}
        <div className="relative shrink-0 overflow-hidden rounded-2xl bg-pay p-4 text-white">
          <span aria-hidden="true" className="absolute -right-10 -top-12 size-36 rounded-full bg-white/10" />
          <span aria-hidden="true" className="absolute -right-2 top-8 size-20 rounded-full bg-white/10" />
          <div className="relative flex items-center">
            <p className="mr-auto flex items-center gap-2 text-[13px] font-medium">
              <span>{orderNo === null ? "New order" : <>Order <span className="font-mono">{orderNo}</span></>}</span>
              {resumed && <span className="rounded-full bg-white/25 px-2 py-0.5 text-[10px] font-semibold">Resumed</span>}
            </p>
            <div className="flex rounded-full bg-black/10 p-0.5" role="radiogroup" aria-label="Order type">
              {ORDER_TYPES.map(({ value, label, icon: Icon }) => (
                <button
                  key={value}
                  role="radio"
                  aria-checked={orderType === value}
                  title={label}
                  onClick={() => setOrderType(value)}
                  className={cn(
                    "flex h-7 items-center gap-1 rounded-full px-2.5 text-[11px] font-medium",
                    orderType === value ? "bg-white text-brand-deep" : "text-white/85 hover:text-white",
                  )}
                >
                  <Icon className="size-3.5" />
                  {orderType === value && label}
                </button>
              ))}
            </div>
            <button onClick={togglePanel} aria-label="Fold order panel" title="Fold order panel" className="ml-1.5 flex size-7 shrink-0 items-center justify-center rounded-full bg-black/10 text-white/90 hover:bg-black/20 hover:text-white">
              <PanelRightClose className="size-4" />
            </button>
          </div>

          {orderType === "dine-in" ? (
            <div className="relative mt-3 flex items-end justify-between">
              <div>
                <p className="text-[12px] text-white/80">Table</p>
                <p className="text-[28px] font-semibold leading-none">{table ?? "None"}</p>
              </div>
              <div className="flex items-center gap-1 rounded-full bg-black/10 p-1 text-[12px]">
                <button aria-label="Fewer guests" onClick={() => setGuests((g) => Math.max(1, g - 1))} className="flex size-6 items-center justify-center rounded-full hover:bg-white/20"><Minus className="size-3.5" /></button>
                <span className="num min-w-14 text-center">{guests} guests</span>
                <button aria-label="More guests" onClick={() => setGuests((g) => Math.min(30, g + 1))} className="flex size-6 items-center justify-center rounded-full hover:bg-white/20"><Plus className="size-3.5" /></button>
              </div>
            </div>
          ) : (
            <label className="relative mt-3 flex items-center">
              <Phone className="pointer-events-none absolute left-3 size-4 text-white/80" />
              <input
                value={customer}
                onChange={(e) => setCustomer(e.target.value)}
                placeholder={orderType === "delivery" ? "Phone or PickMe / Uber no." : "Customer name or phone"}
                aria-label="Customer"
                className="h-10 w-full rounded-lg bg-white/20 pl-9 pr-3 text-[13px] text-white outline-none placeholder:text-white/70 focus-visible:bg-white/30"
              />
            </label>
          )}

          <div className="relative mt-4 grid grid-cols-2 gap-2">
            {orderType === "dine-in" ? (
              <Popover
                open={pop === "table"}
                onOpenChange={(o) => setPop(o ? "table" : null)}
                side="left"
                className="w-[420px]"
                triggerClassName="flex h-9 items-center justify-center gap-1.5 rounded-md bg-kot text-[12px] font-medium text-white hover:bg-kot-hover"
                trigger={<><Armchair className="size-4" /> {table ? "Change table" : "Choose table"}</>}
              >
                <TablePicker floor={floor} current={table} onPick={(t) => { setTable(t); setPop(null); }} />
              </Popover>
            ) : (
              <span className="flex h-9 items-center justify-center rounded-md bg-black/10 text-[12px]">Steward: {server}</span>
            )}
            <button
              onClick={hold}
              disabled={!lines.length || busy}
              className="flex h-9 items-center justify-center gap-1.5 rounded-md bg-white text-[12px] font-medium text-brand-deep hover:bg-white/90 disabled:opacity-60"
            >
              <CirclePause className="size-4" /> Hold <Key>F9</Key>
            </button>
          </div>
        </div>

        {/* Items + totals */}
        <div className="flex min-h-0 flex-1 flex-col rounded-2xl bg-panel">
          <div className="flex items-center justify-between px-4 pb-2 pt-4">
            <h2 className="text-[14px] font-semibold">Order items</h2>
            <button
              onClick={() => { setLines((p) => p.filter((l) => l.sent)); setSelected(null); }}
              disabled={!unsent.length}
              className="text-[12px] font-medium text-pay-ink hover:underline disabled:text-muted-foreground disabled:no-underline"
            >
              Clear new items
            </button>
          </div>

          <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-3">
            {lines.length === 0 ? (
              <EmptyState icon={ShoppingCart} message="No items yet" hint="Tap Add on a dish, or type its code and press Enter." />
            ) : (
              <ul className="space-y-1">
                {lines.map((l) => {
                  const item = items[l.itemId];
                  const cat = catById[item.categoryId];
                  const sel = selected === l.key;
                  return (
                    <li key={l.key} className={cn("rounded-lg", sel && "bg-brand-soft dark:bg-muted")}>
                      <div onClick={() => setSelected(sel ? null : l.key)} className={cn("flex cursor-pointer items-center gap-2.5 rounded-lg p-1.5", !sel && "hover:bg-muted")}>
                        <DishImage src={item.image} alt="" color={cat.color} icon={cat.icon} className="size-10 shrink-0 rounded-lg" iconClassName="size-5" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[13px] font-medium">{item.name}</p>
                          <div className="mt-0.5 flex items-center gap-2 text-[11px]">
                            {l.sent ? (
                              <span className="flex items-center gap-1 rounded-full bg-success/12 px-1.5 font-medium text-success-ink"><ChefHat className="size-3" /> Sent</span>
                            ) : (
                              <span className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                                <QtyBtn label="Decrease" onClick={() => changeQty(l.key, -1)}><Minus className="size-3" /></QtyBtn>
                                <span className="num w-4 text-center font-semibold">{l.qty}</span>
                                <QtyBtn label="Increase" onClick={() => changeQty(l.key, 1)}><Plus className="size-3" /></QtyBtn>
                              </span>
                            )}
                            {l.sent && <span className="num text-muted-foreground">x {l.qty}</span>}
                            {l.note && !sel && <span className="flex min-w-0 items-center gap-0.5 text-kot-ink"><NotebookPen className="size-3 shrink-0" /><span className="truncate">{l.note}</span></span>}
                          </div>
                        </div>
                        <span className="num shrink-0 text-[13px] font-semibold">{rsExact(item.price * l.qty)}</span>
                      </div>
                      {sel && !l.sent && (
                        <div className="flex flex-wrap gap-1.5 px-1.5 pb-2">
                          <label className="relative flex w-full items-center">
                            <NotebookPen className="pointer-events-none absolute left-2.5 size-3.5 text-muted-foreground" />
                            <input
                              autoFocus
                              value={l.note}
                              onChange={(e) => patch(l.key, { note: e.target.value.slice(0, 80) })}
                              onKeyDown={(e) => { if (e.key === "Enter" || e.key === "Escape") setSelected(null); }}
                              placeholder="Note for the kitchen"
                              aria-label={`Kitchen note for ${item.name}`}
                              className="h-8 w-full rounded-md bg-panel pl-8 pr-2 text-[12px] outline-none ring-1 ring-border focus-visible:ring-pay"
                            />
                          </label>
                          {QUICK_NOTES.map((n) => (
                            <button
                              key={n}
                              onClick={() => patch(l.key, { note: l.note.includes(n) ? l.note : l.note ? `${l.note}, ${n}` : n })}
                              className="h-6 rounded-full bg-panel px-2.5 text-[11px] ring-1 ring-border hover:ring-pay"
                            >
                              {n}
                            </button>
                          ))}
                          <button
                            onClick={() => { setLines((p) => p.filter((x) => x.key !== l.key)); setSelected(null); }}
                            className="ml-auto flex h-6 items-center gap-1 rounded-full px-2 text-[11px] text-void-ink hover:bg-void/10"
                          >
                            <Trash2 className="size-3" /> Remove
                          </button>
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <div className="border-t border-line px-4 pb-4 pt-3">
            <dl className="space-y-1 text-[12px]">
              <Row label="Sub-total" value={rsExact(subtotal)} />
              <Row label={discountRate ? `Discount ${Math.round(discountRate * 100)}%` : "Discount"} value={discount ? `-${rsExact(discount)}` : "0.00"} />
              {orderType === "dine-in" && <Row label="Service charge 10%" value={rsExact(service)} />}
              <div className="flex items-baseline justify-between pt-1.5">
                <dt className="text-[14px] font-semibold">Total</dt>
                <dd className="num text-[20px] font-semibold">
                  <span className="text-pay">Rs </span>
                  {rsExact(total)}
                </dd>
              </div>
            </dl>

            <div className="mt-3 grid grid-cols-[1fr_auto] gap-2">
              <Popover
                open={pop === "discount"}
                onOpenChange={(o) => (o && !lines.length ? toast.info("Add items first.") : setPop(o ? "discount" : null))}
                side="top"
                className="w-72"
                triggerClassName="flex h-9 items-center justify-center gap-1.5 rounded-full border border-pay/60 text-[12px] font-medium text-pay-ink hover:bg-brand-soft"
                trigger={<><BadgePercent className="size-4" /> {discountRate ? "Change discount" : "Add a discount"}</>}
              >
                <DiscountPicker current={discountRate} subtotal={subtotal} onApply={(r) => { setDiscountRate(r); setPop(null); }} />
              </Popover>
              <Btn tone="outline" size="icon" className="rounded-full" aria-label="Print bill" title="Print bill" disabled={!lines.length} onClick={() => toast.info("Bill printing will work once a printer is set up.")}>
                <Printer />
              </Btn>
            </div>

            <Btn tone="kot" size="lg" className="mt-2 w-full" onClick={sendKot} disabled={!unsentQty}>
              <ChefHat /> Send to kitchen{unsentQty ? ` (${unsentQty})` : ""} <Key>F4</Key>
            </Btn>
            <Btn tone="pay" size="xl" className="mt-2 w-full justify-between shadow-[0_10px_24px_-12px_color-mix(in_oklch,var(--brand-base)_90%,transparent)]" onClick={pay} disabled={!lines.length}>
              <span className="flex items-center gap-2"><Wallet /> Pay <Key>F8</Key></span>
              <span className="num">Rs {rsExact(total)}</span>
            </Btn>
          </div>
        </div>
      </aside>
      )}

      <PaymentDialog open={payOpen} onOpenChange={setPayOpen} orderNo={orderNo ?? 0} total={total} onPaid={(m) => { toast.success(m); resetOrder(); }} />
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={cn(
        "flex h-8 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-[12px] transition-colors",
        active ? "border-pay bg-pay font-medium text-white" : "border-input text-foreground hover:border-pay hover:text-pay-ink",
      )}
    >
      {children}
    </button>
  );
}

function QtyBtn({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button aria-label={label} onClick={onClick} className="flex size-5 items-center justify-center rounded-full bg-muted text-foreground hover:bg-pay hover:text-white">
      {children}
    </button>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <dt className="italic text-muted-foreground">{label}</dt>
      <dd className="num">{value}</dd>
    </div>
  );
}

/** Orders on hold, always visible above the menu. Tap one to bring it back. */
function HeldStrip({ held, busy, onResume }: { held: HeldOrder[]; busy: boolean; onResume: (h: HeldOrder) => void }) {
  return (
    <section aria-label="Orders on hold" className="flex shrink-0 items-center gap-3 rounded-2xl bg-panel py-2.5 pl-4 pr-2">
      <span className="flex shrink-0 items-center gap-2 text-[13px] font-semibold">
        <span className="flex size-8 items-center justify-center rounded-lg bg-info/12 text-info-ink">
          <CirclePause className="size-[18px]" />
        </span>
        On hold
        <span className="num flex h-5 min-w-5 items-center justify-center rounded-full bg-info px-1 text-[11px] text-white">{held.length}</span>
      </span>
      <div className="scroll-thin flex min-w-0 flex-1 gap-2 overflow-x-auto pb-0.5">
        {held.map((h) => {
          const count = h.lines.reduce((s, l) => s + l.qty, 0);
          const where = h.type === "dine-in" ? (h.table ? `Table ${h.table}` : "No table") : h.type === "takeaway" ? "Take Away" : "Delivery";
          return (
            <button
              key={h.id}
              onClick={() => onResume(h)}
              disabled={busy}
              title={`Continue order ${h.orderNo}`}
              className="group flex shrink-0 items-center gap-3 rounded-xl border border-info/30 bg-info/[0.06] py-1.5 pl-3 pr-2 text-left transition-colors hover:border-info hover:bg-info/12 disabled:opacity-60"
            >
              <span className="leading-tight">
                <span className="block text-[13px] font-semibold">
                  {where} <span className="font-mono text-[11px] font-normal text-muted-foreground">{h.orderNo}</span>
                </span>
                <span className="block text-[11px] text-muted-foreground">
                  {count} item{count === 1 ? "" : "s"}, Rs {rsExact(h.total)}, <TimeAgo date={h.heldAt} /> by {h.heldBy}
                </span>
              </span>
              <span className="flex h-7 items-center gap-1 rounded-full bg-info px-2.5 text-[11px] font-medium text-white group-hover:bg-info-hover">
                <Play className="size-3" fill="currentColor" /> Resume
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

/** The order panel folded into a thin bar: what's on the order, and the main actions. */
function OrderRail({
  orderNo,
  where,
  count,
  unsentQty,
  total,
  busy,
  onExpand,
  onHold,
  onKot,
  onPay,
}: {
  orderNo: number | null;
  where: string;
  count: number;
  unsentQty: number;
  total: number;
  busy: boolean;
  onExpand: () => void;
  onHold: () => void;
  onKot: () => void;
  onPay: () => void;
}) {
  return (
    <aside className="flex w-[84px] shrink-0 flex-col gap-3" aria-label="Current order (folded)">
      <button
        onClick={onExpand}
        title="Open order panel"
        className="relative flex shrink-0 flex-col items-center gap-1 overflow-hidden rounded-2xl bg-pay px-1 pb-3 pt-2.5 text-white hover:bg-pay-hover"
      >
        <span aria-hidden="true" className="absolute -right-6 -top-6 size-16 rounded-full bg-white/10" />
        <span className="relative mb-1 flex size-7 items-center justify-center rounded-full bg-black/10">
          <PanelRightOpen className="size-4" />
        </span>
        <span className="relative text-[10px] text-white/80">{orderNo === null ? "New" : "Order"}</span>
        {orderNo !== null && <span className="relative font-mono text-[13px] font-semibold leading-none">{orderNo}</span>}
        <span className="relative mt-1 max-w-full truncate rounded-full bg-black/10 px-1.5 py-0.5 text-[10px] font-medium">{where}</span>
      </button>

      <div className="flex min-h-0 flex-1 flex-col items-center gap-2 rounded-2xl bg-panel px-2 py-3">
        <button onClick={onExpand} title="Show order items" className="relative flex size-11 items-center justify-center rounded-xl bg-muted text-foreground hover:bg-line">
          <ShoppingCart className="size-5" />
          {count > 0 && (
            <span className="num absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-pay px-1 text-[11px] font-semibold text-white" aria-label={`${count} items`}>
              {count}
            </span>
          )}
        </button>
        <span className="text-[10px] text-muted-foreground">{count === 1 ? "1 item" : `${count} items`}</span>

        <div className="mt-auto flex w-full flex-col items-center gap-2">
          <div className="text-center">
            <p className="text-[10px] text-muted-foreground">Total</p>
            <p className="num text-[12px] font-semibold leading-tight">
              <span className="text-pay">Rs</span> {rsExact(total)}
            </p>
          </div>
          <RailBtn label="Hold (F9)" className="bg-info/12 text-info-ink hover:bg-info/20" disabled={!count || busy} onClick={onHold}>
            <CirclePause className="size-5" />
          </RailBtn>
          <RailBtn label={`Send to kitchen (F4)${unsentQty ? `, ${unsentQty} new` : ""}`} className="bg-kot text-white hover:bg-kot-hover" disabled={!unsentQty} onClick={onKot}>
            <ChefHat className="size-5" />
            {unsentQty > 0 && <span className="num absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-panel px-1 text-[11px] font-semibold text-kot-ink ring-1 ring-kot/30">{unsentQty}</span>}
          </RailBtn>
          <RailBtn label="Pay (F8)" className="h-14 bg-pay text-white shadow-[0_10px_24px_-12px_color-mix(in_oklch,var(--brand-base)_90%,transparent)] hover:bg-pay-hover" disabled={!count} onClick={onPay}>
            <Wallet className="size-5" />
            <span className="text-[10px] font-semibold">Pay</span>
          </RailBtn>
        </div>
      </div>
    </aside>
  );
}

function RailBtn({ label, className, children, ...props }: React.ComponentProps<"button"> & { label: string }) {
  return (
    <button
      aria-label={label}
      title={label}
      className={cn("relative flex h-11 w-full flex-col items-center justify-center gap-0.5 rounded-xl transition-colors disabled:pointer-events-none disabled:opacity-45", className)}
      {...props}
    >
      {children}
    </button>
  );
}
