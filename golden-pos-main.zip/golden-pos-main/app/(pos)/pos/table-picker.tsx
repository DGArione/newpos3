"use client";

import { cn } from "@/lib/utils";
import type { Area, TableStatus } from "@/lib/mock/floor";
import { StatusDot, statusTone, type Status } from "@/components/pos/status-badge";

export const TABLE_STATUS_KEY: Record<TableStatus, Status> = {
  free: "available",
  seated: "occupied",
  bill: "bill_printed",
  cleaning: "cleaning",
};

export function TablePicker({ floor, current, onPick }: { floor: Area[]; current: string | null; onPick: (id: string) => void }) {
  return (
    <div className="space-y-3">
      {floor.map((area) => (
        <section key={area.id}>
          <h3 className="mb-1 text-[12px] font-semibold text-muted-foreground">{area.name}</h3>
          <div className="grid grid-cols-6 gap-1">
            {area.tables.map((t) => {
              const st = TABLE_STATUS_KEY[t.status];
              return (
                <button
                  key={t.id}
                  onClick={() => onPick(t.id)}
                  title={`${t.id}, ${t.seats} seats`}
                  className={cn(
                    "flex h-12 flex-col items-center justify-center rounded border text-[13px] font-bold",
                    statusTone(st).tile,
                    current === t.id && "ring-2 ring-ring",
                  )}
                >
                  {t.label}
                  <StatusDot status={st} className="mt-0.5 size-1.5" />
                </button>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
