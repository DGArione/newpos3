"use client";

import { useSyncExternalStore } from "react";
import { format } from "date-fns";

const subscribe = (onChange: () => void) => {
  const id = setInterval(onChange, 10_000);
  return () => clearInterval(id);
};
const getMinute = () => Math.floor(Date.now() / 60_000);
const getServerMinute = () => null;

/** Live clock. Renders blank on the server so markup matches. */
export function Clock({ pattern = "d MMM yyyy  h:mm a", className }: { pattern?: string; className?: string }) {
  const minute = useSyncExternalStore(subscribe, getMinute, getServerMinute);
  if (minute === null) return <span className={className}>&nbsp;</span>;
  const now = new Date(minute * 60_000);
  return (
    <time dateTime={now.toISOString()} className={className} style={{ whiteSpace: "pre" }}>
      {format(now, pattern)}
    </time>
  );
}
