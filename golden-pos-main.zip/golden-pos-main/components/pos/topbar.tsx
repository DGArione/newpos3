"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ChefHat,
  LayoutGrid,
  Lock,
  Moon,
  Printer,
  ReceiptText,
  Search,
  ShoppingCart,
  Sun,
  TrendingUp,
  Users,
  Wifi,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Area } from "@/lib/auth/roles";
import { LogoMark } from "./logo";
import { Clock } from "./clock";
import { Identity } from "./identity";
import { CommandPalette } from "./command-palette";
import { useToggleTheme } from "./use-theme";

const MODULES: { area: Area; href: string; label: string; icon: LucideIcon }[] = [
  { area: "pos", href: "/pos", label: "Billing", icon: ShoppingCart },
  { area: "tables", href: "/tables", label: "Tables", icon: LayoutGrid },
  { area: "orders", href: "/orders", label: "Orders", icon: ReceiptText },
  { area: "kitchen", href: "/kitchen", label: "KOT", icon: ChefHat },
  { area: "reports", href: "/reports", label: "Reports", icon: TrendingUp },
  { area: "staff", href: "/staff", label: "Users", icon: Users },
];

export function TopBar({
  areas,
  name,
  roleLabel,
  tables,
  signOut,
}: {
  areas: Area[];
  name: string;
  roleLabel: string;
  tables: { id: string; area: string }[];
  signOut: () => Promise<void>;
}) {
  const pathname = usePathname();
  const lockForm = useRef<HTMLFormElement>(null);
  const [palette, setPalette] = useState(false);
  const toggleTheme = useToggleTheme();
  const lock = useCallback(() => lockForm.current?.requestSubmit(), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "F10") { e.preventDefault(); lock(); }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPalette((p) => !p); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lock]);

  return (
    <header className="flex h-12 shrink-0 items-stretch border-b border-black/20 bg-bar text-bar-foreground">
      <div className="flex items-center gap-2.5 border-r border-white/10 px-3.5">
        <LogoMark className="size-7" />
        <span className="hidden text-[15px] font-semibold text-white 2xl:block">Golden Beach</span>
      </div>

      <nav aria-label="Modules" className="flex items-stretch">
        {MODULES.filter((m) => areas.includes(m.area)).map(({ href, label, icon: Icon }) => {
          const active = pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center gap-2 border-b-2 px-3 pt-0.5 text-[13px] font-medium transition-colors xl:px-4",
                active ? "border-brand bg-bar-2 text-white" : "border-transparent text-bar-foreground/75 hover:bg-white/5 hover:text-white",
              )}
            >
              <Icon className="size-4" strokeWidth={1.75} />
              {label}
            </Link>
          );
        })}
      </nav>

      <button
        onClick={() => setPalette(true)}
        className="mx-3 my-2 hidden min-w-44 items-center gap-2 rounded-md border border-white/10 bg-white/5 px-2.5 text-[12px] text-bar-foreground/70 hover:bg-white/10 lg:flex"
      >
        <Search className="size-3.5" />
        <span className="flex-1 text-left">Search</span>
        <kbd className="rounded border border-white/15 px-1 text-[10px]">Ctrl K</kbd>
      </button>

      <div className="ml-auto flex items-center text-[12px]">
        <span className="flex items-center gap-1.5 px-2.5" title="Server: online">
          <Wifi className="size-4 text-pay" strokeWidth={2} />
          <span className="hidden xl:inline">Online</span>
        </span>
        <span className="flex items-center gap-1.5 border-l border-white/10 px-2.5" title="Receipt printer: ready">
          <Printer className="size-4 text-pay" strokeWidth={2} />
          <span className="hidden xl:inline">Printer</span>
        </span>
        <Clock className="num hidden border-l border-white/10 px-3 xl:block" />
        <button onClick={toggleTheme} title="Switch light / dark" aria-label="Switch light or dark theme" className="flex h-full items-center border-l border-white/10 px-3 hover:bg-white/5">
          <Moon className="size-4 dark:hidden" />
          <Sun className="hidden size-4 dark:block" />
        </button>
        <span className="flex h-full items-center border-l border-white/10 px-3 text-white">
          <Identity name={name} sub={roleLabel} tone="bar" />
        </span>
        <form ref={lockForm} action={signOut} className="flex">
          <button type="submit" title="Lock terminal (F10)" className="flex items-center gap-1.5 border-l border-white/10 px-4 font-medium hover:bg-void hover:text-white">
            <Lock className="size-4" />
            Lock
          </button>
        </form>
      </div>

      <CommandPalette open={palette} onOpenChange={setPalette} areas={areas} tables={tables} onLock={lock} />
    </header>
  );
}
