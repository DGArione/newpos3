"use client";

import { RotateCcw, ServerCrash } from "lucide-react";

export default function ErrorScreen({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-background p-6">
      <div className="w-full max-w-md overflow-hidden rounded-lg border border-border bg-panel">
        <div className="flex h-11 items-center gap-2 bg-void px-4 font-semibold text-white">
          <ServerCrash className="size-5" /> Something went wrong
        </div>
        <div className="space-y-3 p-4 text-[14px]">
          <p>The terminal could not complete the last action. Check that the server PC is on and connected, then try again.</p>
          <p className="text-[12px] text-muted-foreground">Error code: {error.digest ?? "unknown"}</p>
          <button onClick={reset} className="flex h-10 items-center gap-2 rounded-md bg-bar px-4 font-semibold text-white hover:bg-bar-2">
            <RotateCcw className="size-4" /> Try again
          </button>
        </div>
      </div>
    </div>
  );
}
