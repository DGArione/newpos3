# Golden POS Component Index

Update this file and `/design-guide` when you add or change a shared component.

## Primitives

| Component | File | Props | Notes |
|---|---|---|---|
| Btn | `components/pos/button.tsx` | `tone` outline, ghost, primary, pay, kot, info, void, void-outline; `size` sm, md, lg, xl, icon | CVA. `btn()` exported for links styled as buttons. |
| Key | `components/pos/button.tsx` | children | Shortcut hint on buttons: `<Key>F8</Key>`. |
| Modal | `components/ui/sheet-dialog.tsx` | open, onOpenChange, title, icon, description | Full-attention steps only. |
| Popover | `components/ui/popover.tsx` | open, onOpenChange, trigger, side, align | Quick contextual edits. |

## Composites

| Component | File | Usage |
|---|---|---|
| StatusBadge / StatusDot / statusTone | `components/pos/status-badge.tsx` | Every status in the app. |
| MetricCard | `components/pos/metric-card.tsx` | Numbers strip: wrap in `grid gap-px bg-border`. |
| EmptyState | `components/pos/empty-state.tsx` | Empty lists: icon, message, hint telling what to do. |
| Identity | `components/pos/identity.tsx` | Initials + name (+ role/email). `tone="bar"` in the top bar. |
| RoleBadge | `components/pos/role-badge.tsx` | Role with its icon. |
| Segmented | `components/pos/segmented.tsx` | Mode/filter switch with optional icon and count. |
| MenuCard / DishImage | `components/pos/menu-card.tsx` | Menu card with photo slot, description, price, Add. DishImage = photo or placeholder. |
| ItemTile | `components/pos/item-tile.tsx` | Compact menu key (no photo), kept for dense layouts. |
| Screen | `components/pos/screen.tsx` | Rounded card that holds a whole screen. |
| Sidebar / AppHeader / Shell | `components/pos/sidebar.tsx`, `app-header.tsx`, `shell.tsx` | App frame, greeting header, Ctrl+K and F10 wiring. Module list in `nav.ts`. |
| MenuIcon | `components/pos/menu-icon.tsx` | Category icons in the billing sidebar. |
| PageHeader | `components/pos/page-header.tsx` | Title strip on list/admin screens. |
| CommandPalette | `components/pos/command-palette.tsx` | Ctrl+K: modules, tables, terminal actions. |
| Clock | `components/pos/clock.tsx` | Live clock, `pattern` uses date-fns. |
| ImageField | `components/pos/image-field.tsx` | Photo picker with preview, Change/Remove, drag and drop. Pair with `resolvePhoto()` on the server. |
| BrandMark / BrandName | `components/pos/brand.tsx` | Uploaded logo or built-in mark; name with first word in the brand colour. |
| TimeAgo | `components/pos/time-ago.tsx` | "just now", "4 minutes ago", refreshes itself. |
| HomeBanners | `app/(pos)/pos/home-banners.tsx` | Billing banner carousel from Settings. |
| HeldStrip | `app/(pos)/pos/order-screen.tsx` | On hold bar with Resume buttons. |
| Field / inputClass | `components/pos/field.tsx` | Form label, hint and error. |

## Billing parts (`app/(pos)/pos/`)

| Part | File |
|---|---|
| OrderScreen | `order-screen.tsx` |
| PaymentDialog | `payment-dialog.tsx` |
| TablePicker, TABLE_STATUS_KEY | `table-picker.tsx` |
| DiscountPicker | `discount-picker.tsx` |

## Utilities

| Name | File | Use |
|---|---|---|
| cn | `lib/utils.ts` | Class merging. |
| rs, rsExact, pct, SERVICE_CHARGE_RATE | `lib/money.ts` | All money is integer cents. |
| useToggleTheme | `components/pos/use-theme.ts` | Switch and remember theme. |
| keepFormOnSubmit | `lib/use-keep-form.ts` | Keep form values after server errors. |
