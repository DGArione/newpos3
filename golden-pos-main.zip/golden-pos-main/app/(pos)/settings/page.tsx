import type { Metadata } from "next";
import { Settings } from "lucide-react";
import { requireArea } from "@/lib/auth/session";
import { menuStore, settingsStore } from "@/lib/store";
import { PageHeader } from "@/components/pos/page-header";
import { Screen } from "@/components/pos/screen";
import { BrandingForm, BannerManager, ColorToneForm } from "./settings-forms";
import { DEFAULT_BRAND_COLOR, isHex } from "@/lib/brand-color";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage() {
  await requireArea("settings");
  const [branding, banners, items] = await Promise.all([settingsStore.branding(), settingsStore.banners(), menuStore.items()]);

  return (
    <Screen>
      <PageHeader title="Settings" icon={Settings} meta="Logo, colour, pictures and home page" />
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto bg-background/60 p-4">
        <div className="mx-auto grid max-w-5xl gap-4">
          <BrandingForm branding={branding} />
          <ColorToneForm key={branding.brandColor ?? "default"} saved={branding.brandColor && isHex(branding.brandColor) ? branding.brandColor : DEFAULT_BRAND_COLOR} />
          <BannerManager banners={banners} items={items.map((i) => ({ id: i.id, name: i.name, code: i.code, image: i.image }))} />
        </div>
      </div>
    </Screen>
  );
}
