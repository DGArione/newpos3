import type { Metadata } from "next";
import { Banknote, ChefHat, CirclePause, Palette, Printer, ReceiptText, Search } from "lucide-react";
import { requireArea } from "@/lib/auth/session";
import { PageHeader } from "@/components/pos/page-header";
import { Screen } from "@/components/pos/screen";
import { Btn, Key } from "@/components/pos/button";
import { StatusBadge, StatusDot, STATUSES, type Status } from "@/components/pos/status-badge";
import { MetricCard } from "@/components/pos/metric-card";
import { EmptyState } from "@/components/pos/empty-state";
import { Identity } from "@/components/pos/identity";
import { RoleBadge } from "@/components/pos/role-badge";
import { ItemTile } from "@/components/pos/item-tile";
import { MenuCard } from "@/components/pos/menu-card";
import { ROLES } from "@/lib/auth/roles";
import { SegmentedDemo } from "./segmented-demo";

export const metadata: Metadata = { title: "Design guide" };

const COLORS: { token: string; use: string }[] = [
  { token: "background", use: "App background" },
  { token: "panel", use: "Panels, tables, tiles" },
  { token: "muted", use: "Table heads, totals" },
  { token: "accent", use: "Hover / selected row" },
  { token: "border", use: "All borders" },
  { token: "brand-soft", use: "Menu cards, selected line" },
  { token: "selected", use: "Active chip, primary button" },
  { token: "pay", use: "Brand colour (set in Settings): Pay, Add, active" },
  { token: "brand-deep", use: "Brand-coloured text on white or soft" },
  { token: "kot", use: "Kitchen actions, shift card" },
  { token: "success", use: "Ready, available, sent" },
  { token: "info", use: "Hold, selection" },
  { token: "void", use: "Void, errors, locked" },
  { token: "warn", use: "New kitchen tickets" },
];

const TYPE: { name: string; cls: string; sample: string }[] = [
  { name: "Page title", cls: "text-[16px] font-semibold", sample: "Orders" },
  { name: "Panel title", cls: "text-[14px] font-semibold", sample: "Order 1049" },
  { name: "Body", cls: "text-[13px]", sample: "Cheese Seafood Kottu" },
  { name: "Label", cls: "text-[12px] text-muted-foreground", sample: "Steward" },
  { name: "Identifier", cls: "font-mono text-[12px]", sample: "1049   301   3001" },
  { name: "Money", cls: "num text-[13px] font-semibold", sample: "2,100.00" },
  { name: "Grand total", cls: "num text-[22px] font-bold", sample: "Rs. 9,207.00" },
];

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="border-b border-border bg-panel">
      <h2 className="border-b border-line px-4 py-2 text-[14px] font-semibold">{title}</h2>
      <div className="space-y-4 p-4">{children}</div>
    </section>
  );
}

function Sub({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-2 text-[12px] text-muted-foreground">{title}</p>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}

export default async function DesignGuidePage() {
  await requireArea("design");

  return (
    <Screen>
      <PageHeader title="Design guide" icon={Palette} meta="Every shared component, in every state. Add new ones here." />
      <div className="scroll-thin flex-1 space-y-3 overflow-y-auto p-3">
        <Section title="Colours">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-6">
            {COLORS.map((c) => (
              <div key={c.token} className="overflow-hidden rounded-md border border-border">
                <div className="h-10" style={{ background: `var(--${c.token})` }} />
                <div className="px-2 py-1.5">
                  <p className="font-mono text-[12px]">--{c.token}</p>
                  <p className="text-[11px] text-muted-foreground">{c.use}</p>
                </div>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Typography">
          <table className="text-left">
            <tbody>
              {TYPE.map((t) => (
                <tr key={t.name} className="border-b border-line last:border-0">
                  <td className="w-36 py-1.5 pr-4 text-[12px] text-muted-foreground">{t.name}</td>
                  <td className={`py-1.5 pr-6 ${t.cls}`}>{t.sample}</td>
                  <td className="py-1.5 font-mono text-[11px] text-muted-foreground">{t.cls}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Section>

        <Section title="Buttons">
          <Sub title="Tones">
            <Btn>Outline</Btn>
            <Btn tone="primary">Primary</Btn>
            <Btn tone="pay"><Banknote /> Pay</Btn>
            <Btn tone="kot"><ChefHat /> KOT</Btn>
            <Btn tone="info"><CirclePause /> Hold</Btn>
            <Btn tone="void">Void</Btn>
            <Btn tone="void-outline">Deactivate</Btn>
            <Btn tone="ghost">Ghost</Btn>
          </Sub>
          <Sub title="Sizes">
            <Btn size="sm">Small</Btn>
            <Btn size="md">Medium</Btn>
            <Btn size="lg"><Printer /> Large</Btn>
            <Btn size="xl" tone="pay"><Banknote /> Pay <Key>F8</Key></Btn>
            <Btn size="icon" aria-label="Search"><Search /></Btn>
          </Sub>
          <Sub title="States">
            <Btn tone="pay" disabled>Disabled</Btn>
            <span className="text-[12px] text-muted-foreground">Focus ring shows on keyboard focus only.</span>
          </Sub>
        </Section>

        <Section title="Status">
          <Sub title="StatusBadge">
            {(Object.keys(STATUSES) as Status[]).map((s) => <StatusBadge key={s} status={s} />)}
          </Sub>
          <Sub title="StatusDot">
            {(Object.keys(STATUSES) as Status[]).map((s) => (
              <span key={s} className="flex items-center gap-1.5 text-[12px]"><StatusDot status={s} />{STATUSES[s].label}</span>
            ))}
          </Sub>
        </Section>

        <Section title="Controls">
          <Sub title="Segmented"><SegmentedDemo /></Sub>
          <Sub title="Key"><Key>F2</Key><Key>F4</Key><Key>F8</Key><Key>Ctrl K</Key></Sub>
        </Section>

        <Section title="Menu card">
          <div className="grid w-[720px] max-w-full grid-cols-4 gap-3">
            <MenuCard name="Chicken Kottu" desc="Chopped roti, chicken, egg and leeks" code={301} price={135000} color="#b3442a" icon="kottu" />
            <MenuCard name="Cheese Seafood Kottu" desc="Prawns, cuttlefish and melted cheese" code={302} price={210000} color="#b3442a" icon="kottu" count={2} />
            <MenuCard name="Lagoon Crab Pepper" desc="Lagoon crab in black pepper sauce" code={203} price={560000} color="#2a7d8f" icon="seafood" soldOut />
            <MenuCard name="King Coconut" desc="Served in the shell" code={501} price={45000} color="#3a68ad" icon="drinks" />
          </div>
        </Section>

        <Section title="Item tile (compact)">
          <div className="grid w-[600px] max-w-full grid-cols-4 gap-1.5">
            <ItemTile name="Chicken Kottu" code={301} price={135000} color="#b3442a" />
            <ItemTile name="Cheese Seafood Kottu" code={302} price={210000} color="#b3442a" count={2} />
            <ItemTile name="Lagoon Crab Pepper" code={203} price={560000} color="#2a7d8f" soldOut />
            <ItemTile name="King Coconut" code={501} price={45000} color="#3a68ad" />
          </div>
        </Section>

        <Section title="People">
          <Sub title="Identity">
            <Identity name="Ruwan Fernando" sub="Waiter" />
            <Identity name="Nadeesha Perera" size="sm" />
          </Sub>
          <Sub title="RoleBadge">{ROLES.map((r) => <RoleBadge key={r} role={r} />)}</Sub>
        </Section>

        <Section title="Metric card and empty state">
          <div className="grid gap-px overflow-hidden rounded-md border border-border bg-border md:grid-cols-3">
            <MetricCard icon={ReceiptText} label="Orders today" value="11" />
            <MetricCard icon={Banknote} label="Collected" value="Rs. 28,360.00" description="3 bills settled" />
            <div className="bg-panel"><EmptyState icon={ReceiptText} message="No orders here" hint="Change the filter or clear the search." /></div>
          </div>
        </Section>
      </div>
    </Screen>
  );
}
