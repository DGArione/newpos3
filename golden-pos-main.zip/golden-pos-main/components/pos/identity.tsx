import { cn } from "@/lib/utils";

const initials = (name: string) =>
  name.split(/\s+/).filter((p) => /^[a-z]/i.test(p)).map((p) => p[0]).slice(0, 2).join("").toUpperCase();

/** Avatar initials + name, for any reference to a staff member. */
export function Identity({
  name,
  sub,
  size = "md",
  tone = "default",
  className,
}: {
  name: string;
  sub?: string;
  size?: "sm" | "md";
  tone?: "default" | "bar";
  className?: string;
}) {
  const onBar = tone === "bar";
  return (
    <span className={cn("inline-flex min-w-0 items-center gap-2", className)}>
      <span
        aria-hidden="true"
        className={cn(
          "flex shrink-0 items-center justify-center rounded-full font-semibold",
          onBar ? "bg-white/10 text-white" : "bg-accent text-accent-foreground",
          size === "sm" ? "size-6 text-[10px]" : "size-7 text-[11px]",
        )}
      >
        {initials(name)}
      </span>
      <span className={cn("min-w-0 leading-tight", onBar && "hidden lg:block")}>
        <span className="block max-w-36 truncate font-medium">{name}</span>
        {sub && <span className={cn("block truncate text-[11px]", onBar ? "text-bar-foreground/60" : "text-muted-foreground")}>{sub}</span>}
      </span>
    </span>
  );
}
