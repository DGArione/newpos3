# Golden Beach POS

Restaurant point of sale for Golden Beach. Next.js 16, TypeScript, Tailwind 4.
Built to run on a PC in the restaurant first, then move to local + cloud later.

## Run it

Needs **Node.js 22+**. No database needed yet.

```
npm install
npm run dev
```

Open http://localhost:3000

## Logins

| User ID | Name              | Role    | PIN  |
|---------|-------------------|---------|------|
| 1001    | Owner             | Owner   | 2580 |
| 1002    | Nadeesha Perera   | Manager | 3691 |
| 2001    | Kasun Silva       | Cashier | 4826 |
| 3001    | Ruwan Fernando    | Waiter  | 5937 |
| 3002    | Ishara Jayasinghe | Waiter  | 6048 |
| 4001    | Mahesh Kumara     | Kitchen | 7159 |

Back office: `owner@goldenbeach.lk` or `manager@goldenbeach.lk`, password `ChangeMe!2026`.

## Keyboard

| Key | Action |
|-----|--------|
| F2  | Search item (type a code like `301` + Enter to add it) |
| F4  | Send KOT |
| F8  | Pay |
| F9  | Hold order |
| F10 | Lock terminal |
| Ctrl+K | Command palette: jump to a module, open a table, switch theme, lock |

## Owner and manager screens

- **Menu**: add, edit and delete dishes and categories, upload a photo for each dish
  (JPG, PNG or WebP, up to 5 MB), set prices, kitchen station, and switch items to sold out.
- **Settings**: restaurant name and tagline, logo, the picture in the login card, a full-screen
  background photo behind the login page, the **system colour** (8 presets or any custom colour,
  previewed live before saving; colours too pale for white button text are refused), and the
  **home page banners** shown at the top of Billing (picture, title, text, and an optional dish
  for the "Add to order" button). Several banners can be flicked through with the arrows.

## Orders on hold

Press **Hold** (or F9) to park an order. Held orders show in the **On hold** bar above the menu
(table, items, total, how long ago, who held it), and as a number on Billing in the side menu.
Tap **Resume** to bring one back. If you already have items on screen, that order is held first,
so nothing is lost. Held orders are saved, so they survive a restart.

## Where data is kept

Everything is saved in the `data` folder next to the app:
`data/golden-pos.json` (staff, menu, settings, held orders) and `data/uploads` (photos).
**Back up the whole `data` folder.** Delete it to start again with the starter menu and staff.
Set `DATA_DIR` in `.env.local` to keep it somewhere else.

## What works now

- Staff PIN login and back-office email login, 5 wrong tries locks the account for 15 min.
- Each role only sees its modules: Waiter (Billing, Tables), Cashier (+ Orders),
  Kitchen (KOT only), Manager/Owner (everything incl. Users, Reports).
- Billing: categories, item grid with codes, order table, notes, discount, void, hold,
  KOT, table picker, cash/card payment with keypad and balance.
- Tables, Orders, KOT board, Users (add user, reset PIN, unlock, deactivate, login activity).

## Not connected yet

- **Data is a JSON file** (`lib/store/index.ts`), not a database yet. Tables, open/paid orders and
  kitchen tickets are still sample data in `lib/mock/`.
- Printers, cash drawer, PayHere and reports come with the database phase.
- `prisma/` holds the database schema for that phase. Nothing uses it yet.

## Design

- Light theme by default, orange accent; switch to dark with the moon button in the header (remembered per terminal).
- **Menu photos:** upload them on the **Menu** screen (Edit, then Add photo). Until then a placeholder is shown.
- The **sidebar** can be collapsed to icons with the button next to the logo; each terminal remembers it.
- Owners and managers can open **Design guide** from Ctrl+K: every colour, button, status and
  component in one page.
- Design rules for Claude Code are in `skills-to-install/golden-pos-design/`. To activate them:
  ```powershell
  New-Item -ItemType Directory -Force .claude\skills | Out-Null
  Move-Item skills-to-install\* .claude\skills\
  Remove-Item skills-to-install
  ```

## Clean-up from earlier versions

These files are no longer used and can be deleted:
```powershell
Remove-Item app\fonts\bricolage-grotesque.woff2, app\fonts\public-sans.woff2, app\fonts\ibm-plex-mono-*.woff2, components\pos\rail.tsx, components\pos\topbar.tsx, components\pos\statusbar.tsx, "app\(pos)\pos\note-dialog.tsx", "app\(pos)\pos\table-dialog.tsx", "app\(pos)\pos\discount-dialog.tsx" -ErrorAction SilentlyContinue
```
