"use client";

import { useSyncExternalStore } from "react";
import { formatDistanceStrict } from "date-fns";

const subscribe = (cb: () => void) => {
  const id = setInterval(cb, 15_000);
  return () => clearInterval(id);
};
const getNow = () => Math.floor(Date.now() / 15_000) * 15_000;
const getServerNow = () => null;

/** "just now", "4 minutes ago" — refreshes on its own. */
export function TimeAgo({ date }: { date: Date | string }) {
  const now = useSyncExternalStore(subscribe, getNow, getServerNow);
  const then = new Date(date);
  if (now === null) return null;
  if (now - then.getTime() < 60_000) return <>just now</>;
  return <>{formatDistanceStrict(then, now)} ago</>;
}
