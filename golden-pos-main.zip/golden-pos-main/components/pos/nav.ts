import {
  ChefHat,
  LayoutGrid,
  BookOpenText,
  Palette,
  Settings,
  ReceiptText,
  ShoppingCart,
  TrendingUp,
  Users,
  type LucideIcon,
} from "lucide-react";
import type { Area } from "@/lib/auth/roles";

// Each module keeps its own colour so staff find it by colour as well as by name.
export const MODULES: { area: Area; href: string; label: string; icon: LucideIcon; color: string; inNav: boolean }[] = [
  { area: "pos", href: "/pos", label: "Billing", icon: ShoppingCart, color: "var(--brand-base)", inNav: true },
  { area: "tables", href: "/tables", label: "Tables", icon: LayoutGrid, color: "#f52121", inNav: true },
  { area: "orders", href: "/orders", label: "Orders", icon: ReceiptText, color: "#5b88fc", inNav: true },
  { area: "kitchen", href: "/kitchen", label: "Kitchen (KOT)", icon: ChefHat, color: "#35c344", inNav: true },
  { area: "reports", href: "/reports", label: "Reports", icon: TrendingUp, color: "#9d61e8", inNav: true },
  { area: "menu", href: "/menu", label: "Menu", icon: BookOpenText, color: "#d9772b", inNav: true },
  { area: "staff", href: "/staff", label: "Users", icon: Users, color: "#7471f6", inNav: true },
  { area: "settings", href: "/settings", label: "Settings", icon: Settings, color: "#515151", inNav: true },
  { area: "design", href: "/design-guide", label: "Design guide", icon: Palette, color: "#808080", inNav: false },
];
