import "server-only";
import bcrypt from "bcryptjs";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import type { AuthMethod, Role } from "@/lib/auth/roles";
import type { Banner, Branding, Category, HeldOrder, MenuItem } from "@/lib/types/menu";
import { categories as seedCategories, menu as seedMenu } from "@/lib/mock/menu";

/*
 * Local data store, saved to data/golden-pos.json (no database yet).
 *
 * Every function is async and shaped like a database call, so switching to
 * Prisma/Postgres later means rewriting this one file. The file is written
 * after every change (debounced), so menu edits, photos, settings and held
 * orders survive a restart. Back up the whole data/ folder.
 */

export type Staff = {
  id: string;
  staffCode: string;
  name: string;
  role: Role;
  pinHash: string;
  email: string | null;
  passwordHash: string | null;
  active: boolean;
  failedAttempts: number;
  lockedUntil: Date | null;
  lastLoginAt: Date | null;
  createdAt: Date;
};

export type Session = {
  id: string;
  tokenHash: string;
  userId: string;
  method: AuthMethod;
  terminal: string;
  createdAt: Date;
  lastSeenAt: Date;
  expiresAt: Date;
  revokedAt: Date | null;
};

export type AuthEventType =
  | "LOGIN_SUCCESS"
  | "LOGIN_FAILED"
  | "ACCOUNT_LOCKED"
  | "LOGOUT"
  | "PIN_RESET"
  | "USER_CREATED"
  | "USER_DEACTIVATED"
  | "USER_REACTIVATED"
  | "USER_UNLOCKED";

export type AuthEvent = {
  id: string;
  type: AuthEventType;
  method: AuthMethod | null;
  userId: string | null;
  actorId: string | null;
  staffCode: string | null;
  terminal: string;
  createdAt: Date;
};

type Data = {
  version: 1;
  staff: Staff[];
  sessions: Session[];
  events: AuthEvent[];
  categories: Category[];
  items: MenuItem[];
  branding: Branding;
  banners: Banner[];
  held: HeldOrder[];
  nextOrderNo: number;
};

const DATA_DIR = process.env.DATA_DIR ?? path.join(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIR, "golden-pos.json");
export const UPLOAD_DIR = path.join(DATA_DIR, "uploads");

// Starter team. Change these PINs after the first sign-in.
const SEED_STAFF: { staffCode: string; name: string; role: Role; pin: string; email?: string; password?: string }[] = [
  { staffCode: "1001", name: "Owner", role: "OWNER", pin: "2580", email: "owner@goldenbeach.lk", password: "ChangeMe!2026" },
  { staffCode: "1002", name: "Nadeesha Perera", role: "MANAGER", pin: "3691", email: "manager@goldenbeach.lk", password: "ChangeMe!2026" },
  { staffCode: "2001", name: "Kasun Silva", role: "CASHIER", pin: "4826" },
  { staffCode: "3001", name: "Ruwan Fernando", role: "WAITER", pin: "5937" },
  { staffCode: "3002", name: "Ishara Jayasinghe", role: "WAITER", pin: "6048" },
  { staffCode: "4001", name: "Mahesh Kumara", role: "KITCHEN", pin: "7159" },
];

function seed(): Data {
  const now = new Date();
  return {
    version: 1,
    staff: SEED_STAFF.map((s) => ({
      id: randomUUID(),
      staffCode: s.staffCode,
      name: s.name,
      role: s.role,
      pinHash: bcrypt.hashSync(s.pin, 10),
      email: s.email ?? null,
      passwordHash: s.password ? bcrypt.hashSync(s.password, 10) : null,
      active: true,
      failedAttempts: 0,
      lockedUntil: null,
      lastLoginAt: null,
      createdAt: now,
    })),
    sessions: [],
    events: [],
    categories: seedCategories.map((c) => ({ ...c })),
    items: seedMenu.map((m) => ({ ...m })),
    branding: { restaurantName: "Golden Beach", tagline: "Restaurant & Bar" },
    banners: [
      { id: randomUUID(), title: "Chef's special today", text: "Grilled Seer Fish with lime and garlic butter", itemId: "m6", active: true },
    ],
    held: [],
    nextOrderNo: 1049,
  };
}

// Dates are stored as ISO strings; turn them back into Date objects on load.
const DATE_KEY = /(At|Until)$/;
const reviver = (key: string, value: unknown) =>
  typeof value === "string" && DATE_KEY.test(key) && /^\d{4}-\d{2}-\d{2}T/.test(value) ? new Date(value) : value;

function load(): Data {
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf8");
    const parsed = JSON.parse(raw, reviver) as Partial<Data>;
    // Fill in anything added in a newer version of the app.
    return { ...seed(), ...parsed } as Data;
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== "ENOENT") {
      console.error(`[store] Could not read ${DATA_FILE}. Starting fresh; the old file was kept as .broken`, e);
      try { fs.renameSync(DATA_FILE, `${DATA_FILE}.broken`); } catch {}
    }
    const fresh = seed();
    writeNow(fresh);
    return fresh;
  }
}

function writeNow(data: Data) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DATA_FILE); // atomic replace, so a crash never leaves half a file
}

// One copy per server process; survives Next.js hot reloads in dev.
const g = globalThis as unknown as { __goldenPos?: { db: Data; timer?: NodeJS.Timeout } };
const state = (g.__goldenPos ??= { db: load() });
const db = state.db;

function save() {
  if (state.timer) clearTimeout(state.timer);
  state.timer = setTimeout(() => writeNow(db), 150);
}

const MAX_EVENTS = 500;

export class DuplicateError extends Error {
  constructor(public field: "staffCode" | "email" | "code") {
    super(`Duplicate ${field}`);
  }
}

/* ---------------- Staff, sessions, audit ---------------- */

export const staffStore = {
  async list() {
    return [...db.staff];
  },
  async byId(id: string) {
    return db.staff.find((s) => s.id === id) ?? null;
  },
  async byCode(staffCode: string) {
    return db.staff.find((s) => s.staffCode === staffCode) ?? null;
  },
  async byEmail(email: string) {
    return db.staff.find((s) => s.email === email) ?? null;
  },
  async create(data: Pick<Staff, "staffCode" | "name" | "role" | "pinHash" | "email" | "passwordHash">) {
    if (db.staff.some((s) => s.staffCode === data.staffCode)) throw new DuplicateError("staffCode");
    if (data.email && db.staff.some((s) => s.email === data.email)) throw new DuplicateError("email");
    const staff: Staff = { ...data, id: randomUUID(), active: true, failedAttempts: 0, lockedUntil: null, lastLoginAt: null, createdAt: new Date() };
    db.staff.push(staff);
    save();
    return staff;
  },
  async update(id: string, patch: Partial<Omit<Staff, "id" | "createdAt">>) {
    const s = db.staff.find((x) => x.id === id);
    if (!s) return null;
    Object.assign(s, patch);
    save();
    return s;
  },
};

export const sessionStore = {
  async create(data: Omit<Session, "id" | "createdAt" | "lastSeenAt" | "revokedAt">) {
    const now = new Date();
    const session: Session = { ...data, id: randomUUID(), createdAt: now, lastSeenAt: now, revokedAt: null };
    db.sessions.push(session);
    const cutoff = Date.now() - 24 * 3600_000;
    db.sessions = db.sessions.filter((x) => (x.revokedAt ?? x.expiresAt).getTime() > cutoff);
    save();
    return session;
  },
  async byTokenHash(tokenHash: string) {
    return db.sessions.find((s) => s.tokenHash === tokenHash) ?? null;
  },
  async touch(id: string) {
    const s = db.sessions.find((x) => x.id === id);
    if (s && Date.now() - s.lastSeenAt.getTime() > 60_000) {
      s.lastSeenAt = new Date();
      save();
    }
  },
  async revoke(tokenHash: string) {
    const s = db.sessions.find((x) => x.tokenHash === tokenHash && !x.revokedAt);
    if (s) { s.revokedAt = new Date(); save(); }
  },
  async revokeAllFor(userId: string) {
    for (const s of db.sessions) if (s.userId === userId && !s.revokedAt) s.revokedAt = new Date();
    save();
  },
};

export const eventStore = {
  async add(e: Omit<AuthEvent, "id" | "createdAt">) {
    db.events.unshift({ ...e, id: randomUUID(), createdAt: new Date() });
    if (db.events.length > MAX_EVENTS) db.events.length = MAX_EVENTS;
    save();
  },
  async recent(limit = 20) {
    return db.events.slice(0, limit);
  },
};

/* ---------------- Menu ---------------- */

export const menuStore = {
  async categories() {
    return [...db.categories];
  },
  async items() {
    return [...db.items];
  },
  async item(id: string) {
    return db.items.find((i) => i.id === id) ?? null;
  },
  async saveCategory(c: Omit<Category, "id"> & { id?: string }) {
    if (c.id) {
      const existing = db.categories.find((x) => x.id === c.id);
      if (existing) Object.assign(existing, c);
    } else {
      db.categories.push({ ...c, id: randomUUID() });
    }
    save();
  },
  /** Refuses while items still use the category. */
  async deleteCategory(id: string) {
    if (db.items.some((i) => i.categoryId === id)) return false;
    db.categories = db.categories.filter((c) => c.id !== id);
    save();
    return true;
  },
  async saveItem(item: Omit<MenuItem, "id"> & { id?: string }) {
    if (db.items.some((i) => i.code === item.code && i.id !== item.id)) throw new DuplicateError("code");
    if (item.id) {
      const existing = db.items.find((x) => x.id === item.id);
      if (existing) Object.assign(existing, item);
    } else {
      db.items.push({ ...item, id: randomUUID() });
    }
    save();
  },
  async deleteItem(id: string) {
    db.items = db.items.filter((i) => i.id !== id);
    save();
  },
  async setSoldOut(id: string, soldOut: boolean) {
    const i = db.items.find((x) => x.id === id);
    if (i) { i.soldOut = soldOut; save(); }
  },
};

/* ---------------- Branding and home banners ---------------- */

export const settingsStore = {
  async branding() {
    return { ...db.branding };
  },
  async saveBranding(b: Partial<Branding>) {
    db.branding = { ...db.branding, ...b };
    save();
  },
  async banners() {
    return [...db.banners];
  },
  async saveBanner(b: Omit<Banner, "id"> & { id?: string }) {
    if (b.id) {
      const existing = db.banners.find((x) => x.id === b.id);
      if (existing) Object.assign(existing, b);
    } else {
      db.banners.push({ ...b, id: randomUUID() });
    }
    save();
  },
  async deleteBanner(id: string) {
    db.banners = db.banners.filter((b) => b.id !== id);
    save();
  },
};

/* ---------------- Orders on hold ---------------- */

export const orderStore = {
  /** Reserves the next order number. */
  async nextNumber() {
    const n = db.nextOrderNo++;
    save();
    return n;
  },
  async peekNumber() {
    return db.nextOrderNo;
  },
  async held() {
    return [...db.held].sort((a, b) => a.heldAt.getTime() - b.heldAt.getTime());
  },
  async hold(order: Omit<HeldOrder, "id" | "heldAt">) {
    // Holding the same order number again replaces the earlier copy.
    db.held = db.held.filter((h) => h.orderNo !== order.orderNo);
    db.held.push({ ...order, id: randomUUID(), heldAt: new Date() });
    if (order.orderNo >= db.nextOrderNo) db.nextOrderNo = order.orderNo + 1;
    save();
  },
  /** Takes a held order off the list and returns it. */
  async take(id: string) {
    const h = db.held.find((x) => x.id === id) ?? null;
    if (h) {
      db.held = db.held.filter((x) => x.id !== id);
      save();
    }
    return h;
  },
};
