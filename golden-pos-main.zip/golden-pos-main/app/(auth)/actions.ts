"use server";

import { redirect } from "next/navigation";
import { eventStore, staffStore, type AuthEventType, type Staff } from "@/lib/store";
import { burnTime, verifySecret } from "@/lib/auth/hash";
import { LOCK_MINUTES, MAX_FAILED_ATTEMPTS } from "@/lib/auth/constants";
import { createSession, destroySession, getCurrentUser, terminalName } from "@/lib/auth/session";
import { homeFor, type AuthMethod } from "@/lib/auth/roles";
import { passwordLoginSchema, pinLoginSchema } from "@/lib/validators/auth";

export type LoginState = { error?: string } | undefined;

const MISMATCH_PIN = "Invalid user ID or PIN.";
const MISMATCH_PASSWORD = "Invalid email or password.";

function log(type: AuthEventType, method: AuthMethod | null, user: Pick<Staff, "id" | "staffCode"> | null, staffCode?: string) {
  return eventStore.add({
    type,
    method,
    userId: user?.id ?? null,
    actorId: null,
    staffCode: user?.staffCode ?? staffCode ?? null,
    terminal: terminalName(),
  });
}

// Shared by both sign-in methods: lock check, verify, count failures.
async function attempt(user: Staff, secret: string, hash: string, method: AuthMethod, mismatch: string): Promise<LoginState> {
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const mins = Math.max(1, Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60_000));
    return { error: `Account locked. Try again in ${mins} min or ask a manager to unlock.` };
  }

  if (!(await verifySecret(secret, hash))) {
    const failed = user.failedAttempts + 1;
    const lock = failed >= MAX_FAILED_ATTEMPTS;
    await staffStore.update(user.id, {
      failedAttempts: lock ? 0 : failed,
      lockedUntil: lock ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null,
    });
    await log(lock ? "ACCOUNT_LOCKED" : "LOGIN_FAILED", method, user);
    if (lock) return { error: `Too many failed attempts. Account locked for ${LOCK_MINUTES} min.` };
    const left = MAX_FAILED_ATTEMPTS - failed;
    return { error: left <= 2 ? `${mismatch} ${left} attempt${left === 1 ? "" : "s"} left.` : mismatch };
  }

  await staffStore.update(user.id, { failedAttempts: 0, lockedUntil: null, lastLoginAt: new Date() });
  await log("LOGIN_SUCCESS", method, user);
  await createSession(user.id, method);
  redirect(homeFor(user.role));
}

export async function loginWithPin(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const parsed = pinLoginSchema.safeParse({ staffCode: formData.get("staffCode"), pin: formData.get("pin") });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? MISMATCH_PIN };

  const { staffCode, pin } = parsed.data;
  const user = await staffStore.byCode(staffCode);
  if (!user || !user.active) {
    await burnTime(pin);
    await log("LOGIN_FAILED", "PIN", null, staffCode);
    return { error: MISMATCH_PIN };
  }
  return attempt(user, pin, user.pinHash, "PIN", MISMATCH_PIN);
}

export async function loginWithPassword(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const parsed = passwordLoginSchema.safeParse({ email: formData.get("email"), password: formData.get("password") });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? MISMATCH_PASSWORD };

  const { email, password } = parsed.data;
  const user = await staffStore.byEmail(email);
  if (!user || !user.active || !user.passwordHash || (user.role !== "OWNER" && user.role !== "MANAGER")) {
    await burnTime(password);
    await log("LOGIN_FAILED", "PASSWORD", null);
    return { error: MISMATCH_PASSWORD };
  }
  return attempt(user, password, user.passwordHash, "PASSWORD", MISMATCH_PASSWORD);
}

export async function signOut() {
  const user = await getCurrentUser();
  if (user) await log("LOGOUT", user.method, { id: user.id, staffCode: user.staffCode });
  await destroySession();
  redirect("/login");
}
