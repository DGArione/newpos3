export type SidebarMode = "auto" | "collapsed" | "expanded";
export const SIDEBAR_COOKIE = "gp_sidebar";
export const parseSidebar = (v: string | undefined): SidebarMode => (v === "collapsed" || v === "expanded" ? v : "auto");

// Billing screen: the order panel on the right can be folded into a thin bar.
export const ORDER_PANEL_COOKIE = "gp_order_panel";
