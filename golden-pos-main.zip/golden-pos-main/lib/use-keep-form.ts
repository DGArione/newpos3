"use client";

import { startTransition, type FormEvent } from "react";

// React 19 resets a <form action={...}> after every submit, which wipes what
// staff typed when the server sends back a field error. Submitting through
// this handler keeps the values in place.
export function keepFormOnSubmit(action: (fd: FormData) => void) {
  return (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    startTransition(() => action(fd));
  };
}
