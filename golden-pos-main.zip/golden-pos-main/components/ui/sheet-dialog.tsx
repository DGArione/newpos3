"use client";

import { Dialog } from "@base-ui/react/dialog";
import { X, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

// Window-style dialog. Use only for steps that need full attention (payment, user forms).
export function Modal({
  open,
  onOpenChange,
  title,
  icon: Icon,
  description,
  children,
  className,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  icon?: LucideIcon;
  description?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Backdrop className="fixed inset-0 z-50 bg-black/50 transition-opacity duration-100 data-[ending-style]:opacity-0 data-[starting-style]:opacity-0" />
        <Dialog.Popup
          className={cn(
            "fixed left-1/2 top-1/2 z-50 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-lg border border-border bg-panel shadow-xl outline-none",
            className,
          )}
        >
          <div className="flex h-11 items-center gap-2 border-b border-border bg-muted px-4">
            {Icon && <Icon className="size-[18px] text-muted-foreground" strokeWidth={1.75} />}
            <Dialog.Title className="text-[15px] font-semibold">{title}</Dialog.Title>
            <Dialog.Close aria-label="Close" className="-mr-2 ml-auto rounded p-1.5 text-muted-foreground hover:bg-line hover:text-foreground">
              <X className="size-[18px]" />
            </Dialog.Close>
          </div>
          <div className="p-4">
            {description && <Dialog.Description className="mb-3 text-[13px] text-muted-foreground">{description}</Dialog.Description>}
            {children}
          </div>
        </Dialog.Popup>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
