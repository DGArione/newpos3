"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ChefHat,
  LayoutGrid,
  Lock,
  ReceiptText,
  ShoppingBag,
  TrendingUp,
  Users,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Area } from "@/lib/auth/roles";
import { LogoMark } from "./logo";

const NAV: { area: Area; href: string; label: string; icon: LucideIcon }[] = [
  { area: "pos", href: "/pos", label: "Order", icon: ShoppingBag },
  { area: "tables", href: "/tables", label: "Tables", icon: LayoutGrid },
  { area: "orders", href: "/orders", label: "Orders", icon: ReceiptText },
  { area: "kitchen", href: "/kitchen", label: "Kitchen", icon: ChefHat },
  { area: "reports", href: "/reports", label: "Reports", icon: TrendingUp },
  { area: "staff", href: "/staff", label: "Staff", icon: Users },
];

export function Rail({
  areas,
  name,
  roleLabel,
  signOut,
}: {
  areas: Area[];
  name: string;
  roleLabel: string;
  signOut: () => Promise<void>;
}) {
  const pathname = usePathname();
  const initials = name
    .split(/\s+/)
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <nav
      aria-label="Main"
      className="flex w-[84px] shrink-0 flex-col items-center bg-lagoon py-3 text-lagoon-foreground"
    >
      <LogoMark className="mb-4 size-10" />

      <ul className="flex w-full flex-1 flex-col gap-1 px-2">
        {NAV.filter((n) => areas.includes(n.area)).map(({ href, label, icon: Icon }) => {
          const active = pathname.startsWith(href);
          return (
            <li key={href}>
              <Link
                href={href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex flex-col items-center gap-1 rounded-xl py-2.5 text-[11px] font-semibold transition-colors",
                  "focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-gold",
                  active
                    ? "bg-gold text-gold-foreground"
                    : "text-lagoon-foreground/75 hover:bg-lagoon-2 hover:text-white",
                )}
              >
                <Icon className="size-[22px]" strokeWidth={active ? 2.25 : 1.75} />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>

      <div className="flex w-full flex-col items-center gap-2 px-2">
        <div
          className="flex size-10 items-center justify-center rounded-full bg-lagoon-2 font-heading text-sm font-bold text-white"
          title={`${name} · ${roleLabel}`}
        >
          {initials}
        </div>
        <form action={signOut} className="w-full">
          <button
            type="submit"
            className="flex w-full flex-col items-center gap-1 rounded-xl py-2 text-[11px] font-semibold text-lagoon-foreground/75 transition-colors hover:bg-lagoon-2 hover:text-white focus-visible:outline-2 focus-visible:outline-gold"
          >
            <Lock className="size-5" strokeWidth={1.75} />
            Lock
          </button>
        </form>
      </div>
    </nav>
  );
}
