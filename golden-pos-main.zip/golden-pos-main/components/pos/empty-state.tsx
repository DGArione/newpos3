import type { LucideIcon } from "lucide-react";

export function EmptyState({ icon: Icon, message, hint, children }: { icon: LucideIcon; message: string; hint?: string; children?: React.ReactNode }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-1.5 px-8 py-10 text-center">
      <Icon className="mb-1 size-9 text-muted-foreground/70" strokeWidth={1.25} />
      <p className="text-[14px] font-semibold">{message}</p>
      {hint && <p className="max-w-xs text-[12px] text-muted-foreground">{hint}</p>}
      {children}
    </div>
  );
}
