"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { rsExact } from "@/lib/money";
import type { Banner, MenuItem } from "@/lib/types/menu";
import { DishImage } from "@/components/pos/menu-card";

/** Home-page banners managed in Settings. Arrows switch between them. */
export function HomeBanners({ banners, items, onAdd }: { banners: Banner[]; items: Record<string, MenuItem>; onAdd: (item: MenuItem) => void }) {
  const [index, setIndex] = useState(0);
  const [hidden, setHidden] = useState(false);
  if (hidden || banners.length === 0) return null;

  const b = banners[index % banners.length];
  const item = b.itemId ? items[b.itemId] : undefined;
  const photo = b.image ?? item?.image;
  const many = banners.length > 1;
  const go = (d: number) => setIndex((i) => (i + d + banners.length) % banners.length);

  return (
    <section aria-roledescription="carousel" aria-label="Home banners" className="relative flex h-[104px] shrink-0 items-center overflow-hidden rounded-2xl bg-[#1e1e1e] text-white">
      {photo ? (
        <>
          {/* eslint-disable-next-line @next/next/no-img-element -- local upload */}
          <img src={photo} alt="" className="absolute inset-y-0 right-0 h-full w-3/5 object-cover" />
          <span aria-hidden="true" className="absolute inset-y-0 right-0 w-3/5 bg-gradient-to-r from-[#1e1e1e] via-[#1e1e1e]/60 to-transparent" />
        </>
      ) : (
        <span aria-hidden="true" className="absolute -right-6 -top-10 size-32 rounded-full bg-pay/20" />
      )}

      <div className={cn("relative flex min-w-0 flex-1 items-center gap-4 pl-4 pr-12", many ? "pb-6 pt-2" : "py-3")}>
        {!photo && item && (
          <DishImage alt="" color="var(--brand-base)" icon={item.icon} className="size-16 shrink-0 rounded-xl" iconClassName="size-8" />
        )}
        <div className="min-w-0 max-w-md flex-1">
          <p className="truncate text-[17px] font-semibold leading-tight">{b.title}</p>
          <p className="mt-0.5 line-clamp-2 text-[12px] text-white/75">
            {b.text}
            {item && <>, <span className="text-pay">Rs {rsExact(item.price)}</span></>}
          </p>
        </div>
        {item && (
          <button
            onClick={() => onAdd(item)}
            className="relative ml-auto h-9 shrink-0 rounded-md bg-pay px-4 text-[12px] font-medium text-white hover:bg-pay-hover"
          >
            Add to order
          </button>
        )}
      </div>

      {many && (
        <div className="absolute bottom-1.5 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full bg-black/30 px-1.5 py-0.5">
          <button onClick={() => go(-1)} aria-label="Previous banner" className="flex size-6 items-center justify-center rounded-full text-white hover:bg-white/20">
            <ChevronLeft className="size-4" />
          </button>
          {banners.map((x, i) => (
            <button
              key={x.id}
              onClick={() => setIndex(i)}
              aria-label={`Banner ${i + 1}`}
              aria-current={i === index % banners.length}
              className={cn("h-1.5 rounded-full transition-all", i === index % banners.length ? "w-5 bg-pay" : "w-1.5 bg-white/50")}
            />
          ))}
          <button onClick={() => go(1)} aria-label="Next banner" className="flex size-6 items-center justify-center rounded-full text-white hover:bg-white/20">
            <ChevronRight className="size-4" />
          </button>
        </div>
      )}

      <button onClick={() => setHidden(true)} aria-label="Hide banners" className="absolute right-2.5 top-2.5 rounded-md p-1.5 text-white/60 hover:bg-white/10 hover:text-white">
        <X className="size-4" />
      </button>
    </section>
  );
}
