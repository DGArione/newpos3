"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { DuplicateError, menuStore } from "@/lib/store";
import { requireArea } from "@/lib/auth/session";
import { deleteUpload, resolvePhoto } from "@/lib/media";
import { categorySchema, itemSchema } from "@/lib/validators/menu";
import type { IconName } from "@/lib/types/menu";

export type MenuFormState = { ok?: string; error?: string; fields?: Record<string, string> } | undefined;

function fieldErrors(error: z.ZodError) {
  const fields: Record<string, string> = {};
  for (const issue of error.issues) fields[String(issue.path[0] ?? "form")] ??= issue.message;
  return fields;
}

const refresh = () => {
  revalidatePath("/menu");
  revalidatePath("/pos");
};

export async function saveItem(_prev: MenuFormState, fd: FormData): Promise<MenuFormState> {
  await requireArea("menu");
  const parsed = itemSchema.safeParse({
    id: (fd.get("id") as string) || undefined,
    name: fd.get("name"),
    code: fd.get("code"),
    categoryId: fd.get("categoryId"),
    price: fd.get("price"),
    station: fd.get("station"),
    desc: fd.get("desc") ?? "",
    soldOut: fd.get("soldOut") === "on",
  });
  if (!parsed.success) return { fields: fieldErrors(parsed.error) };
  const v = parsed.data;

  const categories = await menuStore.categories();
  const category = categories.find((c) => c.id === v.categoryId);
  if (!category) return { fields: { categoryId: "Choose a category." } };

  const existing = v.id ? await menuStore.item(v.id) : null;
  if (v.id && !existing) return { error: "This item no longer exists." };

  // Check the code before saving the photo, so a rejected form leaves no orphan file.
  if ((await menuStore.items()).some((i) => i.code === v.code && i.id !== v.id)) {
    return { fields: { code: "Another item already uses this code." } };
  }

  const photo = await resolvePhoto(fd, "photo", existing?.image);
  if (photo.error) return { fields: { photo: photo.error } };

  try {
    await menuStore.saveItem({ ...v, icon: category.icon as IconName, image: photo.url });
  } catch (e) {
    if (e instanceof DuplicateError) return { fields: { code: "Another item already uses this code." } };
    throw e;
  }
  refresh();
  return { ok: existing ? `${v.name} updated.` : `${v.name} added to the menu.` };
}

export async function deleteItem(id: string) {
  await requireArea("menu");
  const item = await menuStore.item(id);
  if (!item) return { error: "Item not found." };
  await menuStore.deleteItem(id);
  await deleteUpload(item.image);
  refresh();
  return { ok: `${item.name} removed from the menu.` };
}

export async function setSoldOut(id: string, soldOut: boolean) {
  await requireArea("menu");
  await menuStore.setSoldOut(id, soldOut);
  refresh();
}

export async function saveCategory(_prev: MenuFormState, fd: FormData): Promise<MenuFormState> {
  await requireArea("menu");
  const parsed = categorySchema.safeParse({
    id: (fd.get("id") as string) || undefined,
    name: fd.get("name"),
    icon: fd.get("icon"),
    color: fd.get("color"),
  });
  if (!parsed.success) return { fields: fieldErrors(parsed.error) };
  await menuStore.saveCategory({ ...parsed.data, icon: parsed.data.icon as IconName });
  refresh();
  return { ok: parsed.data.id ? "Category updated." : `${parsed.data.name} added.` };
}

export async function deleteCategory(id: string) {
  await requireArea("menu");
  const ok = await menuStore.deleteCategory(id);
  if (!ok) return { error: "Move or delete the items in this category first." };
  refresh();
  return { ok: "Category deleted." };
}
