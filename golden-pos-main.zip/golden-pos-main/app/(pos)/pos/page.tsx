import type { Metadata } from "next";
import { cookies } from "next/headers";
import { ORDER_PANEL_COOKIE } from "@/lib/sidebar";
import { requireArea } from "@/lib/auth/session";
import { menuStore, orderStore, settingsStore } from "@/lib/store";
import { areas } from "@/lib/mock/floor";
import { OrderScreen } from "./order-screen";

export const metadata: Metadata = { title: "Billing" };

export default async function PosPage({ searchParams }: PageProps<"/pos">) {
  const user = await requireArea("pos");
  const { table } = await searchParams;
  const known = areas.flatMap((a) => a.tables).find((t) => t.id === table);

  const panelCollapsed = (await cookies()).get(ORDER_PANEL_COOKIE)?.value === "collapsed";
  const [categories, menu, banners, held] = await Promise.all([
    menuStore.categories(),
    menuStore.items(),
    settingsStore.banners(),
    orderStore.held(),
  ]);

  return (
    <OrderScreen
      key={known?.id ?? "none"}
      server={user.name.split(" ")[0]}
      categories={categories}
      menu={menu}
      floor={areas}
      banners={banners.filter((b) => b.active)}
      initialHeld={held}
      initialTable={known?.id ?? null}
      initialPanelCollapsed={panelCollapsed}
    />
  );
}
