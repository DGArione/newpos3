---
name: golden-pos-design
description: >
  Golden Beach POS design system. Use when creating or changing any screen,
  component or style in this repo: billing, tables, orders, KOT, users,
  reports, login, dialogs, popovers, colours, status display. Use together
  with frontend-design. Covers tokens, typography, status system, shared
  components, layout, keyboard rules and the /design-guide page.
---

# Golden POS Design Guide

Golden POS is a restaurant billing terminal used on a touch screen during a
12-hour shift. Visual style follows the "Foodin" POS reference: light grey
background, rounded white cards, orange accent, coloured module icons, menu
cards with photos. Light by default, dark available per terminal.

**Use with:** `frontend-design` for visual judgement.

## 1. Principles

- **Dense but tappable.** Everything needed to take an order is on one screen.
  Touch targets 32px minimum, main actions 44 to 56px.
- **Keyboard-first.** F2 search, F4 KOT, F8 pay, F9 hold, F10 lock, Ctrl+K
  command palette. Show the key on the button with `<Key>`.
- **Contextual, not modal.** Quick edits happen where the data is: notes are
  typed in the order line, table and discount use `Popover`. Use `Modal` only
  for steps that need full attention (payment, user forms).
- **Colour means status or money.** Neutral greys carry the UI. Colour comes
  only from the tones below. Never decorate with colour.
- **Real content.** Item codes, Rs. amounts, table numbers and steward names.
  No marketing copy, no emojis.

## 2. Stack

Next.js 16 (App Router), TypeScript strict, Tailwind 4, Base UI (dialog,
popover), Lucide icons, `class-variance-authority` for variants, `cn()` for
class merging. Poppins (bundled in `app/fonts`) for text, Cascadia
Mono/Consolas for identifiers. Nothing loads from the internet.

Palette: brand colour (default orange #F6990D, owner can change it in Settings;
all brand tokens derive from `--brand-base`, never hard-code it), purple #7471F6, blue #5B88FC, red #F52121,
green #35C344, violet #9D61E8; greys #1E1E1E #515151 #808080 #DADADA #EAEAEA.

## 3. Tokens (`app/globals.css`)

Use token utilities, never raw hex/rgb in components (exception: category
colours in `lib/mock/menu.ts`, which are data).

| Token | Use |
|---|---|
| `background` / `foreground` | App background, main text |
| `panel` | Panels, tables, tiles, dialogs |
| `muted` / `muted-foreground` | Table heads, totals block, secondary text |
| `accent` / `accent-foreground` | Hover, selected row, selected tile |
| `line` | Row dividers inside a panel |
| `border` / `input` | Panel edges / control borders |
| `bar` / `bar-2` / `bar-foreground` | Top bar and active tab |
| `selected` / `selected-foreground` | Active segment, primary button |
| `pay` | Brand colour: Pay, Add, active chip/nav, open orders |
| `brand-deep` | Brand-coloured text on white/soft surfaces |
| `kot` | Kitchen actions, notes, shift card |
| `success` | Ready, available, sent, active users |
| `brand-soft` | Menu cards, selected order line |
| `*-ink` | Darker text shade for each tone, for text on tints |
| `info` | Hold, selection, bill printed |
| `void` | Void, delete, errors, locked |
| `warn` | New kitchen tickets |
| `on-tone` | Text on pay/kot/info/void |
| `brand` | Logo and active tab underline only |

Radius: `rounded-md` (10px) buttons/inputs, `rounded-lg`/`rounded-xl` (14/18px)
menu cards and inner cards, `rounded-2xl` (22px) screen cards. `rounded-full`
for chips, avatars and dots. Soft orange glow only on the main Pay button and
active nav item; otherwise flat.

## 4. Typography

Base size 14px. Use these patterns, do not invent new ones:

| Pattern | Classes |
|---|---|
| Page title | `text-[16px] font-semibold` |
| Panel title | `text-[14px] font-semibold` |
| Body / table cell | `text-[13px]` |
| Label | `text-[12px] text-muted-foreground` |
| Identifier (order no., item code, user ID) | `font-mono text-[12px]` |
| Money | `num` + right-aligned, `Rs.` prefix on totals |
| Grand total | `num text-[22px] font-bold` |

Sentence case or title case for labels. No all-caps, no letter-spaced
eyebrows, no middle-dot meta strings.

## 5. Status system

All statuses live in `components/pos/status-badge.tsx` (`STATUSES`). Use
`<StatusBadge status="...">`, `<StatusDot>` or `statusTone(status).tile`.
Never colour a status by hand; add new statuses to the map.

| Group | Statuses |
|---|---|
| Orders | open, in_kitchen, ready, paid, void |
| Tables | available, occupied, bill_printed, cleaning |
| Kitchen | new, preparing, ready |
| Users | active, locked, inactive |

Kitchen ticket age: neutral under 10 min, `kot` 10 to 14, `void` 15+.

## 6. Components

Primitives: `Btn`/`Key` (button.tsx), `Modal` (ui/sheet-dialog.tsx),
`Popover` (ui/popover.tsx). Composites: StatusBadge, MetricCard, EmptyState,
Identity, RoleBadge, Segmented, MenuCard/DishImage, ItemTile, PageHeader,
Screen, Sidebar, AppHeader, Shell, CommandPalette. Full list: [references/component-index.md](references/component-index.md).

Create a component when a pattern appears twice, has behaviour, or encodes
domain rules (status colours, money). Don't wrap single class lists.

## 7. Layout

```
+---------+------------------------------------------------------+
| Sidebar | AppHeader: Hello, name | search (Ctrl K) | theme bell user |
| logo    +------------------------------------------------------+
| modules | <Screen> card: PageHeader, toolbar, content          |
| shift   |   (Billing: special banner + menu card | order cards) |
| card    |                                                      |
+---------+------------------------------------------------------+
```

Billing: left column = special banner + menu card (category chips, MenuCard
grid). Right column `w-[340-360px]` = orange order card (type, table,
guests, Change table, Hold) + items card (lines with thumbnail and stepper,
inline note, totals, Add a discount, Send to kitchen, Pay). Toasts appear
bottom-centre.

## 8. The /design-guide page

`app/(pos)/design-guide/page.tsx`, owners and managers only (Ctrl+K,
"Design guide"). It shows every shared component in every state.

1. Adding a shared component: add it to the page and to the component index.
2. Changing a component's props: update its section.
3. Order: colours, typography, buttons, status, controls, composites.

## 9. Common mistakes

- Raw colours instead of tokens; hand-coloured statuses.
- New text sizes outside the scale.
- A dialog for something that can be a popover or inline edit.
- Icons that don't match the thing (no generic food icons per item).
- Heavy shadows; gradients as decoration (the order card circles are the one exception).
- Fake states presented as real (e.g. a printer status) without a TODO.
- Forgetting light mode: check both themes before shipping.
