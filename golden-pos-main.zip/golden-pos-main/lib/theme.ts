export type Theme = "dark" | "light";
export const THEME_COOKIE = "gp_theme";
export const DEFAULT_THEME: Theme = "light";
export const parseTheme = (v: string | undefined): Theme => (v === "dark" ? "dark" : DEFAULT_THEME);
