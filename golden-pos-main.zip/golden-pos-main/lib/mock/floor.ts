// TEMPORARY sample floor plan — replaced by the Tables/Areas tables later.

export type TableStatus = "free" | "seated" | "bill" | "cleaning";

export type DiningTable = {
  id: string;
  label: string;
  seats: number;
  shape: "round" | "square" | "long";
  status: TableStatus;
  guests?: number;
  openedMinutesAgo?: number;
  server?: string;
  total?: number; // cents
};

export type Area = { id: string; name: string; tables: DiningTable[] };

export const areas: Area[] = [
  {
    id: "deck",
    name: "Beach deck",
    tables: [
      { id: "D1", label: "D1", seats: 2, shape: "round", status: "seated", guests: 2, openedMinutesAgo: 38, server: "Ruwan", total: 612000 },
      { id: "D2", label: "D2", seats: 2, shape: "round", status: "free" },
      { id: "D3", label: "D3", seats: 4, shape: "square", status: "bill", guests: 4, openedMinutesAgo: 71, server: "Ishara", total: 1489000 },
      { id: "D4", label: "D4", seats: 4, shape: "square", status: "free" },
      { id: "D5", label: "D5", seats: 6, shape: "long", status: "seated", guests: 5, openedMinutesAgo: 12, server: "Ruwan", total: 245000 },
      { id: "D6", label: "D6", seats: 2, shape: "round", status: "cleaning" },
    ],
  },
  {
    id: "inside",
    name: "Inside",
    tables: [
      { id: "T1", label: "T1", seats: 4, shape: "square", status: "free" },
      { id: "T2", label: "T2", seats: 4, shape: "square", status: "seated", guests: 3, openedMinutesAgo: 24, server: "Ishara", total: 538000 },
      { id: "T3", label: "T3", seats: 2, shape: "round", status: "free" },
      { id: "T4", label: "T4", seats: 8, shape: "long", status: "free" },
      { id: "T5", label: "T5", seats: 4, shape: "square", status: "free" },
    ],
  },
  {
    id: "bar",
    name: "Bar",
    tables: [
      { id: "B1", label: "B1", seats: 2, shape: "round", status: "seated", guests: 2, openedMinutesAgo: 55, server: "Kasun", total: 432000 },
      { id: "B2", label: "B2", seats: 2, shape: "round", status: "free" },
      { id: "B3", label: "B3", seats: 2, shape: "round", status: "free" },
    ],
  },
];
