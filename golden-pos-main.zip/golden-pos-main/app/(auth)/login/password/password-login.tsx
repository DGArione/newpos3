"use client";

import { useActionState } from "react";
import { Loader2, LogIn, Mail, Lock, TriangleAlert } from "lucide-react";
import { loginWithPassword } from "../../actions";
import { keepFormOnSubmit } from "@/lib/use-keep-form";

const input =
  "h-11 w-full rounded-md border border-input bg-panel pl-9 pr-3 text-[14px] outline-none focus-visible:border-pay focus-visible:ring-2 focus-visible:ring-pay/20";

export function PasswordLogin() {
  const [state, action, pending] = useActionState(loginWithPassword, undefined);

  return (
    <form onSubmit={keepFormOnSubmit(action)} className="mt-4 space-y-3">
      <div>
        <label htmlFor="email" className="mb-1 block text-[12px] font-semibold text-muted-foreground">Email</label>
        <div className="relative">
          <Mail className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input id="email" name="email" type="email" autoComplete="username" required className={input} />
        </div>
      </div>
      <div>
        <label htmlFor="password" className="mb-1 block text-[12px] font-semibold text-muted-foreground">Password</label>
        <div className="relative">
          <Lock className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input id="password" name="password" type="password" autoComplete="current-password" required className={input} />
        </div>
      </div>
      <div className="min-h-[34px]" aria-live="polite">
        {state?.error && (
          <p role="alert" className="flex items-center gap-2 rounded-md border border-void/30 bg-void/[0.07] px-2.5 py-1.5 text-[13px] font-medium text-void">
            <TriangleAlert className="size-4 shrink-0" /> {state.error}
          </p>
        )}
      </div>
      <button
        type="submit"
        disabled={pending}
        className="flex h-12 w-full items-center justify-center gap-2 rounded-md bg-pay text-[15px] font-medium text-white hover:bg-pay-hover disabled:opacity-50"
      >
        {pending ? <Loader2 className="size-5 animate-spin" /> : <LogIn className="size-5" />}
        {pending ? "Logging in..." : "Login"}
      </button>
    </form>
  );
}
