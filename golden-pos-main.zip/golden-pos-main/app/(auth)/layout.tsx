import { Monitor, Wifi } from "lucide-react";
import { Clock } from "@/components/pos/clock";
import { BrandMark } from "@/components/pos/brand";
import { terminalName } from "@/lib/auth/session";
import { settingsStore } from "@/lib/store";
import { APP_VERSION } from "@/lib/version";

export default async function AuthLayout({ children }: { children: React.ReactNode }) {
  const brand = await settingsStore.branding();

  return (
    <div className="relative isolate flex min-h-dvh flex-col items-center justify-center bg-background p-4">
      {brand.loginBackground && (
        <>
          {/* eslint-disable-next-line @next/next/no-img-element -- local upload */}
          <img src={brand.loginBackground} alt="" className="absolute inset-0 -z-10 size-full object-cover" />
          <span aria-hidden="true" className="absolute inset-0 -z-10 bg-[#141414]/55" />
        </>
      )}
      <div className="grid w-full max-w-[780px] overflow-hidden rounded-2xl bg-panel shadow-[0_20px_50px_-24px_rgb(0_0_0/0.25)] md:grid-cols-[280px_1fr]">
        <aside className="relative flex flex-col overflow-hidden bg-pay p-6 text-white">
          {brand.loginImage ? (
            <>
              {/* eslint-disable-next-line @next/next/no-img-element -- local upload */}
              <img src={brand.loginImage} alt="" className="absolute inset-0 size-full object-cover" />
              <span aria-hidden="true" className="absolute inset-0 bg-[linear-gradient(to_bottom,color-mix(in_oklch,var(--brand-base)_85%,transparent),color-mix(in_oklch,var(--brand-base)_35%,transparent),rgb(30_30_30/0.8))]" />
            </>
          ) : (
            <>
              <span aria-hidden="true" className="absolute -right-16 -top-16 size-48 rounded-full bg-white/10" />
              <span aria-hidden="true" className="absolute -bottom-20 -left-10 size-56 rounded-full bg-white/10" />
            </>
          )}
          <div className="relative flex items-center gap-2.5">
            <BrandMark logo={brand.logo} className="size-11 bg-white/10" />
            <div className="min-w-0 leading-tight">
              <p className="truncate text-[16px] font-semibold text-white">{brand.restaurantName}</p>
              {brand.tagline && <p className="truncate text-[12px] text-white/85">{brand.tagline}</p>}
            </div>
          </div>

          <div className="relative mt-10 hidden md:block">
            <Clock pattern="h:mm a" className="num block text-[34px] font-semibold leading-none text-white" />
            <Clock pattern="EEEE, d MMMM yyyy" className="mt-1.5 block text-[13px]" />
          </div>

          <dl className="relative mt-auto hidden space-y-2 pt-8 text-[12px] md:block">
            <div className="flex items-center gap-2">
              <Monitor className="size-4 opacity-80" />
              <dt className="opacity-80">Terminal</dt>
              <dd className="ml-auto font-semibold text-white">{terminalName()}</dd>
            </div>
            <div className="flex items-center gap-2">
              <Wifi className="size-4" />
              <dt className="opacity-80">Server</dt>
              <dd className="ml-auto font-semibold text-white">Connected</dd>
            </div>
          </dl>
        </aside>
        <main className="p-7">{children}</main>
      </div>
      <p className={brand.loginBackground ? "mt-4 text-[12px] text-white/85 [text-shadow:0_1px_2px_rgb(0_0_0/0.5)]" : "mt-4 text-[12px] text-muted-foreground"}>
        {brand.restaurantName} POS v{APP_VERSION} | Developed by Rapid Solutions
      </p>
    </div>
  );
}
