"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Lock, PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Area } from "@/lib/auth/roles";
import { SIDEBAR_COOKIE, type SidebarMode } from "@/lib/sidebar";
import { BrandMark, BrandName } from "./brand";
import { MODULES } from "./nav";

export function Sidebar({
  areas,
  terminal,
  since,
  brand,
  heldCount,
  initialMode,
  onLock,
}: {
  areas: Area[];
  terminal: string;
  since: string;
  brand: { name: string; logo?: string };
  heldCount: number;
  initialMode: SidebarMode;
  onLock: () => void;
}) {
  const pathname = usePathname();
  const [mode, setMode] = useState<SidebarMode>(initialMode);

  // "auto" = full on wide screens, icons only below 1280px.
  const wide = mode === "expanded" ? "flex" : mode === "collapsed" ? "hidden" : "hidden xl:flex";
  const wideInline = mode === "expanded" ? "inline" : mode === "collapsed" ? "hidden" : "hidden xl:inline";
  const wideBlock = mode === "expanded" ? "block" : mode === "collapsed" ? "hidden" : "hidden xl:block";
  const narrowOnly = mode === "expanded" ? "hidden" : mode === "collapsed" ? "flex" : "flex xl:hidden";
  const width = mode === "expanded" ? "w-60" : mode === "collapsed" ? "w-[76px]" : "w-[76px] xl:w-60";
  const center = mode === "expanded" ? "justify-start" : mode === "collapsed" ? "justify-center" : "justify-center xl:justify-start";

  function toggle() {
    const isWide = mode === "expanded" || (mode === "auto" && window.matchMedia("(min-width: 1280px)").matches);
    const next: SidebarMode = isWide ? "collapsed" : "expanded";
    setMode(next);
    document.cookie = `${SIDEBAR_COOKIE}=${next}; path=/; max-age=31536000; samesite=lax`;
  }

  return (
    <aside className={cn("flex shrink-0 flex-col rounded-2xl bg-panel py-4 transition-[width] duration-200", width)} aria-label="Main menu">
      <div className={cn("flex items-center gap-2 px-4", center)}>
        <BrandMark logo={brand.logo} className="size-8" />
        <BrandName name={brand.name} className={cn("min-w-0 flex-1 truncate text-[15px]", wideBlock)} />
        <button
          onClick={toggle}
          aria-label="Collapse menu"
          title="Collapse menu"
          className={cn("size-8 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground", wide)}
        >
          <PanelLeftClose className="size-[18px]" />
        </button>
      </div>
      <button
        onClick={toggle}
        aria-label="Expand menu"
        title="Expand menu"
        className={cn("mx-auto mt-3 size-9 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground", narrowOnly)}
      >
        <PanelLeftOpen className="size-[18px]" />
      </button>

      <p className={cn("mb-2 mt-6 px-5 text-[12px] font-semibold text-foreground", wideBlock)}>Main Menu</p>
      <nav className="scroll-thin mt-2 flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto px-3">
        {MODULES.filter((m) => m.inNav && areas.includes(m.area)).map(({ href, label, icon: Icon, color }) => {
          const active = pathname.startsWith(href);
          const badge = href === "/pos" && heldCount > 0 ? heldCount : 0;
          return (
            <Link
              key={href}
              href={href}
              title={badge ? `${label} (${badge} on hold)` : label}
              aria-current={active ? "page" : undefined}
              className={cn(
                "relative flex h-11 shrink-0 items-center gap-3 rounded-lg px-2 text-[13px] transition-colors",
                center,
                active ? "bg-pay font-medium text-white shadow-[0_6px_16px_-6px_color-mix(in_oklch,var(--brand-base)_70%,transparent)]" : "text-bar-foreground hover:bg-muted",
              )}
            >
              <span
                className="flex size-7 shrink-0 items-center justify-center rounded-md"
                style={{ background: active ? "rgb(255 255 255 / 0.25)" : `color-mix(in oklch, ${color} 12%, transparent)`, color: active ? "#fff" : color }}
              >
                <Icon className="size-4" strokeWidth={2} />
              </span>
              <span className={cn("flex-1", wideInline)}>{label}</span>
              {badge > 0 && (
                <span
                  className={cn(
                    "num flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[11px] font-semibold",
                    active ? "bg-white text-brand-deep" : "bg-info text-white",
                    mode !== "expanded" && "absolute -right-1 -top-1 xl:static",
                    mode === "collapsed" && "xl:absolute",
                  )}
                  aria-label={`${badge} on hold`}
                >
                  {badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      <div className="mx-3 mt-3 overflow-hidden rounded-xl bg-kot text-white">
        <div className={cn("px-4 pb-3 pt-4", wideBlock)}>
          <p className="text-[13px] font-semibold">{terminal}</p>
          <p className="text-[11px] text-white/80">Shift started {since}</p>
        </div>
        <button
          onClick={onLock}
          title="Lock terminal (F10)"
          className={cn(
            "flex h-10 w-full items-center justify-center gap-2 text-[12px] font-medium",
            mode === "expanded"
              ? "mx-auto mb-3 w-[calc(100%-1.5rem)] rounded-md bg-white text-[#4f4cd6] hover:bg-white/90"
              : mode === "collapsed"
                ? "bg-white/15 hover:bg-white/25"
                : "bg-white/15 hover:bg-white/25 xl:mx-auto xl:mb-3 xl:w-[calc(100%-1.5rem)] xl:rounded-md xl:bg-white xl:text-[#4f4cd6] xl:hover:bg-white/90",
          )}
        >
          <Lock className="size-4" />
          <span className={wideInline}>Lock terminal</span>
        </button>
      </div>
    </aside>
  );
}
