import "server-only";
import bcrypt from "bcryptjs";
import { createHash, randomBytes } from "node:crypto";

// bcryptjs is pure JS — no native build step on Windows.
const COST = 10;

export const hashSecret = (plain: string) => bcrypt.hash(plain, COST);
export const verifySecret = (plain: string, hash: string) => bcrypt.compare(plain, hash);

// Used when a login names an unknown staff code, so the response takes the
// same time as a real check and doesn't reveal which codes exist.
const DUMMY_HASH = bcrypt.hashSync("not-a-real-pin", COST);
export const burnTime = (plain: string) => bcrypt.compare(plain, DUMMY_HASH);

export const newSessionToken = () => randomBytes(32).toString("base64url");
export const hashToken = (token: string) =>
  createHash("sha256").update(token).digest("hex");
