"use client";

import { Armchair } from "lucide-react";
import { Modal } from "@/components/ui/sheet-dialog";
import { cn } from "@/lib/utils";
import type { Area } from "@/lib/mock/floor";
import { TABLE_STATUS } from "@/components/pos/table-status";

export function TableDialog({
  open,
  floor,
  current,
  onClose,
  onPick,
}: {
  open: boolean;
  floor: Area[];
  current: string | null;
  onClose: () => void;
  onPick: (tableId: string) => void;
}) {
  return (
    <Modal open={open} onOpenChange={(o) => !o && onClose()} title="Select table" icon={Armchair} className="max-w-2xl">
      <div className="space-y-4">
        {floor.map((area) => (
          <section key={area.id}>
            <h3 className="mb-1.5 text-[12px] font-semibold text-muted-foreground">{area.name}</h3>
            <div className="grid grid-cols-6 gap-1.5">
              {area.tables.map((t) => {
                const s = TABLE_STATUS[t.status];
                return (
                  <button
                    key={t.id}
                    onClick={() => onPick(t.id)}
                    className={cn(
                      "flex h-16 flex-col items-center justify-center rounded-md border text-[12px]",
                      s.tile,
                      current === t.id && "ring-2 ring-info",
                    )}
                  >
                    <span className="text-[16px] font-bold">{t.label}</span>
                    <span className="opacity-80">{t.status === "free" ? `${t.seats} seats` : s.label}</span>
                  </button>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </Modal>
  );
}
