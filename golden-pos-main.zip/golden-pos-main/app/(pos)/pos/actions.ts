"use server";

import { revalidatePath } from "next/cache";
import { orderStore } from "@/lib/store";
import { requireArea } from "@/lib/auth/session";
import { orderSnapshotSchema, type OrderSnapshot } from "@/lib/validators/order";

async function hold(snapshot: OrderSnapshot, heldBy: string) {
  const parsed = orderSnapshotSchema.safeParse(snapshot);
  if (!parsed.success) return false;
  await orderStore.hold({ ...parsed.data, heldBy });
  return true;
}

/** Parks the current order. The next order gets a number when its first item is added. */
export async function holdOrder(snapshot: OrderSnapshot) {
  const user = await requireArea("pos");
  if (!(await hold(snapshot, user.name.split(" ")[0]))) return { error: "Could not hold this order." };
  revalidatePath("/", "layout"); // sidebar badge
  return { held: await orderStore.held() };
}

/**
 * Brings a held order back to the screen. If the screen already has items,
 * that order is put on hold first so nothing is lost.
 */
export async function resumeOrder(id: string, current: OrderSnapshot | null) {
  const user = await requireArea("pos");
  if (current && current.lines.length) await hold(current, user.name.split(" ")[0]);
  const order = await orderStore.take(id);
  revalidatePath("/", "layout");
  if (!order) return { error: "That order is no longer on hold.", held: await orderStore.held() };
  return { order, held: await orderStore.held() };
}

/** Reserves a number for a new order (called when its first item is added). */
export async function newOrderNumber() {
  await requireArea("pos");
  return orderStore.nextNumber();
}
