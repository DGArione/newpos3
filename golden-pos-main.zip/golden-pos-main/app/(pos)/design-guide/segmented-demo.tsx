"use client";

import { useState } from "react";
import { Bike, ShoppingBag, UtensilsCrossed } from "lucide-react";
import { Segmented } from "@/components/pos/segmented";

export function SegmentedDemo() {
  const [v, setV] = useState("dine-in");
  return (
    <Segmented
      label="Order type"
      size="md"
      value={v}
      onChange={setV}
      options={[
        { value: "dine-in", label: "Dine In", icon: UtensilsCrossed },
        { value: "takeaway", label: "Take Away", icon: ShoppingBag },
        { value: "delivery", label: "Delivery", icon: Bike, count: 3 },
      ]}
    />
  );
}
