"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { Delete, Hash, KeyRound, Loader2, LogIn, TriangleAlert } from "lucide-react";
import { cn } from "@/lib/utils";
import { loginWithPin, type LoginState } from "../actions";

type Field = "code" | "pin";
const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "clear", "0", "back"] as const;

export function PinLogin() {
  const [field, setField] = useState<Field>("code");
  const [code, setCode] = useState("");
  const [pin, setPin] = useState("");
  const formRef = useRef<HTMLFormElement>(null);

  const [state, action, pending] = useActionState(async (prev: LoginState, fd: FormData) => {
    const result = await loginWithPin(prev, fd);
    setPin("");
    setField("pin");
    return result;
  }, undefined);

  const setValue = field === "code" ? setCode : setPin;

  function press(key: (typeof KEYS)[number]) {
    if (pending) return;
    if (key === "back") return setValue((v) => v.slice(0, -1));
    if (key === "clear") return setValue("");
    setValue((v) => (v.length >= 6 ? v : v + key));
  }

  function enter() {
    if (field === "code") {
      if (code.length >= 3) setField("pin");
    } else if (pin.length >= 4) {
      formRef.current?.requestSubmit();
    }
  }

  // Keyboard and USB keypads.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (/^\d$/.test(e.key)) press(e.key as (typeof KEYS)[number]);
      else if (e.key === "Backspace") press("back");
      else if (e.key === "Escape") press("clear");
      else if (e.key === "Enter") { e.preventDefault(); enter(); }
      else if (e.key === "Tab") { e.preventDefault(); setField((f) => (f === "code" ? "pin" : "code")); }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const ready = field === "code" ? code.length >= 3 : pin.length >= 4;

  return (
    <form ref={formRef} action={action} className="mt-4">
      <input type="hidden" name="staffCode" value={code} />
      <input type="hidden" name="pin" value={pin} />

      <div className="grid grid-cols-2 gap-2">
        <InputBox icon={Hash} label="User ID" active={field === "code"} onClick={() => setField("code")}>
          {code || <span className="text-muted-foreground/60">----</span>}
        </InputBox>
        <InputBox icon={KeyRound} label="PIN" active={field === "pin"} onClick={() => setField("pin")}>
          {pin ? "•".repeat(pin.length) : <span className="text-muted-foreground/60">----</span>}
        </InputBox>
      </div>

      <div className="mt-2 min-h-[34px]" aria-live="polite">
        {state?.error && (
          <p role="alert" className="flex items-center gap-2 rounded-md border border-void/30 bg-void/[0.07] px-2.5 py-1.5 text-[13px] font-medium text-void">
            <TriangleAlert className="size-4 shrink-0" /> {state.error}
          </p>
        )}
      </div>

      <div className="mt-1 grid grid-cols-3 gap-1.5" aria-label="Keypad">
        {KEYS.map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => press(k)}
            aria-label={k === "back" ? "Backspace" : k === "clear" ? "Clear" : k}
            className={cn(
              "num flex h-[54px] items-center justify-center rounded-lg text-[20px] font-medium transition-colors active:bg-accent",
              k === "clear" || k === "back" ? "bg-panel text-[13px] text-muted-foreground hover:bg-muted" : "bg-muted hover:bg-brand-soft",
            )}
          >
            {k === "back" ? <Delete className="size-5" /> : k === "clear" ? "CLR" : k}
          </button>
        ))}
      </div>

      <button
        type="button"
        onClick={enter}
        disabled={!ready || pending}
        className="mt-2 flex h-12 w-full items-center justify-center gap-2 rounded-md bg-pay text-[15px] font-medium text-white shadow-[0_10px_24px_-12px_color-mix(in_oklch,var(--brand-base)_90%,transparent)] transition-colors hover:bg-pay-hover disabled:opacity-45"
      >
        {pending ? <Loader2 className="size-5 animate-spin" /> : <LogIn className="size-5" />}
        {field === "code" ? "Next" : pending ? "Logging in..." : "Login"}
      </button>
    </form>
  );
}

function InputBox({
  icon: Icon,
  label,
  active,
  onClick,
  children,
}: {
  icon: typeof Hash;
  label: string;
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "flex h-14 items-center gap-2.5 rounded-md border px-3 text-left",
        active ? "border-pay ring-2 ring-pay/20" : "border-input hover:border-muted-foreground/40",
      )}
    >
      <Icon className={cn("size-5", active ? "text-pay" : "text-muted-foreground")} strokeWidth={1.75} />
      <span className="min-w-0">
        <span className="block text-[11px] font-semibold text-muted-foreground">{label}</span>
        <span className="num block text-[18px] font-semibold tracking-[0.15em]">{children}</span>
      </span>
    </button>
  );
}
