import { format } from "date-fns";
import { APP_VERSION } from "@/lib/version";

export function StatusBar({ terminal, user, signedInAt }: { terminal: string; user: string; signedInAt: Date }) {
  const cell = "border-r border-border px-3";
  return (
    <footer className="flex h-6 shrink-0 items-center border-t border-border bg-panel text-[11px] text-muted-foreground">
      <span className={cell}>Terminal <b className="font-semibold text-foreground">{terminal}</b></span>
      <span className={cell}>{user}</span>
      <span className={cell}>Since {format(signedInAt, "h:mm a")}</span>
      <span className={cell}>Data: local, not synced</span>
      <span className="ml-auto hidden px-3 md:block">Ctrl K search &nbsp; F10 lock</span>
      <span className="border-l border-border px-3">v{APP_VERSION}</span>
    </footer>
  );
}
