import {
  Beef,
  Beer,
  CakeSlice,
  Citrus,
  Coffee,
  CookingPot,
  Drumstick,
  Egg,
  Fish,
  Flame,
  GlassWater,
  IceCreamCone,
  Martini,
  Salad,
  Shell,
  Shrimp,
  Soup,
  UtensilsCrossed,
  Wheat,
  CupSoda,
  type LucideIcon,
} from "lucide-react";
import type { IconName } from "@/lib/mock/menu";

const ICONS: Record<IconName, LucideIcon> = {
  starters: UtensilsCrossed,
  seafood: Fish,
  kottu: Wheat,
  curries: Soup,
  drinks: CupSoda,
  desserts: CakeSlice,
  drumstick: Drumstick,
  shrimp: Shrimp,
  fish: Fish,
  flame: Flame,
  soup: Soup,
  egg: Egg,
  pot: CookingPot,
  wheat: Wheat,
  coconut: GlassWater,
  citrus: Citrus,
  coffee: Coffee,
  beer: Beer,
  cocktail: Martini,
  icecream: IceCreamCone,
  cake: CakeSlice,
  salad: Salad,
  shell: Shell,
};

export function MenuIcon({ name, className, strokeWidth = 1.6 }: { name: IconName; className?: string; strokeWidth?: number }) {
  const Icon = ICONS[name] ?? Beef;
  return <Icon className={className} strokeWidth={strokeWidth} aria-hidden="true" />;
}
