"use client";

import { useEffect, useRef, useState } from "react";
import { ImagePlus, RefreshCw, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Photo picker with preview. Sends the file as <name>; "Remove" sends
 * <name>Remove=1. Leaving it alone keeps the current photo.
 */
export function ImageField({
  name,
  label,
  current,
  hint = "JPG, PNG or WebP, up to 5 MB.",
  error,
  aspect = "aspect-[16/10]",
  fit = "cover",
  className,
}: {
  name: string;
  label: string;
  current?: string;
  hint?: string;
  error?: string;
  aspect?: string;
  fit?: "cover" | "contain";
  className?: string;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | undefined>(current);
  const [removed, setRemoved] = useState(false);

  // Free the temporary preview URL when it changes.
  useEffect(() => () => { if (preview?.startsWith("blob:")) URL.revokeObjectURL(preview); }, [preview]);

  function pick(file: File | undefined) {
    if (!file) return;
    setPreview(URL.createObjectURL(file));
    setRemoved(false);
  }

  function remove() {
    if (input.current) input.current.value = "";
    setPreview(undefined);
    setRemoved(true);
  }

  return (
    <div className={cn("space-y-1", className)}>
      <span className="block text-[12px] font-medium text-muted-foreground">{label}</span>
      <div
        className={cn(
          "group relative flex w-full items-center justify-center overflow-hidden rounded-xl border-2 border-dashed",
          aspect,
          error ? "border-void" : preview ? "border-transparent" : "border-input hover:border-pay",
        )}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          const f = e.dataTransfer.files?.[0];
          if (f && input.current) {
            const dt = new DataTransfer();
            dt.items.add(f);
            input.current.files = dt.files;
            pick(f);
          }
        }}
      >
        {preview ? (
          // eslint-disable-next-line @next/next/no-img-element -- local preview
          <img src={preview} alt="" className={cn("absolute inset-0 size-full", fit === "cover" ? "object-cover" : "object-contain p-3")} />
        ) : (
          <button type="button" onClick={() => input.current?.click()} className="flex flex-col items-center gap-1.5 p-4 text-muted-foreground">
            <ImagePlus className="size-7 text-pay" strokeWidth={1.6} />
            <span className="text-[12px] font-medium text-foreground">Add photo</span>
            <span className="text-[11px]">Click or drop a file here</span>
          </button>
        )}
        {preview && (
          <div className="absolute bottom-2 right-2 flex gap-1.5">
            <button type="button" onClick={() => input.current?.click()} className="flex h-7 items-center gap-1 rounded-full bg-white/95 px-2.5 text-[11px] font-medium text-[#1e1e1e] shadow hover:bg-white">
              <RefreshCw className="size-3" /> Change
            </button>
            <button type="button" onClick={remove} className="flex h-7 items-center gap-1 rounded-full bg-white/95 px-2.5 text-[11px] font-medium text-[#c41414] shadow hover:bg-white">
              <Trash2 className="size-3" /> Remove
            </button>
          </div>
        )}
      </div>
      <input
        ref={input}
        type="file"
        name={name}
        accept="image/jpeg,image/png,image/webp"
        className="sr-only"
        tabIndex={-1}
        aria-label={label}
        onChange={(e) => pick(e.target.files?.[0])}
      />
      {removed && <input type="hidden" name={`${name}Remove`} value="1" />}
      {error ? <p className="text-[12px] font-medium text-void-ink">{error}</p> : <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}
