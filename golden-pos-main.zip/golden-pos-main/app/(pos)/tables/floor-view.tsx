"use client";

import { useState } from "react";
import Link from "next/link";
import { Armchair, Clock3, UserRound, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { rsExact } from "@/lib/money";
import type { Area } from "@/lib/mock/floor";
import { Segmented } from "@/components/pos/segmented";
import { StatusBadge, StatusDot, statusTone, STATUSES } from "@/components/pos/status-badge";
import { TABLE_STATUS_KEY } from "../pos/table-picker";

export function FloorView({ areas }: { areas: Area[] }) {
  const [areaId, setAreaId] = useState("all");
  const all = areas.flatMap((a) => a.tables);
  const shown = areaId === "all" ? areas : areas.filter((a) => a.id === areaId);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-panel px-4 py-2">
        <Segmented
          label="Area"
          options={[{ value: "all", label: "All areas", count: all.length }, ...areas.map((a) => ({ value: a.id, label: a.name, count: a.tables.length }))]}
          value={areaId}
          onChange={setAreaId}
        />
        <ul className="ml-auto flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-muted-foreground">
          {(Object.entries(TABLE_STATUS_KEY) as [keyof typeof TABLE_STATUS_KEY, keyof typeof STATUSES][]).map(([raw, st]) => (
            <li key={raw} className="flex items-center gap-1.5">
              <StatusDot status={st} />
              {STATUSES[st].label}
              <b className="num text-foreground">{all.filter((t) => t.status === raw).length}</b>
            </li>
          ))}
        </ul>
      </div>

      <div className="scroll-thin flex-1 space-y-5 overflow-y-auto p-4">
        {shown.map((area) => (
          <section key={area.id}>
            <h2 className="mb-2 text-[13px] font-semibold">
              {area.name} <span className="font-normal text-muted-foreground">{area.tables.length} tables</span>
            </h2>
            <div className="grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-2">
              {area.tables.map((t) => {
                const st = TABLE_STATUS_KEY[t.status];
                const busy = t.status === "seated" || t.status === "bill";
                return (
                  <Link key={t.id} href={`/pos?table=${t.id}`} className={cn("flex h-[112px] flex-col rounded-md border p-2.5 transition-colors", statusTone(st).tile)}>
                    <div className="flex items-start justify-between">
                      <span className="text-[22px] font-bold leading-none">{t.label}</span>
                      <span className="flex items-center gap-1 text-[11px] text-muted-foreground"><Armchair className="size-3.5" /> {t.seats}</span>
                    </div>
                    {busy ? (
                      <div className="mt-auto space-y-0.5 text-[12px]">
                        <p className="num text-[14px] font-semibold">Rs. {rsExact(t.total ?? 0)}</p>
                        <p className="flex items-center gap-3 text-muted-foreground">
                          <span className="flex items-center gap-1"><Users className="size-3.5" />{t.guests}</span>
                          <span className="flex items-center gap-1"><Clock3 className="size-3.5" />{t.openedMinutesAgo}m</span>
                          <span className="flex min-w-0 items-center gap-1"><UserRound className="size-3.5" /><span className="truncate">{t.server}</span></span>
                        </p>
                      </div>
                    ) : (
                      <StatusBadge status={st} className="mt-auto self-start bg-transparent px-0" />
                    )}
                  </Link>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
