"use client";

import { useActionState, useState } from "react";
import { Loader2, Save, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Modal } from "@/components/ui/sheet-dialog";
import { Field, inputClass } from "@/components/pos/field";
import { Btn } from "@/components/pos/button";
import { ROLE_LABEL, type Role } from "@/lib/auth/roles";
import { keepFormOnSubmit } from "@/lib/use-keep-form";
import { createStaff, type FormState } from "./actions";

export function AddStaff({ roles }: { roles: Role[] }) {
  const [open, setOpen] = useState(false);
  const [formKey, setFormKey] = useState(0);

  return (
    <>
      <Btn tone="primary" onClick={() => setOpen(true)}>
        <UserPlus className="size-4" /> Add User
      </Btn>
      <Modal open={open} onOpenChange={setOpen} title="Add User" icon={UserPlus}>
        <AddStaffForm
          key={formKey}
          roles={roles}
          onCancel={() => setOpen(false)}
          onDone={(msg) => {
            toast.success(msg);
            setOpen(false);
            setFormKey((k) => k + 1);
          }}
        />
      </Modal>
    </>
  );
}

function AddStaffForm({ roles, onDone, onCancel }: { roles: Role[]; onDone: (msg: string) => void; onCancel: () => void }) {
  const [role, setRole] = useState<Role>(roles.includes("WAITER") ? "WAITER" : roles[0]);
  const [state, action, pending] = useActionState(async (prev: FormState, fd: FormData) => {
    const result = await createStaff(prev, fd);
    if (result?.ok) onDone(result.ok);
    return result;
  }, undefined);

  const f = state?.fields ?? {};
  const backOffice = role === "OWNER" || role === "MANAGER";

  return (
    <form onSubmit={keepFormOnSubmit(action)} className="grid grid-cols-2 gap-3">
      <Field label="Full name" htmlFor="name" error={f.name} className="col-span-2">
        <input id="name" name="name" required autoFocus className={inputClass} aria-invalid={!!f.name} />
      </Field>
      <Field label="User ID" htmlFor="staffCode" error={f.staffCode} hint="3 to 6 digits">
        <input id="staffCode" name="staffCode" inputMode="numeric" required className={inputClass} aria-invalid={!!f.staffCode} />
      </Field>
      <Field label="Role" htmlFor="role">
        <select id="role" name="role" value={role} onChange={(e) => setRole(e.target.value as Role)} className={inputClass}>
          {roles.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
        </select>
      </Field>
      <Field label="PIN" htmlFor="pin" error={f.pin} hint="4 to 6 digits. Not 1234 or 0000." className="col-span-2">
        <input id="pin" name="pin" type="password" inputMode="numeric" autoComplete="new-password" required className={inputClass} aria-invalid={!!f.pin} />
      </Field>
      {backOffice && (
        <>
          <Field label="Email (back office)" htmlFor="email" error={f.email}>
            <input id="email" name="email" type="email" className={inputClass} aria-invalid={!!f.email} />
          </Field>
          <Field label="Password" htmlFor="password" error={f.password} hint="Min. 8 characters">
            <input id="password" name="password" type="password" autoComplete="new-password" className={inputClass} aria-invalid={!!f.password} />
          </Field>
        </>
      )}
      {state?.error && <p className="col-span-2 text-[13px] font-medium text-void">{state.error}</p>}
      <div className="col-span-2 flex justify-end gap-2 border-t border-line pt-3">
        <Btn type="button" onClick={onCancel}>Cancel</Btn>
        <Btn type="submit" tone="pay" className="px-5" disabled={pending}>
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} Save User
        </Btn>
      </div>
    </form>
  );
}
