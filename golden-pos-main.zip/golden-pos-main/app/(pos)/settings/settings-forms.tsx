"use client";

import { useActionState, useEffect, useState, useTransition } from "react";
import { toast } from "sonner";
import { Check, GalleryHorizontalEnd, ImageIcon, Loader2, Palette, Pencil, Plus, RotateCcw, Save, ShoppingBag, Store, Trash2 } from "lucide-react";
import { BRAND_PRESETS, brandColorProblem, DEFAULT_BRAND_COLOR, isHex } from "@/lib/brand-color";
import { cn } from "@/lib/utils";
import type { Banner, Branding } from "@/lib/types/menu";
import { Modal } from "@/components/ui/sheet-dialog";
import { Btn } from "@/components/pos/button";
import { Field, inputClass } from "@/components/pos/field";
import { ImageField } from "@/components/pos/image-field";
import { EmptyState } from "@/components/pos/empty-state";
import { keepFormOnSubmit } from "@/lib/use-keep-form";
import { deleteBanner, saveBanner, saveBrandColor, saveBranding, setBannerActive, type SettingsFormState } from "./actions";

type ItemOption = { id: string; name: string; code: number; image?: string };

function Card({ icon: Icon, title, description, action, children }: { icon: typeof Store; title: string; description: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl bg-panel">
      <header className="flex items-center gap-3 border-b border-line px-5 py-3.5">
        <span className="flex size-9 items-center justify-center rounded-lg bg-brand-soft text-pay">
          <Icon className="size-[18px]" />
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="text-[15px] font-semibold">{title}</h2>
          <p className="text-[12px] text-muted-foreground">{description}</p>
        </div>
        {action}
      </header>
      <div className="p-5">{children}</div>
    </section>
  );
}

export function BrandingForm({ branding }: { branding: Branding }) {
  const [state, action, pending] = useActionState(async (prev: SettingsFormState, fd: FormData) => {
    const r = await saveBranding(prev, fd);
    if (r?.ok) toast.success(r.ok);
    return r;
  }, undefined);
  const f = state?.fields ?? {};

  return (
    <Card icon={Store} title="Restaurant and login page" description="Logo and name appear in the menu bar, on the login page and on printed bills.">
      <form onSubmit={keepFormOnSubmit(action)} className="space-y-5">
        <div className="grid gap-5 md:grid-cols-[160px_1fr]">
          <ImageField key={branding.logo ?? "no-logo"} name="logo" label="Logo" current={branding.logo} error={f.logo} aspect="aspect-square" fit="contain" hint="Square works best. Keep it simple." />
          <div className="space-y-3">
            <Field label="Restaurant name" htmlFor="restaurantName" error={f.restaurantName} hint="The first word is shown in the main colour.">
              <input id="restaurantName" name="restaurantName" defaultValue={branding.restaurantName} required className={inputClass} aria-invalid={!!f.restaurantName} />
            </Field>
            <Field label="Tagline" htmlFor="tagline" error={f.tagline} hint="Shown under the name on the login page.">
              <input id="tagline" name="tagline" defaultValue={branding.tagline} className={inputClass} />
            </Field>
          </div>
        </div>

        <div className="grid gap-5 border-t border-line pt-5 md:grid-cols-[180px_minmax(0,400px)]">
          <ImageField
            key={branding.loginImage ?? "no-login-image"}
            name="loginImage"
            label="Login card picture"
            current={branding.loginImage}
            error={f.loginImage}
            aspect="aspect-[3/4]"
            hint="Fills the coloured panel on the left of the login card."
          />
          <ImageField
            key={branding.loginBackground ?? "no-login-background"}
            name="loginBackground"
            label="Login page background"
            current={branding.loginBackground}
            error={f.loginBackground}
            aspect="aspect-[16/9]"
            hint="Covers the whole screen behind the login card and is darkened a little so the card stands out. A wide photo of the beach or dining area works well."
          />
        </div>

        <div className="flex items-center gap-3 border-t border-line pt-4">
          {state?.error && <p className="text-[13px] font-medium text-void-ink">{state.error}</p>}
          <Btn type="submit" tone="pay" className="ml-auto px-5" disabled={pending}>
            {pending ? <Loader2 className="animate-spin" /> : <Save />} Save branding
          </Btn>
        </div>
      </form>
    </Card>
  );
}

/*
 * Main colour of the whole system. Picking a colour previews it on this screen straight
 * away (sets --brand-base on <html>); Save stores it so every till uses it.
 */
export function ColorToneForm({ saved }: { saved: string }) {
  const [value, setValue] = useState(saved);
  const [saving, start] = useTransition();
  const problem = brandColorProblem(value);
  const dirty = value !== saved;

  // Leaving the page without saving drops the preview.
  useEffect(() => () => { document.documentElement.style.removeProperty("--brand-base"); }, []);

  function pick(hex: string) {
    const v = hex.toLowerCase();
    setValue(v);
    if (isHex(v)) document.documentElement.style.setProperty("--brand-base", v);
  }

  function undo() {
    setValue(saved);
    document.documentElement.style.removeProperty("--brand-base");
  }

  function save() {
    start(async () => {
      const r = await saveBrandColor(value);
      if ("error" in r) toast.error(r.error);
      else toast.success(r.ok);
    });
  }

  const presetMatch = BRAND_PRESETS.find((p) => p.hex === value);

  return (
    <Card icon={Palette} title="System colour" description="Main colour for buttons, the menu bar, totals and the login page, on every till.">
      <div className="grid gap-6 md:grid-cols-[1fr_260px]">
        <div className="space-y-4">
          <div role="radiogroup" aria-label="Colour presets" className="grid grid-cols-4 gap-2 sm:grid-cols-8">
            {BRAND_PRESETS.map((p) => {
              const on = p.hex === value;
              return (
                <button
                  key={p.hex}
                  type="button"
                  role="radio"
                  aria-checked={on}
                  aria-label={p.name}
                  title={p.name}
                  onClick={() => pick(p.hex)}
                  className={cn(
                    "flex aspect-square items-center justify-center rounded-xl text-white transition-transform hover:scale-105",
                    on && "ring-2 ring-foreground ring-offset-2 ring-offset-panel",
                  )}
                  style={{ background: p.hex }}
                >
                  {on && <Check className="size-5" strokeWidth={2.5} />}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label className="flex h-10 cursor-pointer items-center gap-2 rounded-lg border border-input bg-background pl-1.5 pr-3 text-[13px] hover:bg-muted">
              <input
                type="color"
                value={isHex(value) ? value : saved}
                onChange={(e) => pick(e.target.value)}
                className="size-7 cursor-pointer rounded-md border-0 bg-transparent p-0 [&::-webkit-color-swatch]:rounded-md [&::-webkit-color-swatch]:border-0 [&::-webkit-color-swatch-wrapper]:p-0"
                aria-label="Custom colour"
              />
              Custom colour
            </label>
            <span className="num rounded-md bg-muted px-2 py-1 text-[12px] font-medium uppercase">{value}</span>
            <span className="text-[12px] text-muted-foreground">{presetMatch?.name ?? "Custom"}</span>
          </div>

          {problem && <p className="text-[13px] font-medium text-void-ink">{problem}</p>}
          <p className="text-[12px] text-muted-foreground">
            {dirty ? "You are previewing this colour on this screen only. Save to use it on every till." : "This is the colour every till uses now."}
          </p>

          <div className="flex flex-wrap items-center gap-2">
            {value !== DEFAULT_BRAND_COLOR && (
              <Btn type="button" onClick={() => pick(DEFAULT_BRAND_COLOR)}><RotateCcw /> Back to golden orange</Btn>
            )}
            {dirty && <Btn type="button" tone="ghost" onClick={undo}>Undo</Btn>}
            <Btn type="button" tone="pay" className="ml-auto px-5" disabled={!dirty || !!problem || saving} onClick={save}>
              {saving ? <Loader2 className="animate-spin" /> : <Save />} Save colour
            </Btn>
          </div>
        </div>

        {/* Sample of the pieces the colour touches. */}
        <div aria-hidden="true" className="space-y-3 rounded-xl bg-muted p-4">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Preview</p>
          <div className="flex items-center gap-2 rounded-lg bg-pay px-3 py-2 text-[13px] font-medium text-white shadow-[0_6px_14px_-8px_var(--brand-base)]">
            <ShoppingBag className="size-4" /> Billing
          </div>
          <div className="flex items-center justify-between rounded-lg bg-panel px-3 py-2 text-[13px]">
            <span>Total</span>
            <span className="num font-semibold text-pay">Rs. 4,250.00</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-brand-soft px-2.5 py-1 text-[12px] font-medium text-brand-deep">Seafood</span>
            <span className="rounded-full bg-panel px-2.5 py-1 text-[12px]">Drinks</span>
          </div>
          <div className="flex h-10 items-center justify-center rounded-lg bg-pay text-[14px] font-semibold text-white">Pay Rs. 4,250.00</div>
        </div>
      </div>
    </Card>
  );
}

export function BannerManager({ banners, items }: { banners: Banner[]; items: ItemOption[] }) {
  const [editing, setEditing] = useState<{ banner?: Banner } | null>(null);
  const [formKey, setFormKey] = useState(0);
  const [, start] = useTransition();
  const itemById = Object.fromEntries(items.map((i) => [i.id, i]));

  const open = (banner?: Banner) => { setFormKey((k) => k + 1); setEditing({ banner }); };

  return (
    <Card
      icon={GalleryHorizontalEnd}
      title="Home page banners"
      description="Pictures and offers shown at the top of the Billing screen. Staff can flick through them with the arrows."
      action={<Btn tone="pay" onClick={() => open()}><Plus /> Add banner</Btn>}
    >
      {banners.length === 0 ? (
        <EmptyState icon={ImageIcon} message="No banners yet" hint="Add a picture of today's special, a promotion or a notice for staff." />
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2">
          {banners.map((b) => {
            const item = b.itemId ? itemById[b.itemId] : undefined;
            const photo = b.image ?? item?.image;
            return (
              <li key={b.id} className={cn("overflow-hidden rounded-xl border border-border", !b.active && "opacity-60")}>
                <div className="relative flex h-28 items-end bg-[#1e1e1e] p-3 text-white">
                  {photo && (
                    // eslint-disable-next-line @next/next/no-img-element -- local upload
                    <img src={photo} alt="" className="absolute inset-0 size-full object-cover opacity-70" />
                  )}
                  <div className="relative min-w-0">
                    <p className="truncate text-[15px] font-semibold">{b.title}</p>
                    <p className="truncate text-[12px] text-white/80">{b.text}</p>
                  </div>
                  {!b.active && <span className="absolute right-2 top-2 rounded-full bg-white/90 px-2 py-0.5 text-[11px] font-medium text-[#1e1e1e]">Hidden</span>}
                </div>
                <div className="flex items-center gap-2 px-3 py-2 text-[12px]">
                  <span className="min-w-0 flex-1 truncate text-muted-foreground">
                    {item ? <>Adds <b className="font-medium text-foreground">{item.name}</b></> : "No dish linked"}
                    {!photo && ", no picture"}
                  </span>
                  <label className="flex items-center gap-1.5">
                    <input
                      type="checkbox"
                      checked={b.active}
                      onChange={(e) => start(async () => { await setBannerActive(b.id, e.target.checked); })}
                      className="size-4 accent-[var(--brand-base)]"
                    />
                    Show
                  </label>
                  <Btn size="sm" onClick={() => open(b)}><Pencil /> Edit</Btn>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <Modal open={!!editing} onOpenChange={(o) => !o && setEditing(null)} title={editing?.banner ? "Edit banner" : "Add banner"} className="max-w-xl">
        {editing && <BannerForm key={formKey} banner={editing.banner} items={items} onDone={() => setEditing(null)} />}
      </Modal>
    </Card>
  );
}

function BannerForm({ banner, items, onDone }: { banner?: Banner; items: ItemOption[]; onDone: () => void }) {
  const [confirm, setConfirm] = useState(false);
  const [deleting, startDelete] = useTransition();
  const [state, action, pending] = useActionState(async (prev: SettingsFormState, fd: FormData) => {
    const r = await saveBanner(prev, fd);
    if (r?.ok) { toast.success(r.ok); onDone(); }
    return r;
  }, undefined);
  const f = state?.fields ?? {};

  return (
    <form onSubmit={keepFormOnSubmit(action)} className="space-y-3">
      {banner && <input type="hidden" name="id" value={banner.id} />}
      <ImageField
        name="image"
        label="Picture"
        current={banner?.image}
        error={f.image}
        aspect="aspect-[16/6]"
        hint="Wide photo. Shown on the right of the banner. Leave empty to use the linked dish's photo."
      />
      <Field label="Title" htmlFor="title" error={f.title}>
        <input id="title" name="title" defaultValue={banner?.title} placeholder="Chef's special today" required className={inputClass} aria-invalid={!!f.title} />
      </Field>
      <Field label="Text" htmlFor="text" error={f.text}>
        <input id="text" name="text" defaultValue={banner?.text} placeholder="Grilled Seer Fish with lime and garlic butter" maxLength={100} className={inputClass} />
      </Field>
      <Field label="Dish for the Add to order button" htmlFor="itemId" error={f.itemId} hint="Optional. Leave as none for a notice without a button.">
        <select id="itemId" name="itemId" defaultValue={banner?.itemId ?? ""} className={inputClass}>
          <option value="">None</option>
          {items.map((i) => <option key={i.id} value={i.id}>{i.code} {i.name}</option>)}
        </select>
      </Field>
      <label className="flex items-center gap-2 text-[13px]">
        <input type="checkbox" name="active" defaultChecked={banner?.active ?? true} className="size-4 accent-[var(--brand-base)]" />
        Show on the home page
      </label>
      {state?.error && <p className="text-[13px] font-medium text-void-ink">{state.error}</p>}
      <div className="flex items-center gap-2 border-t border-line pt-3">
        {banner && (
          <Btn
            type="button"
            tone={confirm ? "void" : "void-outline"}
            disabled={deleting}
            onClick={() => {
              if (!confirm) return setConfirm(true);
              startDelete(async () => {
                const r = await deleteBanner(banner.id);
                if ("error" in r) toast.error(r.error);
                else { toast.success(r.ok); onDone(); }
              });
            }}
          >
            <Trash2 /> {confirm ? "Click again to delete" : "Delete"}
          </Btn>
        )}
        <Btn type="button" className="ml-auto" onClick={onDone}>Cancel</Btn>
        <Btn type="submit" tone="pay" className="px-5" disabled={pending}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />} Save banner
        </Btn>
      </div>
    </form>
  );
}
