import {
  Ban,
  Banknote,
  BellRing,
  ChefHat,
  CircleCheck,
  CircleDashed,
  CircleDot,
  Flame,
  LockKeyhole,
  Receipt,
  Sparkles,
  UserCheck,
  XCircle,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

/*
 * Every status in the app, in one place. Never colour a status by hand —
 * add it here and use <StatusBadge> or <StatusDot>.
 */
type Tone = "green" | "orange" | "blue" | "red" | "yellow" | "neutral";

const TONE: Record<Tone, { badge: string; dot: string; tile: string }> = {
  green: { badge: "bg-success/12 text-success-ink", dot: "bg-success", tile: "border-success/40 bg-success/[0.07] hover:bg-success/15" },
  orange: { badge: "bg-pay/15 text-pay-ink", dot: "bg-pay", tile: "border-pay/50 bg-pay/[0.10] hover:bg-pay/20" },
  blue: { badge: "bg-info/12 text-info-ink", dot: "bg-info", tile: "border-info/45 bg-info/[0.08] hover:bg-info/15" },
  red: { badge: "bg-void/10 text-void-ink", dot: "bg-void", tile: "border-void/45 bg-void/[0.07] hover:bg-void/15" },
  yellow: { badge: "bg-warn/12 text-warn-ink", dot: "bg-warn", tile: "border-warn/45 bg-warn/[0.08] hover:bg-warn/15" },
  neutral: { badge: "bg-muted text-muted-foreground", dot: "bg-muted-foreground", tile: "border-border bg-muted text-muted-foreground hover:bg-line" },
};

export const STATUSES = {
  // Orders
  open: { label: "Open", tone: "orange", icon: CircleDot },
  in_kitchen: { label: "In Kitchen", tone: "blue", icon: ChefHat },
  ready: { label: "Ready", tone: "green", icon: CircleCheck },
  paid: { label: "Paid", tone: "neutral", icon: Banknote },
  void: { label: "Void", tone: "red", icon: XCircle },
  // Tables
  available: { label: "Available", tone: "green", icon: CircleDashed },
  occupied: { label: "Occupied", tone: "orange", icon: CircleDot },
  bill_printed: { label: "Bill Printed", tone: "blue", icon: Receipt },
  cleaning: { label: "Cleaning", tone: "neutral", icon: Sparkles },
  // Kitchen tickets
  new: { label: "New", tone: "yellow", icon: BellRing },
  preparing: { label: "Preparing", tone: "orange", icon: Flame },
  // Users
  active: { label: "Active", tone: "green", icon: UserCheck },
  locked: { label: "Locked", tone: "red", icon: LockKeyhole },
  inactive: { label: "Inactive", tone: "neutral", icon: Ban },
} satisfies Record<string, { label: string; tone: Tone; icon: LucideIcon }>;

export type Status = keyof typeof STATUSES;

export function statusTone(status: Status) {
  return TONE[STATUSES[status].tone as Tone];
}

export function StatusBadge({ status, suffix, className }: { status: Status; suffix?: string; className?: string }) {
  const s = STATUSES[status];
  const Icon = s.icon;
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[12px] font-medium whitespace-nowrap", TONE[s.tone as Tone].badge, className)}>
      <Icon className="size-3.5" strokeWidth={2} />
      {s.label}
      {suffix}
    </span>
  );
}

export function StatusDot({ status, className }: { status: Status; className?: string }) {
  return <span aria-hidden="true" className={cn("inline-block size-2 rounded-full", statusTone(status).dot, className)} />;
}
