import { z } from "zod";
import { pinSchema, staffCodeSchema } from "./auth";

export const roleSchema = z.enum(["OWNER", "MANAGER", "CASHIER", "WAITER", "KITCHEN"]);

// Weak PINs are the first thing anyone tries at a till.
const WEAK_PINS = new Set(["0000", "1111", "1234", "4321", "123456", "000000", "111111"]);

export const strongPinSchema = pinSchema.refine((p) => !WEAK_PINS.has(p), {
  error: "Pick a less obvious PIN.",
});

export const createStaffSchema = z
  .object({
    name: z.string().trim().min(2, { error: "Enter the staff member's name." }).max(60),
    staffCode: staffCodeSchema,
    role: roleSchema,
    pin: strongPinSchema,
    email: z.union([z.literal(""), z.email({ error: "Enter a valid email." })]).optional(),
    password: z.string().optional(),
  })
  .superRefine((v, ctx) => {
    const backOffice = v.role === "OWNER" || v.role === "MANAGER";
    if (backOffice && !v.email) {
      ctx.addIssue({ code: "custom", path: ["email"], message: "Owners and managers need an email for back-office sign-in." });
    }
    if (backOffice && (!v.password || v.password.length < 8)) {
      ctx.addIssue({ code: "custom", path: ["password"], message: "Use at least 8 characters." });
    }
  });
export type CreateStaffInput = z.infer<typeof createStaffSchema>;

export const resetPinSchema = z.object({
  userId: z.uuid(),
  pin: strongPinSchema,
});
