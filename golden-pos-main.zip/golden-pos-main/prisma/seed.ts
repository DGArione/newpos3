// Seeds a starter team so the till can be used straight away.
// Change every PIN and the owner password after the first sign-in.
import "dotenv/config";
import { config as loadEnv } from "dotenv";
import bcrypt from "bcryptjs";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../lib/generated/prisma/client";
import type { Role } from "../lib/generated/prisma/enums";

loadEnv({ path: ".env.local" });

const db = new PrismaClient({
  adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }),
});

type Seed = { staffCode: string; name: string; role: Role; pin: string; email?: string; password?: string };

const staff: Seed[] = [
  { staffCode: "1001", name: "Owner", role: "OWNER", pin: "2580", email: "owner@goldenbeach.lk", password: "ChangeMe!2026" },
  { staffCode: "1002", name: "Nadeesha Perera", role: "MANAGER", pin: "3691", email: "manager@goldenbeach.lk", password: "ChangeMe!2026" },
  { staffCode: "2001", name: "Kasun Silva", role: "CASHIER", pin: "4826" },
  { staffCode: "3001", name: "Ruwan Fernando", role: "WAITER", pin: "5937" },
  { staffCode: "3002", name: "Ishara Jayasinghe", role: "WAITER", pin: "6048" },
  { staffCode: "4001", name: "Chef Mahesh", role: "KITCHEN", pin: "7159" },
];

async function main() {
  for (const s of staff) {
    await db.user.upsert({
      where: { staffCode: s.staffCode },
      update: {},
      create: {
        staffCode: s.staffCode,
        name: s.name,
        role: s.role,
        pinHash: await bcrypt.hash(s.pin, 10),
        email: s.email ?? null,
        passwordHash: s.password ? await bcrypt.hash(s.password, 10) : null,
      },
    });
  }
  console.log(`Seeded ${staff.length} staff.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
