"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { DuplicateError, eventStore, staffStore, type AuthEventType } from "@/lib/store";
import { hashSecret } from "@/lib/auth/hash";
import { requireArea, terminalName } from "@/lib/auth/session";
import { sessionStore } from "@/lib/store";
import { assignableRoles } from "@/lib/auth/roles";
import { createStaffSchema, resetPinSchema } from "@/lib/validators/staff";

export type FormState = { ok?: string; error?: string; fields?: Record<string, string> } | undefined;

function fieldErrors(error: z.ZodError) {
  const fields: Record<string, string> = {};
  for (const issue of error.issues) fields[String(issue.path[0] ?? "form")] ??= issue.message;
  return fields;
}

const audit = (type: AuthEventType, userId: string, actorId: string) =>
  eventStore.add({ type, method: null, userId, actorId, staffCode: null, terminal: terminalName() });

export async function createStaff(_prev: FormState, formData: FormData): Promise<FormState> {
  const actor = await requireArea("staff");
  const parsed = createStaffSchema.safeParse({
    name: formData.get("name"),
    staffCode: formData.get("staffCode"),
    role: formData.get("role"),
    pin: formData.get("pin"),
    email: (formData.get("email") as string | null) ?? "",
    password: (formData.get("password") as string | null) ?? "",
  });
  if (!parsed.success) return { fields: fieldErrors(parsed.error) };

  const v = parsed.data;
  if (!assignableRoles(actor.role).includes(v.role)) return { error: "You can't add staff with that role." };

  const backOffice = v.role === "OWNER" || v.role === "MANAGER";
  try {
    const user = await staffStore.create({
      name: v.name,
      staffCode: v.staffCode,
      role: v.role,
      pinHash: await hashSecret(v.pin),
      email: backOffice && v.email ? v.email.toLowerCase() : null,
      passwordHash: backOffice && v.password ? await hashSecret(v.password) : null,
    });
    await audit("USER_CREATED", user.id, actor.id);
  } catch (e) {
    if (e instanceof DuplicateError) {
      return e.field === "email"
        ? { fields: { email: "Email already in use." } }
        : { fields: { staffCode: "User ID already taken." } };
    }
    throw e;
  }

  revalidatePath("/staff");
  return { ok: `${v.name} added (User ID ${v.staffCode}).` };
}

async function manageable(userId: string) {
  const actor = await requireArea("staff");
  const target = await staffStore.byId(userId);
  if (!target) return { actor, target: null, error: "User not found." };
  if (!assignableRoles(actor.role).includes(target.role)) return { actor, target: null, error: "You can't change this user." };
  return { actor, target, error: null };
}

export async function resetPin(_prev: FormState, formData: FormData): Promise<FormState> {
  const parsed = resetPinSchema.safeParse({ userId: formData.get("userId"), pin: formData.get("pin") });
  if (!parsed.success) return { fields: fieldErrors(parsed.error) };

  const { actor, target, error } = await manageable(parsed.data.userId);
  if (!target) return { error: error ?? undefined };

  await staffStore.update(target.id, { pinHash: await hashSecret(parsed.data.pin), failedAttempts: 0, lockedUntil: null });
  await sessionStore.revokeAllFor(target.id); // new PIN signs them out everywhere
  await audit("PIN_RESET", target.id, actor.id);

  revalidatePath("/staff");
  return { ok: `PIN changed for ${target.name}.` };
}

export async function setActive(userId: string, active: boolean) {
  const { actor, target, error } = await manageable(userId);
  if (!target) return { error };
  if (target.id === actor.id) return { error: "You can't deactivate yourself." };

  await staffStore.update(target.id, { active });
  if (!active) await sessionStore.revokeAllFor(target.id);
  await audit(active ? "USER_REACTIVATED" : "USER_DEACTIVATED", target.id, actor.id);

  revalidatePath("/staff");
  return { error: null };
}

export async function unlock(userId: string) {
  const { actor, target, error } = await manageable(userId);
  if (!target) return { error };
  await staffStore.update(target.id, { failedAttempts: 0, lockedUntil: null });
  await audit("USER_UNLOCKED", target.id, actor.id);
  revalidatePath("/staff");
  return { error: null };
}
