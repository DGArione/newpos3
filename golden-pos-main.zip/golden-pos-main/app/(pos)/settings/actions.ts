"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { menuStore, settingsStore } from "@/lib/store";
import { requireArea } from "@/lib/auth/session";
import { deleteUpload, resolvePhoto } from "@/lib/media";
import { bannerSchema, brandingSchema } from "@/lib/validators/menu";
import { brandColorProblem, DEFAULT_BRAND_COLOR } from "@/lib/brand-color";

export type SettingsFormState = { ok?: string; error?: string; fields?: Record<string, string> } | undefined;

function fieldErrors(error: z.ZodError) {
  const fields: Record<string, string> = {};
  for (const issue of error.issues) fields[String(issue.path[0] ?? "form")] ??= issue.message;
  return fields;
}

// Branding shows on every screen and on the login page.
const refreshAll = () => revalidatePath("/", "layout");

export async function saveBranding(_prev: SettingsFormState, fd: FormData): Promise<SettingsFormState> {
  await requireArea("settings");
  const parsed = brandingSchema.safeParse({ restaurantName: fd.get("restaurantName"), tagline: fd.get("tagline") ?? "" });
  if (!parsed.success) return { fields: fieldErrors(parsed.error) };

  const current = await settingsStore.branding();
  const logo = await resolvePhoto(fd, "logo", current.logo);
  if (logo.error) return { fields: { logo: logo.error } };
  const loginImage = await resolvePhoto(fd, "loginImage", current.loginImage);
  if (loginImage.error) return { fields: { loginImage: loginImage.error } };
  const loginBackground = await resolvePhoto(fd, "loginBackground", current.loginBackground);
  if (loginBackground.error) return { fields: { loginBackground: loginBackground.error } };

  await settingsStore.saveBranding({ ...parsed.data, logo: logo.url, loginImage: loginImage.url, loginBackground: loginBackground.url });
  refreshAll();
  return { ok: "Branding saved." };
}

/** Changes the main colour of every screen, on every till. */
export async function saveBrandColor(hex: string): Promise<{ ok: string } | { error: string }> {
  await requireArea("settings");
  const color = String(hex).toLowerCase();
  const problem = brandColorProblem(color);
  if (problem) return { error: problem };
  await settingsStore.saveBranding({ brandColor: color === DEFAULT_BRAND_COLOR ? undefined : color });
  refreshAll();
  return { ok: "Colour saved for all screens." };
}

export async function saveBanner(_prev: SettingsFormState, fd: FormData): Promise<SettingsFormState> {
  await requireArea("settings");
  const parsed = bannerSchema.safeParse({
    id: (fd.get("id") as string) || undefined,
    title: fd.get("title"),
    text: fd.get("text") ?? "",
    itemId: (fd.get("itemId") as string) || undefined,
    active: fd.get("active") === "on",
  });
  if (!parsed.success) return { fields: fieldErrors(parsed.error) };
  const v = parsed.data;

  if (v.itemId && !(await menuStore.item(v.itemId))) return { fields: { itemId: "That dish is no longer on the menu." } };
  const existing = v.id ? (await settingsStore.banners()).find((b) => b.id === v.id) : undefined;
  if (v.id && !existing) return { error: "This banner no longer exists." };

  const photo = await resolvePhoto(fd, "image", existing?.image);
  if (photo.error) return { fields: { image: photo.error } };

  await settingsStore.saveBanner({ ...v, image: photo.url });
  refreshAll();
  return { ok: existing ? "Banner updated." : "Banner added to the home page." };
}

export async function deleteBanner(id: string) {
  await requireArea("settings");
  const banner = (await settingsStore.banners()).find((b) => b.id === id);
  if (!banner) return { error: "Banner not found." };
  await settingsStore.deleteBanner(id);
  await deleteUpload(banner.image);
  refreshAll();
  return { ok: "Banner deleted." };
}

export async function setBannerActive(id: string, active: boolean) {
  await requireArea("settings");
  const banner = (await settingsStore.banners()).find((b) => b.id === id);
  if (!banner) return;
  await settingsStore.saveBanner({ ...banner, active });
  refreshAll();
}
