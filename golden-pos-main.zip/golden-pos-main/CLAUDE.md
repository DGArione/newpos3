# CLAUDE.md — Golden Beach POS

Restaurant point of sale. Runs **local-first** on a PC in the restaurant (LAN, may be offline);
will later become **hybrid** (local server is the source of truth for sales, syncs to cloud).

## Stack (canonical)

| Layer | Choice |
|---|---|
| Framework | Next.js 16 (App Router, TypeScript strict). `proxy.ts`, not middleware |
| Data | **Now:** JSON file store `lib/store/index.ts` -> `data/golden-pos.json`, photos in `data/uploads` served by `app/media/[file]`. **Later:** PostgreSQL + Prisma 7 (schema in `prisma/`) |
| UI | Tailwind 4 + Base UI dialog, Lucide icons only; tokens in `app/globals.css` |
| Auth | Own implementation in `lib/auth/` — no hosted auth (must work offline) |

When the database is connected, rewrite `lib/store/index.ts` against Prisma with the same
function names; nothing else should need to change.

## Rules

- **No internet at runtime or build.** No CDN scripts, no remote fonts — bundled fonts only.
- **Money is integer cents** (LKR × 100). Format only with `lib/money.ts`. Never floats.
- **UUID primary keys, `created_at`/`updated_at` on every table, soft delete via `deleted_at`,
  timestamps in UTC.** These make the later cloud sync possible — don't skip them.
- **Every protected page calls `requireArea("<area>")`** first. The proxy only checks that a
  cookie exists; it is not authorization. Role → area rules live in `lib/auth/roles.ts`.
- **Every server action re-checks the session and role** — never trust the client.
- PINs/passwords: bcryptjs via `lib/auth/hash.ts`. Session cookie holds a random token; DB
  stores only its SHA-256. Log auth and staff changes to `auth_events`.
- Mutations go through Server Actions. Forms that can return field errors submit via
  `keepFormOnSubmit()` so React 19 doesn't wipe what staff typed.
- Zod schemas in `lib/validators/` are the source of truth for input shapes.
- `lib/mock/` is temporary sample data. When a feature gets real tables, delete its mock.

## Design

Look: light grey background, rounded white cards, brand-colour accent (orange by default) (based on the "Foodin" POS
reference). Follow **golden-pos-design** + **frontend-design** skills (`skills-to-install/`).
- Palette: brand colour (`pay`, Pay/Add/active), default orange `#F6990D`. The owner can change it in
  Settings > System colour: it is saved as `branding.brandColor`, injected as `--brand-base` in
  `app/layout.tsx`, and every brand token (`pay`, `brand-soft`, `brand-deep`, `selected`, `ring`) is
  derived from it with `color-mix`. **Never hard-code the orange**; use the tokens or `var(--brand-base)`.
  Others: purple `#7471F6` (`kot`, kitchen),
  blue `#5B88FC` (`info`), red `#F52121` (`void`), green `#35C344` (`success`), violet `#9D61E8` (`warn`).
  Use `*-ink` tokens for coloured text on tinted backgrounds. Tokens only, no raw colours.
- Font: Poppins, bundled in `app/fonts` (no internet). Light default, dark per terminal (cookie `gp_theme`).
- Shell: `Sidebar` (coloured module icons) + `AppHeader` ("Hello, name") + screens inside `<Screen>` cards.
- Photos: uploaded through `ImageField` + `resolvePhoto()` (`lib/media.ts`, checks real file type, 5 MB max, no SVG).
  Without a photo, `DishImage` shows a placeholder. Menu and Settings screens are owner/manager only.
- All statuses via `<StatusBadge>`. Quick edits inline or in a `Popover`; `Modal` only for payment and user forms.
- Keyboard: F2/F4/F8/F9/F10 and Ctrl+K. New shared component: add it to `/design-guide` and the component index.

## Migrations

`npx prisma migrate dev --name <change>` on a dev machine; `npx prisma migrate deploy` on the till.
Destructive migrations need a written rollback note.

## Next phases

1. Menu in DB (categories, items, modifiers, sold-out toggle) + menu admin.
2. Orders/order items persisted; tables & areas in DB; KOT printing per station (ESC/POS).
3. Payments (cash, card, PayHere) with `payment_events` audit; bill printing; shift cash-up.
4. Reports. 5. Cloud sync (outbox table) for hybrid.
