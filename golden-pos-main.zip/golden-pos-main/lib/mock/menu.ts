// Starter menu. Copied into the data file on first run; after that,
// edit the menu from the Menu screen (owners and managers).

// Types live in lib/types/menu.ts; re-exported for older imports.
import type { Category, MenuItem } from "@/lib/types/menu";
export type { Station, IconName, Category, MenuItem } from "@/lib/types/menu";

export const categories: Category[] = [
  { id: "starters", name: "Starters", icon: "starters", color: "#d9772b" },
  { id: "seafood", name: "Seafood Grill", icon: "seafood", color: "#2a7d8f" },
  { id: "kottu", name: "Kottu & Rice", icon: "kottu", color: "#b3442a" },
  { id: "curries", name: "Rice & Curry", icon: "curries", color: "#6f8a1f" },
  { id: "drinks", name: "Beverages", icon: "drinks", color: "#3a68ad" },
  { id: "desserts", name: "Desserts", icon: "desserts", color: "#a74e83" },
];

const lkr = (rupees: number) => rupees * 100;

export const menu: MenuItem[] = [
  { id: "m1", code: 101, categoryId: "starters", name: "Hot Butter Cuttlefish", price: lkr(1650), station: "HOT_KITCHEN", icon: "flame", desc: "Crispy cuttlefish, chilli and spring onion" },
  { id: "m2", code: 102, categoryId: "starters", name: "Devilled Chicken", price: lkr(1450), station: "HOT_KITCHEN", icon: "drumstick", desc: "Wok-tossed with capsicum and onion" },
  { id: "m3", code: 103, categoryId: "starters", name: "Prawn Cutlets (6)", price: lkr(1200), station: "HOT_KITCHEN", icon: "shrimp", desc: "Golden fried, served with chilli sauce" },
  { id: "m4", code: 104, categoryId: "starters", name: "Isso Wade (4)", price: lkr(950), station: "HOT_KITCHEN", icon: "shrimp", desc: "Lentil prawn fritters, street style" },
  { id: "m5", code: 105, categoryId: "starters", name: "Chilli Cashew", price: lkr(1100), station: "HOT_KITCHEN", icon: "flame", desc: "Roasted cashews with chilli and curry leaves" },
  { id: "m29", code: 106, categoryId: "starters", name: "Garden Salad", price: lkr(850), station: "HOT_KITCHEN", icon: "salad", desc: "Greens, tomato, cucumber, lime dressing" },

  { id: "m6", code: 201, categoryId: "seafood", name: "Grilled Seer Fish", price: lkr(3200), station: "HOT_KITCHEN", icon: "fish", desc: "Whole fillet, lime and garlic butter" },
  { id: "m7", code: 202, categoryId: "seafood", name: "Jumbo Prawns Garlic Butter", price: lkr(4800), station: "HOT_KITCHEN", icon: "shrimp", desc: "Six prawns, garlic butter, rice or fries" },
  { id: "m8", code: 203, categoryId: "seafood", name: "Lagoon Crab Pepper", price: lkr(5600), station: "HOT_KITCHEN", icon: "shell", desc: "Lagoon crab in black pepper sauce", soldOut: true },
  { id: "m9", code: 204, categoryId: "seafood", name: "Calamari Rings", price: lkr(1900), station: "HOT_KITCHEN", icon: "flame", desc: "Battered rings with tartare sauce" },
  { id: "m10", code: 205, categoryId: "seafood", name: "Seafood Platter (2 pax)", price: lkr(8900), station: "HOT_KITCHEN", icon: "fish", desc: "Fish, prawns, cuttlefish, crab, two sides" },

  { id: "m11", code: 301, categoryId: "kottu", name: "Chicken Kottu", price: lkr(1350), station: "HOT_KITCHEN", icon: "wheat", desc: "Chopped roti, chicken, egg and leeks" },
  { id: "m12", code: 302, categoryId: "kottu", name: "Cheese Seafood Kottu", price: lkr(2100), station: "HOT_KITCHEN", icon: "wheat", desc: "Prawns, cuttlefish and melted cheese" },
  { id: "m13", code: 303, categoryId: "kottu", name: "Seafood Fried Rice", price: lkr(1850), station: "HOT_KITCHEN", icon: "pot", desc: "Basmati, prawns, cuttlefish, egg" },
  { id: "m14", code: 304, categoryId: "kottu", name: "Chicken Biriyani", price: lkr(1750), station: "HOT_KITCHEN", icon: "pot", desc: "Spiced rice, chicken, raita, egg" },
  { id: "m15", code: 305, categoryId: "kottu", name: "Veg Nasi Goreng", price: lkr(1300), station: "HOT_KITCHEN", icon: "pot", desc: "Indonesian fried rice, fried egg" },

  { id: "m16", code: 401, categoryId: "curries", name: "Rice & Curry Fish", price: lkr(1250), station: "HOT_KITCHEN", icon: "soup", desc: "Red rice, fish curry, three vegetables" },
  { id: "m17", code: 402, categoryId: "curries", name: "Rice & Curry Chicken", price: lkr(1150), station: "HOT_KITCHEN", icon: "soup", desc: "Red rice, chicken curry, three vegetables" },
  { id: "m18", code: 403, categoryId: "curries", name: "Dhal & Pol Sambol", price: lkr(650), station: "HOT_KITCHEN", icon: "soup", desc: "Coconut dhal with fresh pol sambol" },
  { id: "m19", code: 404, categoryId: "curries", name: "Egg Hoppers (2)", price: lkr(600), station: "HOT_KITCHEN", icon: "egg", desc: "Two egg hoppers with lunu miris" },

  { id: "m20", code: 501, categoryId: "drinks", name: "King Coconut", price: lkr(450), station: "BAR", icon: "coconut", desc: "Served in the shell" },
  { id: "m21", code: 502, categoryId: "drinks", name: "Fresh Lime Soda", price: lkr(550), station: "BAR", icon: "citrus", desc: "Fresh lime, soda, a little salt" },
  { id: "m22", code: 503, categoryId: "drinks", name: "Iced Ceylon Tea", price: lkr(500), station: "BAR", icon: "coffee", desc: "Brewed strong, lemon and ice" },
  { id: "m23", code: 504, categoryId: "drinks", name: "Mango Lassi", price: lkr(750), station: "BAR", icon: "citrus", desc: "Mango, yoghurt, cardamom" },
  { id: "m24", code: 505, categoryId: "drinks", name: "Lion Lager 625ml", price: lkr(1350), station: "BAR", icon: "beer", desc: "Local lager, chilled" },
  { id: "m25", code: 506, categoryId: "drinks", name: "Arrack Sour", price: lkr(1600), station: "BAR", icon: "cocktail", desc: "Coconut arrack, lime, sugar syrup" },

  { id: "m26", code: 601, categoryId: "desserts", name: "Watalappan", price: lkr(650), station: "PASTRY", icon: "cake", desc: "Jaggery and coconut custard" },
  { id: "m27", code: 602, categoryId: "desserts", name: "Curd & Kithul Treacle", price: lkr(700), station: "PASTRY", icon: "icecream", desc: "Buffalo curd with kithul treacle" },
  { id: "m28", code: 603, categoryId: "desserts", name: "Fruit Salad & Ice Cream", price: lkr(850), station: "PASTRY", icon: "icecream", desc: "Seasonal fruit with vanilla ice cream" },
];

// Shown in the banner on the Billing screen.
export const todaysSpecial = { itemId: "m6", title: "Chef's special today", note: "Grilled Seer Fish with lime and garlic butter" };
