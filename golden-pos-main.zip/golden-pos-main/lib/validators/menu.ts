import { z } from "zod";
import { CATEGORY_COLORS, CATEGORY_ICONS } from "@/lib/types/menu";

// "1,650.50" -> 165050 cents
const rupees = z
  .string()
  .trim()
  .transform((v) => v.replace(/,/g, ""))
  .refine((v) => /^\d{1,7}(\.\d{1,2})?$/.test(v), { error: "Enter a price like 1650 or 1650.50." })
  .transform((v) => Math.round(Number(v) * 100))
  .refine((c) => c > 0, { error: "Price must be more than zero." });

export const itemSchema = z.object({
  id: z.string().optional(),
  name: z.string().trim().min(2, { error: "Enter the dish name." }).max(60),
  code: z.coerce.number<string>().int({ error: "Code is a whole number." }).min(1, { error: "Enter an item code." }).max(99999),
  categoryId: z.string().min(1, { error: "Choose a category." }),
  price: rupees,
  station: z.enum(["HOT_KITCHEN", "BAR", "PASTRY"]),
  desc: z.string().trim().max(80, { error: "Keep it under 80 characters." }),
  soldOut: z.boolean(),
});

export const categorySchema = z.object({
  id: z.string().optional(),
  name: z.string().trim().min(2, { error: "Enter a category name." }).max(30),
  icon: z.enum(CATEGORY_ICONS as [string, ...string[]]),
  color: z.string().refine((c) => CATEGORY_COLORS.includes(c), { error: "Pick a colour." }),
});

export const bannerSchema = z.object({
  id: z.string().optional(),
  title: z.string().trim().min(2, { error: "Enter a title." }).max(50),
  text: z.string().trim().max(100, { error: "Keep it under 100 characters." }),
  itemId: z.string().optional(),
  active: z.boolean(),
});

export const brandingSchema = z.object({
  restaurantName: z.string().trim().min(2, { error: "Enter the restaurant name." }).max(30),
  tagline: z.string().trim().max(40),
});
