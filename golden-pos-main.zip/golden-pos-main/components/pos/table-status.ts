// Kept for older imports. New code: use StatusBadge/statusTone with TABLE_STATUS_KEY.
import type { TableStatus } from "@/lib/mock/floor";
import { STATUSES, statusTone } from "./status-badge";
import { TABLE_STATUS_KEY } from "@/app/(pos)/pos/table-picker";

export const TABLE_STATUS = Object.fromEntries(
  (Object.keys(TABLE_STATUS_KEY) as TableStatus[]).map((s) => {
    const key = TABLE_STATUS_KEY[s];
    return [s, { label: STATUSES[key].label, tile: statusTone(key).tile, dot: statusTone(key).dot }];
  }),
) as Record<TableStatus, { label: string; tile: string; dot: string }>;
