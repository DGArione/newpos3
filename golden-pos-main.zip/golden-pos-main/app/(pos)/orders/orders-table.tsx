"use client";

import { useState } from "react";
import { Banknote, Bike, CircleDollarSign, CreditCard, Hourglass, QrCode, ReceiptText, Search, ShoppingBag, UtensilsCrossed, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { rsExact } from "@/lib/money";
import type { Order, OrderStatus, OrderType } from "@/lib/mock/orders";
import { MetricCard } from "@/components/pos/metric-card";
import { Segmented } from "@/components/pos/segmented";
import { StatusBadge, type Status } from "@/components/pos/status-badge";
import { EmptyState } from "@/components/pos/empty-state";

const STATUS_KEY: Record<OrderStatus, Status> = { open: "open", sent: "in_kitchen", ready: "ready", paid: "paid", void: "void" };
const LABEL: Record<OrderStatus, string> = { open: "Open", sent: "In Kitchen", ready: "Ready", paid: "Paid", void: "Void" };
const TYPE: Record<OrderType, { label: string; icon: LucideIcon }> = {
  "dine-in": { label: "Dine In", icon: UtensilsCrossed },
  takeaway: { label: "Take Away", icon: ShoppingBag },
  delivery: { label: "Delivery", icon: Bike },
};
const PAY_ICON = { Cash: Banknote, Card: CreditCard, PayHere: QrCode } as const;

export function OrdersTable({ orders }: { orders: Order[] }) {
  const [filter, setFilter] = useState<OrderStatus | "all">("all");
  const [q, setQ] = useState("");

  const rows = orders.filter(
    (o) => (filter === "all" || o.status === filter) && (!q || String(o.no).includes(q) || (o.table ?? o.customer ?? "").toLowerCase().includes(q.toLowerCase())),
  );
  const paid = orders.filter((o) => o.status === "paid");
  const open = orders.filter((o) => o.status !== "paid" && o.status !== "void");
  const count = (s: OrderStatus) => orders.filter((o) => o.status === s).length;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="grid grid-cols-2 gap-px border-b border-border bg-border md:grid-cols-4">
        <MetricCard icon={ReceiptText} label="Orders today" value={String(orders.length)} />
        <MetricCard icon={Hourglass} label="Open orders" value={String(open.length)} />
        <MetricCard icon={CircleDollarSign} label="Open value" value={`Rs. ${rsExact(open.reduce((s, o) => s + o.total, 0))}`} />
        <MetricCard icon={Banknote} label="Collected" value={`Rs. ${rsExact(paid.reduce((s, o) => s + o.total, 0))}`} description={`${paid.length} bills settled`} />
      </div>

      <div className="flex flex-wrap items-center gap-2 border-b border-border bg-panel px-4 py-2">
        <Segmented
          label="Status"
          options={[{ value: "all" as const, label: "All", count: orders.length }, ...(Object.keys(LABEL) as OrderStatus[]).map((s) => ({ value: s, label: LABEL[s], count: count(s) }))]}
          value={filter}
          onChange={setFilter}
        />
        <label className="relative ml-auto">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Order no., table or customer"
            className="h-8 w-64 rounded-md border border-input bg-background pl-8 pr-2 text-[13px] outline-none placeholder:text-muted-foreground focus-visible:border-ring"
          />
        </label>
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-auto bg-panel">
        {rows.length === 0 ? (
          <EmptyState icon={ReceiptText} message="No orders here" hint="Change the filter or clear the search." />
        ) : (
          <table className="w-full min-w-[820px] text-[13px]">
            <thead className="sticky top-0 z-10 bg-muted text-left text-[12px] text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-4 py-2 font-semibold">Order</th>
                <th className="px-3 py-2 font-semibold">Type</th>
                <th className="px-3 py-2 font-semibold">Table / Customer</th>
                <th className="px-3 py-2 text-right font-semibold">Items</th>
                <th className="px-3 py-2 font-semibold">Steward</th>
                <th className="px-3 py-2 font-semibold">Opened</th>
                <th className="px-3 py-2 font-semibold">Payment</th>
                <th className="px-3 py-2 text-right font-semibold">Amount</th>
                <th className="px-4 py-2 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((o) => {
                const T = TYPE[o.type];
                const P = o.payment ? PAY_ICON[o.payment] : null;
                return (
                  <tr key={o.no} className="border-b border-line hover:bg-muted/60">
                    <td className="px-4 py-2 font-mono text-[12px] font-semibold">{o.no}</td>
                    <td className="px-3 py-2"><span className="flex items-center gap-1.5"><T.icon className="size-4 text-muted-foreground" />{T.label}</span></td>
                    <td className="px-3 py-2">{o.table ? `Table ${o.table}` : o.customer}</td>
                    <td className="num px-3 py-2 text-right">{o.items}</td>
                    <td className="px-3 py-2">{o.server}</td>
                    <td className="num px-3 py-2 text-muted-foreground">{o.minutesAgo} min ago</td>
                    <td className="px-3 py-2">{P ? <span className="flex items-center gap-1.5"><P className="size-4 text-muted-foreground" />{o.payment}</span> : <span className="text-muted-foreground">-</span>}</td>
                    <td className={cn("num px-3 py-2 text-right font-semibold", o.status === "void" && "text-muted-foreground line-through")}>{rsExact(o.total)}</td>
                    <td className="px-4 py-2"><StatusBadge status={STATUS_KEY[o.status]} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
