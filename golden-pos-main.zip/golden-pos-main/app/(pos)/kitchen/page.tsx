import type { Metadata } from "next";
import { ChefHat } from "lucide-react";
import { requireArea } from "@/lib/auth/session";
import { kitchenTickets } from "@/lib/mock/orders";
import { PageHeader } from "@/components/pos/page-header";
import { Screen } from "@/components/pos/screen";
import { KitchenBoard } from "./kitchen-board";

export const metadata: Metadata = { title: "KOT" };

export default async function KitchenPage() {
  await requireArea("kitchen");
  return (
    <Screen>
      <PageHeader title="Kitchen Orders (KOT)" icon={ChefHat} meta="Oldest first. Red after 15 minutes." />
      <KitchenBoard initial={kitchenTickets} />
    </Screen>
  );
}
