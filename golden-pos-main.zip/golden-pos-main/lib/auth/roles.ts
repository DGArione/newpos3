export type Role = "OWNER" | "MANAGER" | "CASHIER" | "WAITER" | "KITCHEN";
export type AuthMethod = "PIN" | "PASSWORD";

export const ROLES: Role[] = ["OWNER", "MANAGER", "CASHIER", "WAITER", "KITCHEN"];

export const ROLE_LABEL: Record<Role, string> = {
  OWNER: "Owner",
  MANAGER: "Manager",
  CASHIER: "Cashier",
  WAITER: "Waiter",
  KITCHEN: "Kitchen",
};

// Which roles can open each module. The proxy only checks that a session
// cookie exists; these rules are enforced on the server per page.
export const ACCESS = {
  pos: ["OWNER", "MANAGER", "CASHIER", "WAITER"],
  tables: ["OWNER", "MANAGER", "CASHIER", "WAITER"],
  orders: ["OWNER", "MANAGER", "CASHIER"],
  kitchen: ["OWNER", "MANAGER", "KITCHEN"],
  reports: ["OWNER", "MANAGER"],
  staff: ["OWNER", "MANAGER"],
  menu: ["OWNER", "MANAGER"],
  settings: ["OWNER", "MANAGER"],
  design: ["OWNER", "MANAGER"],
} as const satisfies Record<string, readonly Role[]>;

export type Area = keyof typeof ACCESS;

export function canAccess(role: Role, area: Area) {
  return (ACCESS[area] as readonly Role[]).includes(role);
}

export function homeFor(role: Role) {
  return role === "KITCHEN" ? "/kitchen" : "/pos";
}

// Managers can't create or edit owners or other managers.
export function assignableRoles(actor: Role): Role[] {
  if (actor === "OWNER") return [...ROLES];
  if (actor === "MANAGER") return ["CASHIER", "WAITER", "KITCHEN"];
  return [];
}
