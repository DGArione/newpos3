import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { KeyRound } from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { homeFor } from "@/lib/auth/roles";
import { PinLogin } from "./pin-login";

export const metadata: Metadata = { title: "Login" };

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect(homeFor(user.role));

  return (
    <div>
      <h1 className="text-[20px] font-semibold">Staff Login</h1>
      <p className="text-[13px] text-muted-foreground">Enter your User ID and PIN.</p>
      <PinLogin />
      <Link
        href="/login/password"
        className="mt-4 flex items-center justify-center gap-1.5 text-[13px] font-semibold text-pay-ink hover:underline"
      >
        <KeyRound className="size-4" /> Back office login (email &amp; password)
      </Link>
    </div>
  );
}
