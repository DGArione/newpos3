// TEMPORARY sample orders for the Orders and Kitchen screens.

export type OrderStatus = "open" | "sent" | "ready" | "paid" | "void";
export type OrderType = "dine-in" | "takeaway" | "delivery";

export type Order = {
  no: number;
  type: OrderType;
  table?: string;
  customer?: string;
  items: number;
  total: number; // cents
  status: OrderStatus;
  server: string;
  minutesAgo: number;
  payment?: "Cash" | "Card" | "PayHere";
};

export const orders: Order[] = [
  { no: 1048, type: "dine-in", table: "D5", items: 3, total: 245000, status: "sent", server: "Ruwan", minutesAgo: 12 },
  { no: 1047, type: "takeaway", customer: "Dilan, 077 ••• 4471", items: 2, total: 349000, status: "ready", server: "Kasun", minutesAgo: 19 },
  { no: 1046, type: "dine-in", table: "T2", items: 5, total: 538000, status: "sent", server: "Ishara", minutesAgo: 24 },
  { no: 1045, type: "delivery", customer: "PickMe Food #88213", items: 4, total: 612000, status: "ready", server: "Kasun", minutesAgo: 31 },
  { no: 1044, type: "dine-in", table: "D1", items: 4, total: 612000, status: "open", server: "Ruwan", minutesAgo: 38 },
  { no: 1043, type: "dine-in", table: "B1", items: 3, total: 432000, status: "sent", server: "Kasun", minutesAgo: 55 },
  { no: 1042, type: "dine-in", table: "D3", items: 9, total: 1489000, status: "open", server: "Ishara", minutesAgo: 71 },
  { no: 1041, type: "takeaway", customer: "Walk-in", items: 1, total: 135000, status: "paid", server: "Kasun", minutesAgo: 84, payment: "Cash" },
  { no: 1040, type: "dine-in", table: "T4", items: 12, total: 2371000, status: "paid", server: "Ruwan", minutesAgo: 102, payment: "Card" },
  { no: 1039, type: "delivery", customer: "Uber Eats #5K2Q", items: 2, total: 330000, status: "paid", server: "Kasun", minutesAgo: 118, payment: "PayHere" },
  { no: 1038, type: "dine-in", table: "D2", items: 2, total: 190000, status: "void", server: "Ishara", minutesAgo: 131 },
];

export type KitchenTicket = {
  no: number;
  table: string;
  station: "Hot kitchen" | "Bar" | "Pastry";
  minutesAgo: number;
  stage: "new" | "cooking" | "ready";
  lines: { qty: number; name: string; note?: string }[];
};

export const kitchenTickets: KitchenTicket[] = [
  { no: 1048, table: "D5", station: "Hot kitchen", minutesAgo: 2, stage: "new", lines: [{ qty: 2, name: "Hot butter cuttlefish" }, { qty: 1, name: "Cheese seafood kottu", note: "Less spicy" }] },
  { no: 1046, table: "T2", station: "Hot kitchen", minutesAgo: 9, stage: "cooking", lines: [{ qty: 1, name: "Grilled seer fish", note: "No butter, allergy" }, { qty: 2, name: "Chicken biriyani" }] },
  { no: 1046, table: "T2", station: "Bar", minutesAgo: 9, stage: "ready", lines: [{ qty: 2, name: "King coconut" }, { qty: 1, name: "Mango lassi" }] },
  { no: 1043, table: "B1", station: "Hot kitchen", minutesAgo: 17, stage: "cooking", lines: [{ qty: 1, name: "Seafood platter for two" }] },
  { no: 1047, table: "Takeaway", station: "Hot kitchen", minutesAgo: 19, stage: "ready", lines: [{ qty: 1, name: "Chicken kottu" }, { qty: 1, name: "Seafood fried rice" }] },
  { no: 1049, table: "D1", station: "Pastry", minutesAgo: 1, stage: "new", lines: [{ qty: 2, name: "Watalappan" }] },
];
