import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactCompiler: true,
  // Runs on a local machine in the restaurant first; keep the server output
  // self-contained so the same build can later move to a cloud host.
  output: "standalone",
  experimental: {
    // Menu and banner photos are uploaded through server actions (max 5 MB + form overhead).
    serverActions: { bodySizeLimit: "6mb" },
  },
};

export default nextConfig;
