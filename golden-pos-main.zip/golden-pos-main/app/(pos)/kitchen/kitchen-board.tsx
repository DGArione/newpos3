"use client";

import { useState } from "react";
import { BellRing, Check, ChefHat, Clock3, Flame, NotebookPen } from "lucide-react";
import { cn } from "@/lib/utils";
import type { KitchenTicket } from "@/lib/mock/orders";
import { Btn } from "@/components/pos/button";
import { Segmented } from "@/components/pos/segmented";
import { StatusBadge, type Status } from "@/components/pos/status-badge";
import { EmptyState } from "@/components/pos/empty-state";

type Stage = KitchenTicket["stage"];
const COLUMNS: { stage: Stage; status: Status }[] = [
  { stage: "new", status: "new" },
  { stage: "cooking", status: "preparing" },
  { stage: "ready", status: "ready" },
];
const STATIONS = ["All", "Hot kitchen", "Bar", "Pastry"] as const;

// Ticket age is the one thing the kitchen must see at a glance.
const ageClass = (min: number) => (min >= 15 ? "bg-void text-on-tone" : min >= 10 ? "bg-kot text-on-tone" : "bg-muted text-foreground");

export function KitchenBoard({ initial }: { initial: KitchenTicket[] }) {
  // TODO(db phase): live updates over WebSocket instead of local state.
  const [tickets, setTickets] = useState(initial.map((t, i) => ({ ...t, id: `${t.no}-${t.station}-${i}` })));
  const [station, setStation] = useState<(typeof STATIONS)[number]>("All");

  const advance = (id: string) =>
    setTickets((prev) =>
      prev.flatMap((t) => (t.id !== id ? [t] : t.stage === "new" ? [{ ...t, stage: "cooking" as const }] : t.stage === "cooking" ? [{ ...t, stage: "ready" as const }] : [])),
    );

  const shown = tickets.filter((t) => station === "All" || t.station === station);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center gap-2 border-b border-border bg-panel px-4 py-2">
        <Segmented
          label="Station"
          options={STATIONS.map((s) => ({ value: s, label: s, count: tickets.filter((t) => s === "All" || t.station === s).length }))}
          value={station}
          onChange={setStation}
        />
      </div>

      <div className="grid min-h-0 flex-1 gap-px bg-border md:grid-cols-3">
        {COLUMNS.map((col) => {
          const list = shown.filter((t) => t.stage === col.stage).sort((a, b) => b.minutesAgo - a.minutesAgo);
          return (
            <section key={col.stage} className="flex min-h-0 flex-col bg-background">
              <h2 className="flex h-9 items-center justify-between border-b border-border bg-panel px-3">
                <StatusBadge status={col.status} />
                <span className="num text-[12px] text-muted-foreground">{list.length} tickets</span>
              </h2>
              <div className="scroll-thin min-h-0 flex-1 space-y-2 overflow-y-auto p-2">
                {list.length === 0 && <EmptyState icon={ChefHat} message="No tickets" />}
                {list.map((t) => (
                  <article key={t.id} className="overflow-hidden rounded-md border border-border bg-panel">
                    <header className="flex items-center justify-between border-b border-line px-2.5 py-1.5 text-[13px]">
                      <span className="font-semibold">
                        {t.table === "Takeaway" ? "Take Away" : `Table ${t.table}`}
                        <span className="ml-2 font-mono text-[12px] font-normal text-muted-foreground">{t.no}</span>
                      </span>
                      <span className={cn("num flex items-center gap-1 rounded px-1.5 py-0.5 text-[12px] font-semibold", ageClass(t.minutesAgo))}>
                        <Clock3 className="size-3.5" /> {t.minutesAgo} min
                      </span>
                    </header>
                    <ul className="divide-y divide-line text-[14px]">
                      {t.lines.map((l, i) => (
                        <li key={i} className="flex gap-2 px-2.5 py-1.5">
                          <span className="num w-7 font-bold">{l.qty}x</span>
                          <span>
                            {l.name}
                            {l.note && <span className="mt-0.5 flex items-center gap-1 text-[12px] font-semibold text-kot"><NotebookPen className="size-3" /> {l.note}</span>}
                          </span>
                        </li>
                      ))}
                    </ul>
                    <footer className="flex items-center justify-between border-t border-line px-2.5 py-1.5">
                      <span className="text-[12px] text-muted-foreground">{t.station}</span>
                      {col.stage === "new" && <Btn tone="kot" size="sm" onClick={() => advance(t.id)}><Flame /> Start</Btn>}
                      {col.stage === "cooking" && <Btn tone="pay" size="sm" onClick={() => advance(t.id)}><Check /> Ready</Btn>}
                      {col.stage === "ready" && <Btn size="sm" onClick={() => advance(t.id)}><BellRing /> Served</Btn>}
                    </footer>
                  </article>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
