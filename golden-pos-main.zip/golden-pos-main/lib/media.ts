import "server-only";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { UPLOAD_DIR } from "@/lib/store";

export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;

// Checked against the file's first bytes, not its name, so a renamed file can't slip through.
// SVG is deliberately not allowed (it can carry scripts).
function detect(buf: Buffer): "jpg" | "png" | "webp" | null {
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "png";
  if (buf.subarray(0, 4).toString("ascii") === "RIFF" && buf.subarray(8, 12).toString("ascii") === "WEBP") return "webp";
  return null;
}

export type UploadResult = { url: string } | { error: string };

/** Saves an uploaded photo to data/uploads and returns its /media URL. */
export async function saveUpload(file: File): Promise<UploadResult> {
  if (file.size === 0) return { error: "The file is empty." };
  if (file.size > MAX_UPLOAD_BYTES) return { error: "Photo is larger than 5 MB. Use a smaller one." };
  const buf = Buffer.from(await file.arrayBuffer());
  const ext = detect(buf);
  if (!ext) return { error: "Use a JPG, PNG or WebP photo." };
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  const name = `${randomUUID()}.${ext}`;
  await fs.writeFile(path.join(UPLOAD_DIR, name), buf);
  return { url: `/media/${name}` };
}

/** Removes a previously uploaded photo. Ignores anything that isn't ours. */
export async function deleteUpload(url: string | undefined | null) {
  const m = url?.match(/^\/media\/([a-f0-9-]{36}\.(?:jpg|png|webp))$/);
  if (!m) return;
  await fs.rm(path.join(UPLOAD_DIR, m[1]), { force: true });
}

/** Reads an optional photo field: a new file wins, "remove" clears, otherwise keep the old one. */
export async function resolvePhoto(formData: FormData, field: string, current?: string): Promise<{ url?: string; error?: string }> {
  const file = formData.get(field);
  const remove = formData.get(`${field}Remove`) === "1";
  if (file instanceof File && file.size > 0) {
    const r = await saveUpload(file);
    if ("error" in r) return { error: r.error };
    await deleteUpload(current);
    return { url: r.url };
  }
  if (remove) {
    await deleteUpload(current);
    return { url: undefined };
  }
  return { url: current };
}
