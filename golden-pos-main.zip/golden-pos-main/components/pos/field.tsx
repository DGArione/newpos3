import { cn } from "@/lib/utils";

export const inputClass =
  "h-9 w-full rounded-md border border-input bg-panel px-2.5 text-[14px] outline-none focus-visible:border-info focus-visible:ring-2 focus-visible:ring-info/20 aria-invalid:border-void";

export function Field({
  label,
  htmlFor,
  error,
  hint,
  className,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  hint?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={cn("space-y-1", className)}>
      <label htmlFor={htmlFor} className="block text-[12px] font-semibold text-muted-foreground">
        {label}
      </label>
      {children}
      {error ? (
        <p className="text-[12px] font-medium text-void">{error}</p>
      ) : hint ? (
        <p className="text-[12px] text-muted-foreground">{hint}</p>
      ) : null}
    </div>
  );
}
