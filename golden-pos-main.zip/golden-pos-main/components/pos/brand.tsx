import { cn } from "@/lib/utils";
import { LogoMark } from "./logo";

/** The restaurant's uploaded logo, or the built-in sun-and-waves mark. */
export function BrandMark({ logo, className }: { logo?: string; className?: string }) {
  if (logo) {
    // eslint-disable-next-line @next/next/no-img-element -- local upload, served by /media
    return <img src={logo} alt="" className={cn("size-9 rounded-md object-contain", className)} />;
  }
  return <LogoMark className={cn("size-9", className)} />;
}

/** Restaurant name with the first word in the brand colour. */
export function BrandName({ name, className }: { name: string; className?: string }) {
  const [first, ...rest] = name.trim().split(/\s+/);
  return (
    <span className={cn("font-semibold leading-tight", className)}>
      <span className="text-pay">{first}</span>
      {rest.length > 0 && <span className="text-foreground"> {rest.join(" ")}</span>}
    </span>
  );
}
