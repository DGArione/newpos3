import { cn } from "@/lib/utils";

/** Rounded white card that holds a whole screen (everything except Billing). */
export function Screen({ children, className }: { children: React.ReactNode; className?: string }) {
  return <section className={cn("flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl bg-panel", className)}>{children}</section>;
}
