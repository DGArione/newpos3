"use client";

import { useState } from "react";
import { NotebookPen } from "lucide-react";
import { Modal } from "@/components/ui/sheet-dialog";
import { Btn } from "@/components/pos/button";
import { cn } from "@/lib/utils";

const QUICK = ["Less spicy", "Extra spicy", "No onion", "No butter", "Allergy - check with steward", "Serve first", "Parcel"];

export function NoteDialog({
  open,
  itemName,
  initial,
  onClose,
  onSave,
}: {
  open: boolean;
  itemName: string;
  initial: string;
  onClose: () => void;
  onSave: (note: string) => void;
}) {
  return (
    <Modal open={open} onOpenChange={(o) => !o && onClose()} title="Kitchen note" icon={NotebookPen} description={itemName}>
      {open && <NoteForm key={itemName + initial} initial={initial} onSave={onSave} onCancel={onClose} />}
    </Modal>
  );
}

function NoteForm({ initial, onSave, onCancel }: { initial: string; onSave: (n: string) => void; onCancel: () => void }) {
  const [note, setNote] = useState(initial);
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSave(note.trim()); }}>
      <div className="flex flex-wrap gap-1.5">
        {QUICK.map((q) => (
          <button
            key={q}
            type="button"
            onClick={() => setNote((n) => (n.includes(q) ? n : n ? `${n}, ${q}` : q))}
            className={cn(
              "h-8 rounded-md border px-2.5 text-[12px] font-semibold",
              note.includes(q) ? "border-info bg-accent text-info" : "border-input hover:bg-muted",
            )}
          >
            {q}
          </button>
        ))}
      </div>
      <textarea
        value={note}
        onChange={(e) => setNote(e.target.value.slice(0, 120))}
        rows={3}
        aria-label="Note"
        placeholder="Type a note for the kitchen"
        className="mt-3 w-full resize-none rounded-md border border-input px-2.5 py-2 text-[14px] outline-none focus-visible:border-info focus-visible:ring-2 focus-visible:ring-info/20"
      />
      <div className="mt-3 flex justify-end gap-2 border-t border-line pt-3">
        {initial && <Btn type="button" className="mr-auto h-9 text-void" onClick={() => onSave("")}>Remove note</Btn>}
        <Btn type="button" className="h-9" onClick={onCancel}>Cancel</Btn>
        <Btn type="submit" tone="dark" className="h-9 px-5">Save</Btn>
      </div>
    </form>
  );
}
