"use client";

import { useState } from "react";
import { BadgePercent } from "lucide-react";
import { Modal } from "@/components/ui/sheet-dialog";
import { Btn } from "@/components/pos/button";
import { inputClass } from "@/components/pos/field";
import { cn } from "@/lib/utils";
import { pct, rsExact } from "@/lib/money";

const PRESETS = [5, 10, 15, 20];

export function DiscountDialog({
  open,
  current,
  subtotal,
  onClose,
  onApply,
}: {
  open: boolean;
  current: number;
  subtotal: number;
  onClose: () => void;
  onApply: (rate: number) => void;
}) {
  return (
    <Modal open={open} onOpenChange={(o) => !o && onClose()} title="Bill discount" icon={BadgePercent} className="max-w-sm">
      {open && <DiscountForm current={current} subtotal={subtotal} onApply={onApply} onCancel={onClose} />}
    </Modal>
  );
}

function DiscountForm({ current, subtotal, onApply, onCancel }: { current: number; subtotal: number; onApply: (r: number) => void; onCancel: () => void }) {
  const [percent, setPercent] = useState(current ? String(Math.round(current * 100)) : "");
  const value = Math.min(100, Math.max(0, Number(percent || 0)));

  return (
    <div>
      <div className="grid grid-cols-4 gap-1.5">
        {PRESETS.map((p) => (
          <button
            key={p}
            onClick={() => setPercent(String(p))}
            className={cn("h-10 rounded-md border text-[14px] font-semibold", value === p ? "border-info bg-accent text-info" : "border-input hover:bg-muted")}
          >
            {p}%
          </button>
        ))}
      </div>
      <label htmlFor="pct" className="mt-3 block text-[12px] font-semibold text-muted-foreground">Other (%)</label>
      <input id="pct" inputMode="numeric" value={percent} onChange={(e) => setPercent(e.target.value.replace(/\D/g, "").slice(0, 3))} className={cn(inputClass, "mt-1")} />
      <p className="mt-3 flex justify-between rounded-md bg-muted px-3 py-2 text-[13px]">
        <span className="text-muted-foreground">Discount amount</span>
        <span className="num font-semibold">Rs. {rsExact(pct(subtotal, value / 100))}</span>
      </p>
      <p className="mt-2 text-[12px] text-muted-foreground">Manager approval for discounts will be added with the database.</p>
      <div className="mt-3 flex justify-end gap-2 border-t border-line pt-3">
        {current > 0 && <Btn className="mr-auto h-9 text-void" onClick={() => onApply(0)}>Remove</Btn>}
        <Btn className="h-9" onClick={onCancel}>Cancel</Btn>
        <Btn tone="dark" className="h-9 px-5" onClick={() => onApply(value / 100)}>Apply</Btn>
      </div>
    </div>
  );
}
