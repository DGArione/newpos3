import type { LucideIcon } from "lucide-react";

// Toolbar strip under the top bar on list/admin screens.
export function PageHeader({
  title,
  icon: Icon,
  meta,
  children,
}: {
  title: string;
  icon: LucideIcon;
  meta?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <div className="flex min-h-14 flex-wrap items-center gap-x-4 gap-y-2 border-b border-line px-5 py-2.5">
      <h1 className="flex items-center gap-2 text-[16px] font-semibold">
        <span className="flex size-8 items-center justify-center rounded-lg bg-brand-soft text-pay"><Icon className="size-[18px]" strokeWidth={2} /></span>
        {title}
      </h1>
      {meta && <span className="text-[13px] text-muted-foreground">{meta}</span>}
      <div className="ml-auto flex flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}
