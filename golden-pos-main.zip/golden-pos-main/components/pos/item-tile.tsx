import { cn } from "@/lib/utils";
import { rsExact } from "@/lib/money";

/**
 * Menu item button. Category colour as a top bar (the way most POS colour-code
 * their keys), code and price always visible, count once it's on the order.
 */
export function ItemTile({
  name,
  code,
  price,
  color,
  count = 0,
  soldOut,
  onClick,
}: {
  name: string;
  code: number;
  price: number;
  color: string;
  count?: number;
  soldOut?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={`${name}, ${rsExact(price)}${soldOut ? ", sold out" : ""}`}
      style={{ borderTopColor: soldOut ? undefined : color }}
      className={cn(
        "relative flex h-[92px] flex-col rounded-md border border-t-[3px] bg-panel px-2.5 pb-2 pt-1.5 text-left transition-colors",
        soldOut
          ? "cursor-not-allowed border-border border-t-input bg-muted text-muted-foreground"
          : count
            ? "border-x-info border-b-info bg-accent"
            : "border-x-border border-b-border hover:bg-muted active:bg-accent",
      )}
    >
      <span className="flex items-center justify-between font-mono text-[11px] text-muted-foreground">
        {code}
        {count > 0 && (
          <span className="num rounded-sm bg-info px-1.5 font-sans text-[11px] font-bold text-on-tone">x{count}</span>
        )}
        {soldOut && <span className="font-sans text-[11px] font-semibold text-void">Sold out</span>}
      </span>
      <span className={cn("mt-0.5 line-clamp-2 min-h-[2lh] text-[13px] font-semibold leading-[1.2]", soldOut && "line-through")}>{name}</span>
      <span className="num mt-auto pt-1 text-[13px] font-semibold">{rsExact(price)}</span>
    </button>
  );
}
