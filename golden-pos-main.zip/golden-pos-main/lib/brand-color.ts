// Brand colour presets and checks. Shared by the Settings screen and the server.

export const DEFAULT_BRAND_COLOR = "#f6990d";

export const BRAND_PRESETS: { name: string; hex: string }[] = [
  { name: "Golden orange", hex: "#f6990d" },
  { name: "Coral", hex: "#ee5a46" },
  { name: "Crimson", hex: "#d62f4b" },
  { name: "Plum", hex: "#a3368f" },
  { name: "Ocean blue", hex: "#2f7de1" },
  { name: "Lagoon teal", hex: "#0f97a3" },
  { name: "Emerald", hex: "#14a06a" },
  { name: "Charcoal", hex: "#3b3b3b" },
];

export const isHex = (v: string) => /^#[0-9a-f]{6}$/i.test(v);

function luminance(hex: string) {
  const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255);
  const [r, g, b] = c.map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** Contrast of white text on this colour (WCAG ratio). */
export const whiteContrast = (hex: string) => 1.05 / (luminance(hex) + 0.05);

// Buttons use white text on the brand colour. The default orange sits at about 2.2:1,
// so anything paler than it would make button text hard to read.
export const MIN_WHITE_CONTRAST = 2.1;

export const brandColorProblem = (hex: string): string | null => {
  if (!isHex(hex)) return "Pick a colour.";
  if (whiteContrast(hex) < MIN_WHITE_CONTRAST) return "Too light: white text on buttons would be hard to read. Pick a deeper shade.";
  return null;
};
