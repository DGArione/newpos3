"use client";

import { useActionState, useState, useTransition } from "react";
import { KeyRound, Loader2, Save, Unlock, UserCheck, UserX } from "lucide-react";
import { toast } from "sonner";
import { Modal } from "@/components/ui/sheet-dialog";
import { Field, inputClass } from "@/components/pos/field";
import { Btn } from "@/components/pos/button";
import { keepFormOnSubmit } from "@/lib/use-keep-form";
import { resetPin, setActive, unlock, type FormState } from "./actions";

export function StaffRowActions({ userId, name, active, locked }: { userId: string; name: string; active: boolean; locked: boolean }) {
  const [pinOpen, setPinOpen] = useState(false);
  const [pending, start] = useTransition();

  function run(fn: () => Promise<{ error: string | null | undefined }>, ok: string) {
    start(async () => {
      const r = await fn();
      if (r.error) toast.error(r.error);
      else toast.success(ok);
    });
  }

  return (
    <div className="flex justify-end gap-1">
      {locked && (
        <Btn size="sm" disabled={pending} onClick={() => run(() => unlock(userId), `${name} unlocked.`)}>
          <Unlock className="size-4" /> Unlock
        </Btn>
      )}
      {active && (
        <Btn size="sm" disabled={pending} onClick={() => setPinOpen(true)}>
          <KeyRound className="size-4" /> Reset PIN
        </Btn>
      )}
      <Btn
        size="sm" tone={active ? "void-outline" : "outline"}
        disabled={pending}
        onClick={() => run(() => setActive(userId, !active), active ? `${name} deactivated.` : `${name} reactivated.`)}
      >
        {active ? <UserX className="size-4" /> : <UserCheck className="size-4" />}
        {active ? "Deactivate" : "Activate"}
      </Btn>

      <Modal open={pinOpen} onOpenChange={setPinOpen} title={`Reset PIN - ${name}`} icon={KeyRound} description="The user will be logged out of every terminal." className="max-w-sm">
        {pinOpen && <PinForm userId={userId} onCancel={() => setPinOpen(false)} onDone={(m) => { toast.success(m); setPinOpen(false); }} />}
      </Modal>
    </div>
  );
}

function PinForm({ userId, onDone, onCancel }: { userId: string; onDone: (m: string) => void; onCancel: () => void }) {
  const [state, action, pending] = useActionState(async (prev: FormState, fd: FormData) => {
    const r = await resetPin(prev, fd);
    if (r?.ok) onDone(r.ok);
    return r;
  }, undefined);

  return (
    <form onSubmit={keepFormOnSubmit(action)} className="space-y-3 text-left">
      <input type="hidden" name="userId" value={userId} />
      <Field label="New PIN" htmlFor="newPin" error={state?.fields?.pin ?? state?.error} hint="4 to 6 digits">
        <input id="newPin" name="pin" type="password" inputMode="numeric" autoComplete="new-password" autoFocus required className={inputClass} />
      </Field>
      <div className="flex justify-end gap-2 border-t border-line pt-3">
        <Btn type="button" onClick={onCancel}>Cancel</Btn>
        <Btn type="submit" tone="pay" className="px-5" disabled={pending}>
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} Save PIN
        </Btn>
      </div>
    </form>
  );
}
