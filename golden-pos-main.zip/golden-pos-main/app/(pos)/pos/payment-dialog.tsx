"use client";

import { useState } from "react";
import { Banknote, CheckCircle2, CreditCard, Delete, QrCode, Wallet } from "lucide-react";
import { Modal } from "@/components/ui/sheet-dialog";
import { Btn } from "@/components/pos/button";
import { inputClass } from "@/components/pos/field";
import { cn } from "@/lib/utils";
import { rs, rsExact } from "@/lib/money";

type Method = "cash" | "card" | "payhere";

const METHODS: { id: Method; label: string; icon: typeof Banknote }[] = [
  { id: "cash", label: "Cash", icon: Banknote },
  { id: "card", label: "Card", icon: CreditCard },
  { id: "payhere", label: "PayHere QR", icon: QrCode },
];

// Sri Lankan notes, in cents.
const NOTES = [100000, 200000, 500000];
const PAD = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "00", "0", "back"] as const;

export function PaymentDialog({
  open,
  onOpenChange,
  orderNo,
  total,
  onPaid,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orderNo: number;
  total: number;
  onPaid: (message: string) => void;
}) {
  return (
    <Modal open={open} onOpenChange={onOpenChange} title={`Payment - Order #${orderNo}`} icon={Wallet} className="max-w-[720px]">
      {open && <PaymentForm key={orderNo} total={total} onPaid={onPaid} />}
    </Modal>
  );
}

function PaymentForm({ total, onPaid }: { total: number; onPaid: (message: string) => void }) {
  const [method, setMethod] = useState<Method>("cash");
  const [tendered, setTendered] = useState(""); // rupees typed on the pad
  const [cardRef, setCardRef] = useState("");

  const tenderedCents = Number(tendered || 0) * 100;
  const balance = tenderedCents - total;

  function press(k: (typeof PAD)[number]) {
    if (k === "back") return setTendered((t) => t.slice(0, -1));
    setTendered((t) => (t.length >= 7 ? t : (t + k).replace(/^0+/, "")));
  }

  const canComplete = method === "cash" ? tenderedCents >= total : method === "card";

  // TODO(db phase): save payment + payment_events, open cash drawer, print bill.
  function complete() {
    if (method === "cash") onPaid(balance > 0 ? `Payment received. Balance to return: Rs. ${rsExact(balance)}` : "Payment received (exact).");
    else onPaid(`Card payment recorded${cardRef ? ` (approval ${cardRef})` : ""}.`);
  }

  return (
    <div className="grid gap-4 sm:grid-cols-[1fr_260px]">
      <div className="space-y-3">
        <div className="rounded-md border border-border bg-muted px-4 py-3">
          <p className="text-[12px] text-muted-foreground">Amount due</p>
          <p className="num text-[30px] font-bold leading-tight">Rs. {rsExact(total)}</p>
        </div>

        <div role="radiogroup" aria-label="Payment method" className="grid grid-cols-3 gap-1.5">
          {METHODS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              role="radio"
              aria-checked={method === id}
              onClick={() => setMethod(id)}
              className={cn(
                "flex h-14 flex-col items-center justify-center gap-0.5 rounded-md border text-[12px] font-semibold",
                method === id ? "border-ring bg-accent text-accent-foreground ring-1 ring-ring" : "border-input hover:bg-muted",
              )}
            >
              <Icon className="size-5" strokeWidth={1.6} />
              {label}
            </button>
          ))}
        </div>

        {method === "cash" && (
          <>
            <dl className="divide-y divide-line rounded-md border border-border text-[14px]">
              <div className="flex items-center justify-between px-3 py-2">
                <dt className="text-muted-foreground">Cash received</dt>
                <dd className="num text-[18px] font-semibold">{tendered ? rsExact(tenderedCents) : "0.00"}</dd>
              </div>
              <div className={cn("flex items-center justify-between px-3 py-2", tendered && balance < 0 && "text-void")}>
                <dt className={cn(!(tendered && balance < 0) && "text-muted-foreground")}>
                  {tendered && balance < 0 ? "Short by" : "Balance to return"}
                </dt>
                <dd className={cn("num text-[18px] font-bold", balance >= 0 && tendered && "text-pay")}>
                  {rsExact(tendered ? Math.abs(balance) : 0)}
                </dd>
              </div>
            </dl>
            <div className="grid grid-cols-4 gap-1.5">
              <Btn size="lg" onClick={() => setTendered(String(total / 100))}>Exact</Btn>
              {NOTES.map((n) => (
                <Btn key={n} size="lg" className="num" onClick={() => setTendered(String(n / 100))}>{rs(n)}</Btn>
              ))}
            </div>
          </>
        )}

        {method === "card" && (
          <div className="space-y-2 rounded-md border border-border p-3 text-[13px]">
            <p className="text-muted-foreground">Charge Rs. {rsExact(total)} on the card terminal, then confirm here.</p>
            <label htmlFor="cardRef" className="block text-[12px] font-semibold text-muted-foreground">Approval code (optional)</label>
            <input id="cardRef" value={cardRef} onChange={(e) => setCardRef(e.target.value.slice(0, 12))} className={inputClass} />
          </div>
        )}

        {method === "payhere" && (
          <div className="rounded-md border border-dashed border-input p-4 text-[13px] text-muted-foreground">
            PayHere QR is not connected yet. Use cash or card.
          </div>
        )}
      </div>

      <div className="flex flex-col gap-1.5">
        <div className={cn("grid grid-cols-3 gap-1.5", method !== "cash" && "pointer-events-none opacity-40")} aria-label="Keypad">
          {PAD.map((k) => (
            <button
              key={k}
              onClick={() => press(k)}
              aria-label={k === "back" ? "Delete" : k}
              className="num flex h-[52px] items-center justify-center rounded-md border border-input bg-background text-[18px] font-semibold hover:bg-muted active:bg-accent"
            >
              {k === "back" ? <Delete className="size-5" /> : k}
            </button>
          ))}
        </div>
        <Btn onClick={() => setTendered("")} disabled={method !== "cash"}>Clear</Btn>
        <Btn tone="pay" size="xl" className="mt-auto" onClick={complete} disabled={!canComplete}>
          <CheckCircle2 className="size-5" /> Complete Payment
        </Btn>
      </div>
    </div>
  );
}
