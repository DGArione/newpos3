import type { LucideIcon } from "lucide-react";

export function MetricCard({ icon: Icon, label, value, description }: { icon: LucideIcon; label: string; value: string; description?: string }) {
  return (
    <div className="flex items-start gap-3 bg-panel px-4 py-3">
      <Icon className="mt-0.5 size-[18px] text-muted-foreground" strokeWidth={1.75} />
      <div className="min-w-0">
        <p className="text-[12px] text-muted-foreground">{label}</p>
        <p className="num text-[20px] font-bold leading-tight">{value}</p>
        {description && <p className="text-[12px] text-muted-foreground">{description}</p>}
      </div>
    </div>
  );
}
