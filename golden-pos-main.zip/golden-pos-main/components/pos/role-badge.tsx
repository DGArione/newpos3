import { Banknote, ChefHat, ConciergeBell, Crown, ShieldCheck, type LucideIcon } from "lucide-react";
import { ROLE_LABEL, type Role } from "@/lib/auth/roles";

const ICON: Record<Role, LucideIcon> = {
  OWNER: Crown,
  MANAGER: ShieldCheck,
  CASHIER: Banknote,
  WAITER: ConciergeBell,
  KITCHEN: ChefHat,
};

export function RoleBadge({ role }: { role: Role }) {
  const Icon = ICON[role];
  return (
    <span className="inline-flex items-center gap-1.5">
      <Icon className="size-4 text-muted-foreground" strokeWidth={1.75} />
      {ROLE_LABEL[role]}
    </span>
  );
}
