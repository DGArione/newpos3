import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { rsExact } from "@/lib/money";
import type { IconName } from "@/lib/mock/menu";
import { MenuIcon } from "./menu-icon";

/** Photo of the dish, or a tinted placeholder with the category icon until a photo is added. */
export function DishImage({
  src,
  alt,
  color,
  icon,
  className,
  iconClassName = "size-10",
}: {
  src?: string;
  alt: string;
  color: string;
  icon: IconName;
  className?: string;
  iconClassName?: string;
}) {
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element -- local menu photos, no optimiser needed offline
    return <img src={src} alt={alt} className={cn("object-cover", className)} />;
  }
  return (
    <div
      aria-hidden="true"
      className={cn("flex items-center justify-center", className)}
      style={{
        background: `radial-gradient(circle at 30% 25%, color-mix(in oklch, ${color} 19%, transparent), color-mix(in oklch, ${color} 7%, transparent) 60%), color-mix(in oklch, ${color} 5%, transparent)`,
        color,
      }}
    >
      <MenuIcon name={icon} className={iconClassName} strokeWidth={1.4} />
    </div>
  );
}

/** Menu item card: photo, name, short description, price and Add. */
export function MenuCard({
  name,
  desc,
  code,
  price,
  color,
  icon,
  image,
  count = 0,
  soldOut,
  onAdd,
}: {
  name: string;
  desc: string;
  code: number;
  price: number;
  color: string;
  icon: IconName;
  image?: string;
  count?: number;
  soldOut?: boolean;
  onAdd?: () => void;
}) {
  return (
    <button
      onClick={onAdd}
      aria-label={`Add ${name}, Rs ${rsExact(price)}${soldOut ? ", sold out" : ""}`}
      className={cn(
        "group relative flex flex-col rounded-xl bg-brand-soft/60 p-2 text-left transition-[box-shadow,background-color] dark:bg-muted",
        soldOut ? "cursor-not-allowed opacity-55" : "hover:bg-brand-soft hover:shadow-[0_8px_20px_-12px_color-mix(in_oklch,var(--brand-base)_60%,transparent)]",
        count > 0 && "ring-2 ring-pay",
      )}
    >
      <DishImage src={image} alt={name} color={color} icon={icon} className="aspect-[16/10] w-full rounded-lg" />
      <span className="absolute left-3 top-3 rounded-md bg-panel/90 px-1.5 font-mono text-[11px] text-muted-foreground">{code}</span>
      {count > 0 && (
        <span className="num absolute right-3 top-3 flex h-6 min-w-6 items-center justify-center rounded-full bg-pay px-1.5 text-[12px] font-semibold text-white">
          {count}
        </span>
      )}
      <span className={cn("mt-2 truncate px-0.5 text-[13px] font-semibold", soldOut && "line-through")}>{name}</span>
      <span className="truncate px-0.5 text-[11px] text-muted-foreground">{desc}</span>
      <span className="mt-2 flex items-center justify-between px-0.5">
        <span className="num text-[13px] font-semibold">
          <span className="text-pay">Rs </span>
          {rsExact(price)}
        </span>
        {soldOut ? (
          <span className="text-[11px] font-medium text-void-ink">Sold out</span>
        ) : (
          <span className="flex h-6 items-center gap-0.5 rounded-full bg-pay px-2.5 text-[11px] font-medium text-white group-hover:bg-pay-hover">
            <Plus className="size-3" strokeWidth={2.5} /> Add
          </span>
        )}
      </span>
    </button>
  );
}
