import { z } from "zod";

export const heldLineSchema = z.object({
  itemId: z.string().min(1).max(64),
  qty: z.int().min(1).max(999),
  note: z.string().max(80),
  sent: z.boolean(),
});

export const orderSnapshotSchema = z.object({
  orderNo: z.int().positive(),
  type: z.enum(["dine-in", "takeaway", "delivery"]),
  table: z.string().max(10).nullable(),
  guests: z.int().min(1).max(30),
  customer: z.string().max(80),
  discountRate: z.number().min(0).max(1),
  lines: z.array(heldLineSchema).min(1).max(200),
  total: z.int().min(0),
});
export type OrderSnapshot = z.infer<typeof orderSnapshotSchema>;
