import { cookies } from "next/headers";
import { format } from "date-fns";
import { Shell } from "@/components/pos/shell";
import { requireUser, terminalName } from "@/lib/auth/session";
import { ACCESS, ROLE_LABEL, canAccess, type Area } from "@/lib/auth/roles";
import { orderStore, settingsStore } from "@/lib/store";
import { SIDEBAR_COOKIE, parseSidebar } from "@/lib/sidebar";
import { areas as floor } from "@/lib/mock/floor";
import { kitchenTickets } from "@/lib/mock/orders";
import { signOut } from "../(auth)/actions";

export default async function PosLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const areas = (Object.keys(ACCESS) as Area[]).filter((a) => canAccess(user.role, a));
  const tables = floor.flatMap((a) => a.tables.map((t) => ({ id: t.id, area: a.name })));
  const [branding, held, jar] = await Promise.all([settingsStore.branding(), orderStore.held(), cookies()]);

  return (
    <Shell
      areas={areas}
      name={user.name}
      roleLabel={ROLE_LABEL[user.role]}
      terminal={terminalName()}
      since={format(user.signedInAt, "h:mm a")}
      tables={tables}
      readyTickets={kitchenTickets.filter((t) => t.stage === "ready").length}
      brand={{ name: branding.restaurantName, logo: branding.logo }}
      heldCount={held.length}
      sidebarMode={parseSidebar(jar.get(SIDEBAR_COOKIE)?.value)}
      signOut={signOut}
    >
      {children}
    </Shell>
  );
}
